-- Inclusão do comando de impressão
n = 2
print(n)