-- Listagem 2: Declaração de uma variável

-- Em Lua, declaração de variaveis limitam apenas seu escopo
-- As variaveis podem ser local ou global
-- local: local x = 10 - precisam ser inicializadas
-- global: x = 10      - não precisam ser inicializadas
-- local x          é um programa aceito em lua (declaração de uma variavel local)
-- x                não é um programa aceito em lua