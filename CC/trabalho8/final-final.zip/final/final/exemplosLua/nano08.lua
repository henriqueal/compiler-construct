-- Listagem 8: Inclusão do comando condicional com parte senão

n = 1
if(n == 1)
then
	print(n)
else
	print("0")
end