-- Atribuição de uma soma de inteiros a uma variável
n = 1 + 2