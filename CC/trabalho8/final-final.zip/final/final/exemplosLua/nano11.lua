-- Listagem 11: Introdução do comando de repetição enquanto
n = 1
m = 2
x = 5

while(x > n)
do
	n = n + m
	print(n)
end