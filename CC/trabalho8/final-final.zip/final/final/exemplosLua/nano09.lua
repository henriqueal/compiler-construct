-- Listagem 9: Atribuição de duas operações aritméticas sobre inteiros a uma variável

n = 1 + 1 / 2
if (n == 1)
then
	print(n)
else
	print("0")
end