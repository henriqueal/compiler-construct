-- Listagem 7: Inclusão do comando condicional
n = 1
if (n == 1)
then
	print(n)
end