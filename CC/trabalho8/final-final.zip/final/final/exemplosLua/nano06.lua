-- Listagem 6: Atribuição de uma subtração de inteiros a uma variável

n = 1 - 2
print(n)