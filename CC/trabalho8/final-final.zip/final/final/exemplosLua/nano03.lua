-- Atribuicao de um inteiro a uma variavel
n = 1