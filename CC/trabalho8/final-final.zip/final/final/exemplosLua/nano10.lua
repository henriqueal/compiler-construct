-- Listagem 10: Atribuição de duas variáveis inteiras
n = 1
m = 2

if(n == m)
then
	print(n)
else
	print("0")
end
