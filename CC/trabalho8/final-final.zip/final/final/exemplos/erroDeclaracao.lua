m:inteiro
-- função que calcula a fatorial de um número
-- recebe um número "n"
function fat(n:string,m:string):inteiro
	w:inteiro
	if (n == m) then
		return 1
	else
		return 0
	end
end


n=1
m=2

-- imprime o fatorial
print(n,m)