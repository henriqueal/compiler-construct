print(123)
--   aula de compiladores
print("digite um valor:\n")
n = tonumber(io.read())

print("Valor digitado foi:\n")
io.write(n)
--[[
asdasdasdasd

--[[

]]
-- 
@

print("\nfinal!!)