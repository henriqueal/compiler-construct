s:inteiro
f:float
-- função que calcula a fatorial de um número
-- recebe um número "n"
function fat(n:inteiro):inteiro
	w:inteiro
	if (n == 0) then
		return 1
	else
		return n * fat(n - 1)
	end
end
s=1
s=io.read()
f=5.5
print(f)
if (f == s)then
	print("igual")
else
	print("dif")
end
-- imprime o fatorial
print("Fatorial de s: ", fat(s))