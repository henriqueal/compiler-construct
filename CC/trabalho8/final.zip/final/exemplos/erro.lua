
n,m:string

begin
-- função que calcula a fatorial de um número
-- recebe um número "n"


n="tchau"
m="oi"
m=io.read()

-- imprime o fatorial
print("Fatorial de s: ", n,m)
end