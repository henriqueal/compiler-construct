a,s,b,soma,numero: inteiro



function somador(x: inteiro, y: inteiro) : inteiro
  r: inteiro
  w:inteiro
  r = x + y
	return r
end 


numero = 1
a=1
b=1
s=1
soma=1

while (numero != 5) do
        numero = numero + 1
        print(numero)
	
end

if ( a > b ) then
  a=3
else
  a=23
end 

s =io.read()

soma = somador(a, b) - 1
print ("Calculando: ", 2*a - 3, a, b, soma, 5, s)

