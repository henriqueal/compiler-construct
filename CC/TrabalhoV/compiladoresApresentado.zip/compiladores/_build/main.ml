open Ast

let parse_arq arq =
  let ic = open_in arq in
  let lexbuf = Lexing.from_channel ic in
  let ast = Parser.program Lualexer.token lexbuf in
  ast
;;



