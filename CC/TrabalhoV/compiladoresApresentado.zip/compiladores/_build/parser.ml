
module Basics = struct
  
  exception Error
  
  type token = 
    | WHILE
    | VIRGULA
    | UNTIL
    | TRUE
    | TONUMBER
    | THEN
    | SUBTRACAO
    | STRING of (string)
    | SOMA
    | RETURN
    | REPEAT
    | READ
    | QUADRADO
    | PRINT
    | PONTOPONTOPONTO
    | PONTOPONTO
    | PONTOEVIRGULA
    | PONTO
    | OR
    | NOT
    | NIL
    | MULTIPLICACAO
    | MODULO
    | MENORIGUAL
    | MENOR
    | MAIORIGUAL
    | MAIOR
    | LOCAL
    | INT of (int)
    | IN
    | IGUALDADE
    | IF
    | ID of (string)
    | GOTO
    | FUNCTION
    | FOR
    | FLOAT of (float)
    | FECHAPARENTESE
    | FECHACOLCHETE
    | FECHACHAVES
    | FALSE
    | EXPONENCIACAO
    | EOF
    | END
    | ELSEIF
    | ELSE
    | DOISPONTOS
    | DOISDOISPONTOS
    | DO
    | DIVISAO
    | DIFERENTE
    | BREAK
    | ATRIBUICAO
    | AND
    | ABREPARENTESE
    | ABRECOLCHETE
    | ABRECHAVES
  
end

include Basics

let _eRR =
  Basics.Error

type _menhir_env = {
  _menhir_lexer: Lexing.lexbuf -> token;
  _menhir_lexbuf: Lexing.lexbuf;
  _menhir_token: token;
  mutable _menhir_error: bool
}

and _menhir_state = 
  | MenhirState203
  | MenhirState202
  | MenhirState193
  | MenhirState192
  | MenhirState189
  | MenhirState184
  | MenhirState181
  | MenhirState180
  | MenhirState179
  | MenhirState178
  | MenhirState175
  | MenhirState173
  | MenhirState161
  | MenhirState156
  | MenhirState153
  | MenhirState152
  | MenhirState150
  | MenhirState149
  | MenhirState147
  | MenhirState144
  | MenhirState140
  | MenhirState138
  | MenhirState137
  | MenhirState136
  | MenhirState135
  | MenhirState134
  | MenhirState133
  | MenhirState132
  | MenhirState131
  | MenhirState129
  | MenhirState122
  | MenhirState119
  | MenhirState115
  | MenhirState114
  | MenhirState113
  | MenhirState109
  | MenhirState107
  | MenhirState102
  | MenhirState101
  | MenhirState100
  | MenhirState99
  | MenhirState94
  | MenhirState93
  | MenhirState91
  | MenhirState89
  | MenhirState86
  | MenhirState83
  | MenhirState79
  | MenhirState78
  | MenhirState76
  | MenhirState75
  | MenhirState74
  | MenhirState73
  | MenhirState71
  | MenhirState70
  | MenhirState53
  | MenhirState50
  | MenhirState47
  | MenhirState43
  | MenhirState41
  | MenhirState39
  | MenhirState37
  | MenhirState36
  | MenhirState33
  | MenhirState31
  | MenhirState30
  | MenhirState29
  | MenhirState24
  | MenhirState21
  | MenhirState19
  | MenhirState18
  | MenhirState1
  | MenhirState0
  
  open Ast

let rec _menhir_goto_option_fieldsep_ : _menhir_env -> 'ttv_tail -> _menhir_state -> (Ast.fieldsep option) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = Obj.magic _menhir_stack in
    let _menhir_stack = Obj.magic _menhir_stack in
    let (fs : (Ast.fieldsep option)) = _v in
    let ((_menhir_stack, _menhir_s, (f : (Ast.field))), _, (ffr : (Ast.fieldsep_field_rule list))) = _menhir_stack in
    let _v : (Ast.fieldlist) =                                                   ( FieldLists(f, ffr, fs)) in
    let _menhir_stack = Obj.magic _menhir_stack in
    let _menhir_stack = Obj.magic _menhir_stack in
    let (x : (Ast.fieldlist)) = _v in
    let _v : (Ast.fieldlist option) =     ( Some x ) in
    _menhir_goto_option_fieldlist_ _menhir_env _menhir_stack _menhir_s _v

and _menhir_goto_list_fieldsep_field_rule_ : _menhir_env -> 'ttv_tail -> _menhir_state -> (Ast.fieldsep_field_rule list) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    match _menhir_s with
    | MenhirState83 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | PONTOEVIRGULA ->
            _menhir_run85 _menhir_env (Obj.magic _menhir_stack) MenhirState86
        | VIRGULA ->
            _menhir_run84 _menhir_env (Obj.magic _menhir_stack) MenhirState86
        | FECHACHAVES ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_s = MenhirState86 in
            let _v : (Ast.fieldsep option) =     ( None ) in
            _menhir_goto_option_fieldsep_ _menhir_env _menhir_stack _menhir_s _v
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState86)
    | MenhirState89 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_stack = Obj.magic _menhir_stack in
        let ((_menhir_stack, _menhir_s, (x : (Ast.fieldsep_field_rule))), _, (xs : (Ast.fieldsep_field_rule list))) = _menhir_stack in
        let _v : (Ast.fieldsep_field_rule list) =     ( x :: xs ) in
        _menhir_goto_list_fieldsep_field_rule_ _menhir_env _menhir_stack _menhir_s _v
    | _ ->
        _menhir_fail ()

and _menhir_goto_fieldsep : _menhir_env -> 'ttv_tail -> _menhir_state -> (Ast.fieldsep) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    match _menhir_s with
    | MenhirState86 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, (x : (Ast.fieldsep))) = _menhir_stack in
        let _v : (Ast.fieldsep option) =     ( Some x ) in
        _menhir_goto_option_fieldsep_ _menhir_env _menhir_stack _menhir_s _v
    | MenhirState83 | MenhirState89 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | ABRECHAVES ->
            _menhir_run37 _menhir_env (Obj.magic _menhir_stack) MenhirState91
        | ABRECOLCHETE ->
            _menhir_run75 _menhir_env (Obj.magic _menhir_stack) MenhirState91
        | ABREPARENTESE ->
            _menhir_run36 _menhir_env (Obj.magic _menhir_stack) MenhirState91
        | FALSE ->
            _menhir_run35 _menhir_env (Obj.magic _menhir_stack) MenhirState91
        | FLOAT _v ->
            _menhir_run34 _menhir_env (Obj.magic _menhir_stack) MenhirState91 _v
        | FUNCTION ->
            _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState91
        | ID _v ->
            _menhir_run38 _menhir_env (Obj.magic _menhir_stack) MenhirState91 _v
        | INT _v ->
            _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState91 _v
        | NIL ->
            _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState91
        | NOT ->
            _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState91
        | PONTOPONTOPONTO ->
            _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState91
        | QUADRADO ->
            _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState91
        | STRING _v ->
            _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState91 _v
        | SUBTRACAO ->
            _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState91
        | TONUMBER ->
            _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState91
        | TRUE ->
            _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState91
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState91)
    | _ ->
        _menhir_fail ()

and _menhir_goto_list_elseif_rule_ : _menhir_env -> 'ttv_tail -> _menhir_state -> (Ast.elseif_rule list) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    match _menhir_s with
    | MenhirState178 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | ELSE ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            (match _tok with
            | ABREPARENTESE ->
                _menhir_run36 _menhir_env (Obj.magic _menhir_stack) MenhirState184
            | BREAK ->
                _menhir_run145 _menhir_env (Obj.magic _menhir_stack) MenhirState184
            | DO ->
                _menhir_run144 _menhir_env (Obj.magic _menhir_stack) MenhirState184
            | DOISDOISPONTOS ->
                _menhir_run141 _menhir_env (Obj.magic _menhir_stack) MenhirState184
            | FOR ->
                _menhir_run131 _menhir_env (Obj.magic _menhir_stack) MenhirState184
            | FUNCTION ->
                _menhir_run118 _menhir_env (Obj.magic _menhir_stack) MenhirState184
            | GOTO ->
                _menhir_run116 _menhir_env (Obj.magic _menhir_stack) MenhirState184
            | ID _v ->
                _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState184 _v
            | IF ->
                _menhir_run113 _menhir_env (Obj.magic _menhir_stack) MenhirState184
            | LOCAL ->
                _menhir_run107 _menhir_env (Obj.magic _menhir_stack) MenhirState184
            | PONTOEVIRGULA ->
                _menhir_run106 _menhir_env (Obj.magic _menhir_stack) MenhirState184
            | PRINT ->
                _menhir_run31 _menhir_env (Obj.magic _menhir_stack) MenhirState184
            | REPEAT ->
                _menhir_run30 _menhir_env (Obj.magic _menhir_stack) MenhirState184
            | WHILE ->
                _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState184
            | END | RETURN ->
                _menhir_reduce58 _menhir_env (Obj.magic _menhir_stack) MenhirState184
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState184)
        | END ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _v : (Ast.else_block_rule option) =     ( None ) in
            _menhir_goto_option_else_block_rule_ _menhir_env _menhir_stack _v
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | MenhirState189 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_stack = Obj.magic _menhir_stack in
        let ((_menhir_stack, _menhir_s, (x : (Ast.elseif_rule))), _, (xs : (Ast.elseif_rule list))) = _menhir_stack in
        let _v : (Ast.elseif_rule list) =     ( x :: xs ) in
        _menhir_goto_list_elseif_rule_ _menhir_env _menhir_stack _menhir_s _v
    | _ ->
        _menhir_fail ()

and _menhir_reduce93 : _menhir_env -> 'ttv_tail * _menhir_state * (Ast.functioncall) -> 'ttv_return =
  fun _menhir_env _menhir_stack ->
    let (_menhir_stack, _menhir_s, (f : (Ast.functioncall))) = _menhir_stack in
    let _v : (Ast.prefixexp) =                    ( Functioncall(f) ) in
    _menhir_goto_prefixexp _menhir_env _menhir_stack _menhir_s _v

and _menhir_goto_option_PONTOEVIRGULA_ : _menhir_env -> 'ttv_tail -> (unit option) -> 'ttv_return =
  fun _menhir_env _menhir_stack _v ->
    let _menhir_stack = Obj.magic _menhir_stack in
    let _menhir_stack = Obj.magic _menhir_stack in
    let (_3 : (unit option)) = _v in
    let (_menhir_stack, _, (e : (Ast.explist option))) = _menhir_stack in
    let _1 = () in
    let _v : (Ast.retstat) =                                      ( Retstat(e) ) in
    let _menhir_stack = Obj.magic _menhir_stack in
    let _menhir_stack = Obj.magic _menhir_stack in
    let (x : (Ast.retstat)) = _v in
    let _v : (Ast.retstat option) =     ( Some x ) in
    _menhir_goto_option_retstat_ _menhir_env _menhir_stack _v

and _menhir_goto_list_virgula_var_rule_ : _menhir_env -> 'ttv_tail -> _menhir_state -> (Ast.virgula_var_rule list) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    match _menhir_s with
    | MenhirState153 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_stack = Obj.magic _menhir_stack in
        let (xs : (Ast.virgula_var_rule list)) = _v in
        let (_menhir_stack, _menhir_s, (x : (Ast.virgula_var_rule))) = _menhir_stack in
        let _v : (Ast.virgula_var_rule list) =     ( x :: xs ) in
        _menhir_goto_list_virgula_var_rule_ _menhir_env _menhir_stack _menhir_s _v
    | MenhirState149 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_stack = Obj.magic _menhir_stack in
        let (vir : (Ast.virgula_var_rule list)) = _v in
        let (_menhir_stack, _menhir_s, (v : (Ast.var))) = _menhir_stack in
        let _v : (Ast.varlist) =                                 ( Varlist(v,vir) ) in
        let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | ATRIBUICAO ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            (match _tok with
            | ABRECHAVES ->
                _menhir_run37 _menhir_env (Obj.magic _menhir_stack) MenhirState147
            | ABREPARENTESE ->
                _menhir_run36 _menhir_env (Obj.magic _menhir_stack) MenhirState147
            | FALSE ->
                _menhir_run35 _menhir_env (Obj.magic _menhir_stack) MenhirState147
            | FLOAT _v ->
                _menhir_run34 _menhir_env (Obj.magic _menhir_stack) MenhirState147 _v
            | FUNCTION ->
                _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState147
            | ID _v ->
                _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState147 _v
            | INT _v ->
                _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState147 _v
            | NIL ->
                _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState147
            | NOT ->
                _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState147
            | PONTOPONTOPONTO ->
                _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState147
            | QUADRADO ->
                _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState147
            | STRING _v ->
                _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState147 _v
            | SUBTRACAO ->
                _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState147
            | TONUMBER ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState147
            | TRUE ->
                _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState147
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState147)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | _ ->
        _menhir_fail ()

and _menhir_goto_list_virgula_exp_rule_ : _menhir_env -> 'ttv_tail -> _menhir_state -> (Ast.virgula_exp_rule list) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    match _menhir_s with
    | MenhirState102 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_stack = Obj.magic _menhir_stack in
        let (xs : (Ast.virgula_exp_rule list)) = _v in
        let (_menhir_stack, _menhir_s, (x : (Ast.virgula_exp_rule))) = _menhir_stack in
        let _v : (Ast.virgula_exp_rule list) =     ( x :: xs ) in
        _menhir_goto_list_virgula_exp_rule_ _menhir_env _menhir_stack _menhir_s _v
    | MenhirState99 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_stack = Obj.magic _menhir_stack in
        let (v : (Ast.virgula_exp_rule list)) = _v in
        let (_menhir_stack, _menhir_s, (e : (Ast.exp))) = _menhir_stack in
        let _v : (Ast.explist) =                               ( ExpList(e,v)) in
        let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
        (match _menhir_s with
        | MenhirState161 | MenhirState33 ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, (x : (Ast.explist))) = _menhir_stack in
            let _v : (Ast.explist option) =     ( Some x ) in
            _menhir_goto_option_explist_ _menhir_env _menhir_stack _menhir_s _v
        | MenhirState109 ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _, (e : (Ast.explist))) = _menhir_stack in
            let _1 = () in
            let _v : (Ast.atribuicao_explist_rule) =                          ( Atribuicao(e)) in
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_stack = Obj.magic _menhir_stack in
            let (x : (Ast.atribuicao_explist_rule)) = _v in
            let _v : (Ast.atribuicao_explist_rule option) =     ( Some x ) in
            _menhir_goto_option_atribuicao_explist_rule_ _menhir_env _menhir_stack _v
        | MenhirState147 ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_stack = Obj.magic _menhir_stack in
            let ((_menhir_stack, _menhir_s, (v : (Ast.varlist))), _, (e : (Ast.explist))) = _menhir_stack in
            let _2 = () in
            let _v : (Ast.stat) =                                    ( Atribuicao(v,e) ) in
            _menhir_goto_stat _menhir_env _menhir_stack _menhir_s _v
        | MenhirState173 ->
            let _menhir_stack = Obj.magic _menhir_stack in
            assert (not _menhir_env._menhir_error);
            let _tok = _menhir_env._menhir_token in
            (match _tok with
            | DO ->
                let _menhir_stack = Obj.magic _menhir_stack in
                let _menhir_env = _menhir_discard _menhir_env in
                let _tok = _menhir_env._menhir_token in
                (match _tok with
                | ABREPARENTESE ->
                    _menhir_run36 _menhir_env (Obj.magic _menhir_stack) MenhirState175
                | BREAK ->
                    _menhir_run145 _menhir_env (Obj.magic _menhir_stack) MenhirState175
                | DO ->
                    _menhir_run144 _menhir_env (Obj.magic _menhir_stack) MenhirState175
                | DOISDOISPONTOS ->
                    _menhir_run141 _menhir_env (Obj.magic _menhir_stack) MenhirState175
                | FOR ->
                    _menhir_run131 _menhir_env (Obj.magic _menhir_stack) MenhirState175
                | FUNCTION ->
                    _menhir_run118 _menhir_env (Obj.magic _menhir_stack) MenhirState175
                | GOTO ->
                    _menhir_run116 _menhir_env (Obj.magic _menhir_stack) MenhirState175
                | ID _v ->
                    _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState175 _v
                | IF ->
                    _menhir_run113 _menhir_env (Obj.magic _menhir_stack) MenhirState175
                | LOCAL ->
                    _menhir_run107 _menhir_env (Obj.magic _menhir_stack) MenhirState175
                | PONTOEVIRGULA ->
                    _menhir_run106 _menhir_env (Obj.magic _menhir_stack) MenhirState175
                | PRINT ->
                    _menhir_run31 _menhir_env (Obj.magic _menhir_stack) MenhirState175
                | REPEAT ->
                    _menhir_run30 _menhir_env (Obj.magic _menhir_stack) MenhirState175
                | WHILE ->
                    _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState175
                | END | RETURN ->
                    _menhir_reduce58 _menhir_env (Obj.magic _menhir_stack) MenhirState175
                | _ ->
                    assert (not _menhir_env._menhir_error);
                    _menhir_env._menhir_error <- true;
                    _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState175)
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                let _menhir_stack = Obj.magic _menhir_stack in
                let (_menhir_stack, _menhir_s, _) = _menhir_stack in
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
        | _ ->
            _menhir_fail ())
    | _ ->
        _menhir_fail ()

and _menhir_run44 : _menhir_env -> 'ttv_tail * _menhir_state * (Ast.prefixexp) -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ID _v ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_env = _menhir_discard _menhir_env in
        let _menhir_stack = Obj.magic _menhir_stack in
        let (i : (string)) = _v in
        let ((_menhir_stack, _menhir_s, (p : (Ast.prefixexp))), _) = _menhir_stack in
        let _2 = () in
        let _v : (Ast.var) =                            ( Varponto(p,i) ) in
        _menhir_goto_var _menhir_env _menhir_stack _menhir_s _v
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s

and _menhir_run46 : _menhir_env -> 'ttv_tail * _menhir_state * (Ast.prefixexp) -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ID _v ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_stack = (_menhir_stack, _v) in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | ABRECHAVES ->
            _menhir_run37 _menhir_env (Obj.magic _menhir_stack) MenhirState47
        | ABREPARENTESE ->
            _menhir_run33 _menhir_env (Obj.magic _menhir_stack) MenhirState47
        | STRING _v ->
            _menhir_run32 _menhir_env (Obj.magic _menhir_stack) MenhirState47 _v
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState47)
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s

and _menhir_run50 : _menhir_env -> 'ttv_tail * _menhir_state * (Ast.prefixexp) -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ABRECHAVES ->
        _menhir_run37 _menhir_env (Obj.magic _menhir_stack) MenhirState50
    | ABREPARENTESE ->
        _menhir_run36 _menhir_env (Obj.magic _menhir_stack) MenhirState50
    | FALSE ->
        _menhir_run35 _menhir_env (Obj.magic _menhir_stack) MenhirState50
    | FLOAT _v ->
        _menhir_run34 _menhir_env (Obj.magic _menhir_stack) MenhirState50 _v
    | FUNCTION ->
        _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState50
    | ID _v ->
        _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState50 _v
    | INT _v ->
        _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState50 _v
    | NIL ->
        _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState50
    | NOT ->
        _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState50
    | PONTOPONTOPONTO ->
        _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState50
    | QUADRADO ->
        _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState50
    | STRING _v ->
        _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState50 _v
    | SUBTRACAO ->
        _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState50
    | TONUMBER ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState50
    | TRUE ->
        _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState50
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState50

and _menhir_reduce54 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _v : (Ast.fieldsep_field_rule list) =     ( [] ) in
    _menhir_goto_list_fieldsep_field_rule_ _menhir_env _menhir_stack _menhir_s _v

and _menhir_run84 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _menhir_stack = Obj.magic _menhir_stack in
    let _1 = () in
    let _v : (Ast.fieldsep) =             ( Virgula ) in
    _menhir_goto_fieldsep _menhir_env _menhir_stack _menhir_s _v

and _menhir_run85 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _menhir_stack = Obj.magic _menhir_stack in
    let _1 = () in
    let _v : (Ast.fieldsep) =                   ( PontoEVirgula ) in
    _menhir_goto_fieldsep _menhir_env _menhir_stack _menhir_s _v

and _menhir_goto_binop : _menhir_env -> 'ttv_tail -> _menhir_state -> (Ast.binop) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    let _menhir_stack = Obj.magic _menhir_stack in
    assert (not _menhir_env._menhir_error);
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ABRECHAVES ->
        _menhir_run37 _menhir_env (Obj.magic _menhir_stack) MenhirState70
    | ABREPARENTESE ->
        _menhir_run36 _menhir_env (Obj.magic _menhir_stack) MenhirState70
    | FALSE ->
        _menhir_run35 _menhir_env (Obj.magic _menhir_stack) MenhirState70
    | FLOAT _v ->
        _menhir_run34 _menhir_env (Obj.magic _menhir_stack) MenhirState70 _v
    | FUNCTION ->
        _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState70
    | ID _v ->
        _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState70 _v
    | INT _v ->
        _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState70 _v
    | NIL ->
        _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState70
    | NOT ->
        _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState70
    | PONTOPONTOPONTO ->
        _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState70
    | QUADRADO ->
        _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState70
    | STRING _v ->
        _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState70 _v
    | SUBTRACAO ->
        _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState70
    | TONUMBER ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState70
    | TRUE ->
        _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState70
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState70

and _menhir_goto_option_else_block_rule_ : _menhir_env -> 'ttv_tail -> (Ast.else_block_rule option) -> 'ttv_return =
  fun _menhir_env _menhir_stack _v ->
    let _menhir_stack = (_menhir_stack, _v) in
    let _menhir_stack = Obj.magic _menhir_stack in
    assert (not _menhir_env._menhir_error);
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | END ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_env = _menhir_discard _menhir_env in
        let _menhir_stack = Obj.magic _menhir_stack in
        let ((((((_menhir_stack, _menhir_s), _, (e : (Ast.exp))), _), _, (b : (Ast.block))), _, (elif : (Ast.elseif_rule list))), (elbl : (Ast.else_block_rule option))) = _menhir_stack in
        let _7 = () in
        let _3 = () in
        let _1 = () in
        let _v : (Ast.stat) =                                                                       ( If(e,b,elif, elbl) ) in
        _menhir_goto_stat _menhir_env _menhir_stack _menhir_s _v
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        let _menhir_stack = Obj.magic _menhir_stack in
        let ((_menhir_stack, _menhir_s, _), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s

and _menhir_reduce52 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _v : (Ast.elseif_rule list) =     ( [] ) in
    _menhir_goto_list_elseif_rule_ _menhir_env _menhir_stack _menhir_s _v

and _menhir_run179 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ABRECHAVES ->
        _menhir_run37 _menhir_env (Obj.magic _menhir_stack) MenhirState179
    | ABREPARENTESE ->
        _menhir_run36 _menhir_env (Obj.magic _menhir_stack) MenhirState179
    | FALSE ->
        _menhir_run35 _menhir_env (Obj.magic _menhir_stack) MenhirState179
    | FLOAT _v ->
        _menhir_run34 _menhir_env (Obj.magic _menhir_stack) MenhirState179 _v
    | FUNCTION ->
        _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState179
    | ID _v ->
        _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState179 _v
    | INT _v ->
        _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState179 _v
    | NIL ->
        _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState179
    | NOT ->
        _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState179
    | PONTOPONTOPONTO ->
        _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState179
    | QUADRADO ->
        _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState179
    | STRING _v ->
        _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState179 _v
    | SUBTRACAO ->
        _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState179
    | TONUMBER ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState179
    | TRUE ->
        _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState179
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState179

and _menhir_goto_functioncall : _menhir_env -> 'ttv_tail -> _menhir_state -> (Ast.functioncall) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    match _menhir_s with
    | MenhirState1 | MenhirState192 | MenhirState179 | MenhirState173 | MenhirState161 | MenhirState150 | MenhirState147 | MenhirState137 | MenhirState135 | MenhirState133 | MenhirState113 | MenhirState109 | MenhirState100 | MenhirState33 | MenhirState36 | MenhirState91 | MenhirState37 | MenhirState78 | MenhirState75 | MenhirState39 | MenhirState41 | MenhirState70 | MenhirState50 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        _menhir_reduce93 _menhir_env (Obj.magic _menhir_stack)
    | MenhirState0 | MenhirState203 | MenhirState29 | MenhirState30 | MenhirState184 | MenhirState181 | MenhirState115 | MenhirState175 | MenhirState140 | MenhirState144 | MenhirState156 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | ABREPARENTESE | BREAK | DO | DOISDOISPONTOS | ELSE | ELSEIF | END | EOF | FOR | FUNCTION | GOTO | ID _ | IF | LOCAL | PONTOEVIRGULA | PRINT | REPEAT | RETURN | UNTIL | WHILE ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, (f : (Ast.functioncall))) = _menhir_stack in
            let _v : (Ast.stat) =                    ( Functioncall(f) ) in
            _menhir_goto_stat _menhir_env _menhir_stack _menhir_s _v
        | ABRECHAVES | ABRECOLCHETE | DOISPONTOS | PONTO | STRING _ ->
            _menhir_reduce93 _menhir_env (Obj.magic _menhir_stack)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | _ ->
        _menhir_fail ()

and _menhir_goto_option_explist_ : _menhir_env -> 'ttv_tail -> _menhir_state -> (Ast.explist option) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    match _menhir_s with
    | MenhirState33 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | FECHAPARENTESE ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_env = _menhir_discard _menhir_env in
            let _menhir_stack = Obj.magic _menhir_stack in
            let ((_menhir_stack, _menhir_s), _, (e : (Ast.explist option))) = _menhir_stack in
            let _3 = () in
            let _1 = () in
            let _v : (Ast.args) =                                             ( ArgsParentese(e)) in
            _menhir_goto_args _menhir_env _menhir_stack _menhir_s _v
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | MenhirState161 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | PONTOEVIRGULA ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_env = _menhir_discard _menhir_env in
            let _menhir_stack = Obj.magic _menhir_stack in
            let x = () in
            let _v : (unit option) =     ( Some x ) in
            _menhir_goto_option_PONTOEVIRGULA_ _menhir_env _menhir_stack _v
        | ELSE | ELSEIF | END | EOF | UNTIL ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _v : (unit option) =     ( None ) in
            _menhir_goto_option_PONTOEVIRGULA_ _menhir_env _menhir_stack _v
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | _ ->
        _menhir_fail ()

and _menhir_reduce64 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _v : (Ast.virgula_var_rule list) =     ( [] ) in
    _menhir_goto_list_virgula_var_rule_ _menhir_env _menhir_stack _menhir_s _v

and _menhir_run150 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ABREPARENTESE ->
        _menhir_run36 _menhir_env (Obj.magic _menhir_stack) MenhirState150
    | ID _v ->
        _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState150 _v
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState150

and _menhir_reduce92 : _menhir_env -> 'ttv_tail * _menhir_state * (Ast.var) -> 'ttv_return =
  fun _menhir_env _menhir_stack ->
    let (_menhir_stack, _menhir_s, (v : (Ast.var))) = _menhir_stack in
    let _v : (Ast.prefixexp) =           ( Var(v) ) in
    _menhir_goto_prefixexp _menhir_env _menhir_stack _menhir_s _v

and _menhir_goto_option_doispontos_id_rule_ : _menhir_env -> 'ttv_tail -> (Ast.doispontos_id_rule option) -> 'ttv_return =
  fun _menhir_env _menhir_stack _v ->
    let _menhir_stack = Obj.magic _menhir_stack in
    let _menhir_stack = Obj.magic _menhir_stack in
    let (d : (Ast.doispontos_id_rule option)) = _v in
    let ((_menhir_stack, (i : (string))), _, (p : (Ast.ponto_id_rule list))) = _menhir_stack in
    let _v : (Ast.funcname) =                                                 ( Funcname(i, p, d) ) in
    let _menhir_stack = (_menhir_stack, _v) in
    let _menhir_stack = Obj.magic _menhir_stack in
    assert (not _menhir_env._menhir_error);
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ABREPARENTESE ->
        _menhir_run19 _menhir_env (Obj.magic _menhir_stack) MenhirState129
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState129

and _menhir_goto_option_virgula_tres_pontos_rule_ : _menhir_env -> 'ttv_tail -> (Ast.virgula_tres_pontos_rule option) -> 'ttv_return =
  fun _menhir_env _menhir_stack _v ->
    let _menhir_stack = Obj.magic _menhir_stack in
    let _menhir_stack = Obj.magic _menhir_stack in
    let (v : (Ast.virgula_tres_pontos_rule option)) = _v in
    let (_menhir_stack, _menhir_s, (n : (Ast.namelist))) = _menhir_stack in
    let _v : (Ast.parlist) =                                            ( NameListVirgula(n,v) ) in
    _menhir_goto_parlist _menhir_env _menhir_stack _menhir_s _v

and _menhir_goto_option_atribuicao_explist_rule_ : _menhir_env -> 'ttv_tail -> (Ast.atribuicao_explist_rule option) -> 'ttv_return =
  fun _menhir_env _menhir_stack _v ->
    let _menhir_stack = Obj.magic _menhir_stack in
    let _menhir_stack = Obj.magic _menhir_stack in
    let (a : (Ast.atribuicao_explist_rule option)) = _v in
    let ((_menhir_stack, _menhir_s), _, (n : (Ast.namelist))) = _menhir_stack in
    let _1 = () in
    let _v : (Ast.stat) =                                                 ( Local(n,a) ) in
    _menhir_goto_stat _menhir_env _menhir_stack _menhir_s _v

and _menhir_goto_option_parlist_ : _menhir_env -> 'ttv_tail -> _menhir_state -> (Ast.parlist option) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    let _menhir_stack = Obj.magic _menhir_stack in
    assert (not _menhir_env._menhir_error);
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | FECHAPARENTESE ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | ABREPARENTESE ->
            _menhir_run36 _menhir_env (Obj.magic _menhir_stack) MenhirState29
        | BREAK ->
            _menhir_run145 _menhir_env (Obj.magic _menhir_stack) MenhirState29
        | DO ->
            _menhir_run144 _menhir_env (Obj.magic _menhir_stack) MenhirState29
        | DOISDOISPONTOS ->
            _menhir_run141 _menhir_env (Obj.magic _menhir_stack) MenhirState29
        | FOR ->
            _menhir_run131 _menhir_env (Obj.magic _menhir_stack) MenhirState29
        | FUNCTION ->
            _menhir_run118 _menhir_env (Obj.magic _menhir_stack) MenhirState29
        | GOTO ->
            _menhir_run116 _menhir_env (Obj.magic _menhir_stack) MenhirState29
        | ID _v ->
            _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState29 _v
        | IF ->
            _menhir_run113 _menhir_env (Obj.magic _menhir_stack) MenhirState29
        | LOCAL ->
            _menhir_run107 _menhir_env (Obj.magic _menhir_stack) MenhirState29
        | PONTOEVIRGULA ->
            _menhir_run106 _menhir_env (Obj.magic _menhir_stack) MenhirState29
        | PRINT ->
            _menhir_run31 _menhir_env (Obj.magic _menhir_stack) MenhirState29
        | REPEAT ->
            _menhir_run30 _menhir_env (Obj.magic _menhir_stack) MenhirState29
        | WHILE ->
            _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState29
        | END | RETURN ->
            _menhir_reduce58 _menhir_env (Obj.magic _menhir_stack) MenhirState29
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState29)
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s

and _menhir_goto_parlist : _menhir_env -> 'ttv_tail -> _menhir_state -> (Ast.parlist) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = Obj.magic _menhir_stack in
    let _menhir_stack = Obj.magic _menhir_stack in
    let (x : (Ast.parlist)) = _v in
    let _v : (Ast.parlist option) =     ( Some x ) in
    _menhir_goto_option_parlist_ _menhir_env _menhir_stack _menhir_s _v

and _menhir_goto_option_comma_exp_rule_ : _menhir_env -> 'ttv_tail -> _menhir_state -> (Ast.comma_exp_rule option) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    let _menhir_stack = Obj.magic _menhir_stack in
    assert (not _menhir_env._menhir_error);
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | DO ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | ABREPARENTESE ->
            _menhir_run36 _menhir_env (Obj.magic _menhir_stack) MenhirState140
        | BREAK ->
            _menhir_run145 _menhir_env (Obj.magic _menhir_stack) MenhirState140
        | DO ->
            _menhir_run144 _menhir_env (Obj.magic _menhir_stack) MenhirState140
        | DOISDOISPONTOS ->
            _menhir_run141 _menhir_env (Obj.magic _menhir_stack) MenhirState140
        | FOR ->
            _menhir_run131 _menhir_env (Obj.magic _menhir_stack) MenhirState140
        | FUNCTION ->
            _menhir_run118 _menhir_env (Obj.magic _menhir_stack) MenhirState140
        | GOTO ->
            _menhir_run116 _menhir_env (Obj.magic _menhir_stack) MenhirState140
        | ID _v ->
            _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState140 _v
        | IF ->
            _menhir_run113 _menhir_env (Obj.magic _menhir_stack) MenhirState140
        | LOCAL ->
            _menhir_run107 _menhir_env (Obj.magic _menhir_stack) MenhirState140
        | PONTOEVIRGULA ->
            _menhir_run106 _menhir_env (Obj.magic _menhir_stack) MenhirState140
        | PRINT ->
            _menhir_run31 _menhir_env (Obj.magic _menhir_stack) MenhirState140
        | REPEAT ->
            _menhir_run30 _menhir_env (Obj.magic _menhir_stack) MenhirState140
        | WHILE ->
            _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState140
        | END | RETURN ->
            _menhir_reduce58 _menhir_env (Obj.magic _menhir_stack) MenhirState140
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState140)
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s

and _menhir_reduce60 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _v : (Ast.virgula_exp_rule list) =     ( [] ) in
    _menhir_goto_list_virgula_exp_rule_ _menhir_env _menhir_stack _menhir_s _v

and _menhir_run100 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ABRECHAVES ->
        _menhir_run37 _menhir_env (Obj.magic _menhir_stack) MenhirState100
    | ABREPARENTESE ->
        _menhir_run36 _menhir_env (Obj.magic _menhir_stack) MenhirState100
    | FALSE ->
        _menhir_run35 _menhir_env (Obj.magic _menhir_stack) MenhirState100
    | FLOAT _v ->
        _menhir_run34 _menhir_env (Obj.magic _menhir_stack) MenhirState100 _v
    | FUNCTION ->
        _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState100
    | ID _v ->
        _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState100 _v
    | INT _v ->
        _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState100 _v
    | NIL ->
        _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState100
    | NOT ->
        _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState100
    | PONTOPONTOPONTO ->
        _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState100
    | QUADRADO ->
        _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState100
    | STRING _v ->
        _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState100 _v
    | SUBTRACAO ->
        _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState100
    | TONUMBER ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState100
    | TRUE ->
        _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState100
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState100

and _menhir_goto_prefixexp : _menhir_env -> 'ttv_tail -> _menhir_state -> (Ast.prefixexp) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    match _menhir_s with
    | MenhirState1 | MenhirState192 | MenhirState179 | MenhirState173 | MenhirState161 | MenhirState147 | MenhirState137 | MenhirState135 | MenhirState133 | MenhirState113 | MenhirState109 | MenhirState100 | MenhirState33 | MenhirState36 | MenhirState91 | MenhirState37 | MenhirState78 | MenhirState75 | MenhirState39 | MenhirState70 | MenhirState50 | MenhirState41 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | ABRECHAVES ->
            _menhir_run37 _menhir_env (Obj.magic _menhir_stack) MenhirState43
        | ABRECOLCHETE ->
            _menhir_run50 _menhir_env (Obj.magic _menhir_stack) MenhirState43
        | ABREPARENTESE ->
            _menhir_run33 _menhir_env (Obj.magic _menhir_stack) MenhirState43
        | DOISPONTOS ->
            _menhir_run46 _menhir_env (Obj.magic _menhir_stack) MenhirState43
        | PONTO ->
            _menhir_run44 _menhir_env (Obj.magic _menhir_stack) MenhirState43
        | STRING _v ->
            _menhir_run32 _menhir_env (Obj.magic _menhir_stack) MenhirState43 _v
        | AND | BREAK | DIFERENTE | DIVISAO | DO | DOISDOISPONTOS | ELSE | ELSEIF | END | EOF | EXPONENCIACAO | FECHACHAVES | FECHACOLCHETE | FECHAPARENTESE | FOR | FUNCTION | GOTO | ID _ | IF | IGUALDADE | LOCAL | MAIOR | MAIORIGUAL | MENOR | MENORIGUAL | MODULO | MULTIPLICACAO | OR | PONTOEVIRGULA | PONTOPONTO | PRINT | REPEAT | RETURN | SOMA | SUBTRACAO | THEN | UNTIL | VIRGULA | WHILE ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, (p : (Ast.prefixexp))) = _menhir_stack in
            let _v : (Ast.exp) =                 ( Prefixexp(p) ) in
            _menhir_goto_exp _menhir_env _menhir_stack _menhir_s _v
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState43)
    | MenhirState0 | MenhirState203 | MenhirState29 | MenhirState30 | MenhirState184 | MenhirState181 | MenhirState115 | MenhirState175 | MenhirState140 | MenhirState144 | MenhirState156 | MenhirState150 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | ABRECHAVES ->
            _menhir_run37 _menhir_env (Obj.magic _menhir_stack) MenhirState152
        | ABRECOLCHETE ->
            _menhir_run50 _menhir_env (Obj.magic _menhir_stack) MenhirState152
        | ABREPARENTESE ->
            _menhir_run33 _menhir_env (Obj.magic _menhir_stack) MenhirState152
        | DOISPONTOS ->
            _menhir_run46 _menhir_env (Obj.magic _menhir_stack) MenhirState152
        | PONTO ->
            _menhir_run44 _menhir_env (Obj.magic _menhir_stack) MenhirState152
        | STRING _v ->
            _menhir_run32 _menhir_env (Obj.magic _menhir_stack) MenhirState152 _v
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState152)
    | _ ->
        _menhir_fail ()

and _menhir_goto_field : _menhir_env -> 'ttv_tail -> _menhir_state -> (Ast.field) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    match _menhir_s with
    | MenhirState37 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | PONTOEVIRGULA ->
            _menhir_run85 _menhir_env (Obj.magic _menhir_stack) MenhirState83
        | VIRGULA ->
            _menhir_run84 _menhir_env (Obj.magic _menhir_stack) MenhirState83
        | FECHACHAVES ->
            _menhir_reduce54 _menhir_env (Obj.magic _menhir_stack) MenhirState83
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState83)
    | MenhirState91 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_stack = Obj.magic _menhir_stack in
        let ((_menhir_stack, _menhir_s, (fs : (Ast.fieldsep))), _, (f : (Ast.field))) = _menhir_stack in
        let _v : (Ast.fieldsep_field_rule) =                         ( FieldSepField(fs,f)) in
        let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | PONTOEVIRGULA ->
            _menhir_run85 _menhir_env (Obj.magic _menhir_stack) MenhirState89
        | VIRGULA ->
            _menhir_run84 _menhir_env (Obj.magic _menhir_stack) MenhirState89
        | FECHACHAVES ->
            _menhir_reduce54 _menhir_env (Obj.magic _menhir_stack) MenhirState89
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState89)
    | _ ->
        _menhir_fail ()

and _menhir_run54 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _menhir_stack = Obj.magic _menhir_stack in
    let _1 = () in
    let _v : (Ast.binop) =               ( Subtracao ) in
    _menhir_goto_binop _menhir_env _menhir_stack _menhir_s _v

and _menhir_run55 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _menhir_stack = Obj.magic _menhir_stack in
    let _1 = () in
    let _v : (Ast.binop) =          ( Soma ) in
    _menhir_goto_binop _menhir_env _menhir_stack _menhir_s _v

and _menhir_run56 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _menhir_stack = Obj.magic _menhir_stack in
    let _1 = () in
    let _v : (Ast.binop) =                ( PontoPonto) in
    _menhir_goto_binop _menhir_env _menhir_stack _menhir_s _v

and _menhir_run57 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _menhir_stack = Obj.magic _menhir_stack in
    let _1 = () in
    let _v : (Ast.binop) =        ( Or) in
    _menhir_goto_binop _menhir_env _menhir_stack _menhir_s _v

and _menhir_run58 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _menhir_stack = Obj.magic _menhir_stack in
    let _1 = () in
    let _v : (Ast.binop) =                   ( Multiplicacao ) in
    _menhir_goto_binop _menhir_env _menhir_stack _menhir_s _v

and _menhir_run59 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _menhir_stack = Obj.magic _menhir_stack in
    let _1 = () in
    let _v : (Ast.binop) =            ( Modulo ) in
    _menhir_goto_binop _menhir_env _menhir_stack _menhir_s _v

and _menhir_run60 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _menhir_stack = Obj.magic _menhir_stack in
    let _1 = () in
    let _v : (Ast.binop) =                ( MenorIgual ) in
    _menhir_goto_binop _menhir_env _menhir_stack _menhir_s _v

and _menhir_run61 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _menhir_stack = Obj.magic _menhir_stack in
    let _1 = () in
    let _v : (Ast.binop) =           ( Menor) in
    _menhir_goto_binop _menhir_env _menhir_stack _menhir_s _v

and _menhir_run62 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _menhir_stack = Obj.magic _menhir_stack in
    let _1 = () in
    let _v : (Ast.binop) =                ( MaiorIgual) in
    _menhir_goto_binop _menhir_env _menhir_stack _menhir_s _v

and _menhir_run63 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _menhir_stack = Obj.magic _menhir_stack in
    let _1 = () in
    let _v : (Ast.binop) =           ( Maior) in
    _menhir_goto_binop _menhir_env _menhir_stack _menhir_s _v

and _menhir_run64 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _menhir_stack = Obj.magic _menhir_stack in
    let _1 = () in
    let _v : (Ast.binop) =               ( Igualdade) in
    _menhir_goto_binop _menhir_env _menhir_stack _menhir_s _v

and _menhir_run66 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _menhir_stack = Obj.magic _menhir_stack in
    let _1 = () in
    let _v : (Ast.binop) =                   ( Exponenciacao ) in
    _menhir_goto_binop _menhir_env _menhir_stack _menhir_s _v

and _menhir_run67 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _menhir_stack = Obj.magic _menhir_stack in
    let _1 = () in
    let _v : (Ast.binop) =             ( Divisao ) in
    _menhir_goto_binop _menhir_env _menhir_stack _menhir_s _v

and _menhir_run68 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _menhir_stack = Obj.magic _menhir_stack in
    let _1 = () in
    let _v : (Ast.binop) =               ( Diferente) in
    _menhir_goto_binop _menhir_env _menhir_stack _menhir_s _v

and _menhir_run69 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _menhir_stack = Obj.magic _menhir_stack in
    let _1 = () in
    let _v : (Ast.binop) =         ( And) in
    _menhir_goto_binop _menhir_env _menhir_stack _menhir_s _v

and _menhir_fail : unit -> 'a =
  fun () ->
    Printf.fprintf Pervasives.stderr "Internal failure -- please contact the parser generator's developers.\n%!";
    assert false

and _menhir_goto_option_retstat_ : _menhir_env -> 'ttv_tail -> (Ast.retstat option) -> 'ttv_return =
  fun _menhir_env _menhir_stack _v ->
    let _menhir_stack = Obj.magic _menhir_stack in
    let _menhir_stack = Obj.magic _menhir_stack in
    let (r : (Ast.retstat option)) = _v in
    let (_menhir_stack, _menhir_s, (s : (Ast.stat list))) = _menhir_stack in
    let _v : (Ast.block) =                        ( Block(s,r)) in
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    match _menhir_s with
    | MenhirState144 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | END ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_env = _menhir_discard _menhir_env in
            let _menhir_stack = Obj.magic _menhir_stack in
            let ((_menhir_stack, _menhir_s), _, (b : (Ast.block))) = _menhir_stack in
            let _3 = () in
            let _1 = () in
            let _v : (Ast.stat) =                    ( Do(b) ) in
            _menhir_goto_stat _menhir_env _menhir_stack _menhir_s _v
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | MenhirState140 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | END ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_env = _menhir_discard _menhir_env in
            let _menhir_stack = Obj.magic _menhir_stack in
            let ((((((((_menhir_stack, _menhir_s), _, (i : (string))), _), _, (e : (Ast.exp))), _), _, (ec : (Ast.exp))), _, (c : (Ast.comma_exp_rule option))), _, (b : (Ast.block))) = _menhir_stack in
            let _10 = () in
            let _8 = () in
            let _5 = () in
            let _3 = () in
            let _1 = () in
            let _v : (Ast.stat) =                                                                               ( For1(i, e, ec, c, b)) in
            _menhir_goto_stat _menhir_env _menhir_stack _menhir_s _v
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | MenhirState175 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | END ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_env = _menhir_discard _menhir_env in
            let _menhir_stack = Obj.magic _menhir_stack in
            let ((((_menhir_stack, _menhir_s), _, (n : (Ast.namelist))), _, (e : (Ast.explist))), _, (b : (Ast.block))) = _menhir_stack in
            let _7 = () in
            let _5 = () in
            let _3 = () in
            let _1 = () in
            let _v : (Ast.stat) =                                                ( For2(n, e, b) ) in
            _menhir_goto_stat _menhir_env _menhir_stack _menhir_s _v
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | MenhirState115 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | ELSEIF ->
            _menhir_run179 _menhir_env (Obj.magic _menhir_stack) MenhirState178
        | ELSE | END ->
            _menhir_reduce52 _menhir_env (Obj.magic _menhir_stack) MenhirState178
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState178)
    | MenhirState181 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_stack = Obj.magic _menhir_stack in
        let ((((_menhir_stack, _menhir_s), _, (e : (Ast.exp))), _), _, (b : (Ast.block))) = _menhir_stack in
        let _3 = () in
        let _1 = () in
        let _v : (Ast.elseif_rule) =                               ( Elseif(e,b) ) in
        let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | ELSEIF ->
            _menhir_run179 _menhir_env (Obj.magic _menhir_stack) MenhirState189
        | ELSE | END ->
            _menhir_reduce52 _menhir_env (Obj.magic _menhir_stack) MenhirState189
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState189)
    | MenhirState184 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _, (b : (Ast.block))) = _menhir_stack in
        let _1 = () in
        let _v : (Ast.else_block_rule) =                  ( Else(b) ) in
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_stack = Obj.magic _menhir_stack in
        let (x : (Ast.else_block_rule)) = _v in
        let _v : (Ast.else_block_rule option) =     ( Some x ) in
        _menhir_goto_option_else_block_rule_ _menhir_env _menhir_stack _v
    | MenhirState30 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | UNTIL ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            (match _tok with
            | ABRECHAVES ->
                _menhir_run37 _menhir_env (Obj.magic _menhir_stack) MenhirState192
            | ABREPARENTESE ->
                _menhir_run36 _menhir_env (Obj.magic _menhir_stack) MenhirState192
            | FALSE ->
                _menhir_run35 _menhir_env (Obj.magic _menhir_stack) MenhirState192
            | FLOAT _v ->
                _menhir_run34 _menhir_env (Obj.magic _menhir_stack) MenhirState192 _v
            | FUNCTION ->
                _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState192
            | ID _v ->
                _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState192 _v
            | INT _v ->
                _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState192 _v
            | NIL ->
                _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState192
            | NOT ->
                _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState192
            | PONTOPONTOPONTO ->
                _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState192
            | QUADRADO ->
                _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState192
            | STRING _v ->
                _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState192 _v
            | SUBTRACAO ->
                _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState192
            | TONUMBER ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState192
            | TRUE ->
                _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState192
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState192)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | MenhirState29 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | END ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_env = _menhir_discard _menhir_env in
            let _menhir_stack = Obj.magic _menhir_stack in
            let (((_menhir_stack, _menhir_s), _, (p : (Ast.parlist option))), _, (b : (Ast.block))) = _menhir_stack in
            let _5 = () in
            let _3 = () in
            let _1 = () in
            let _v : (Ast.funcbody) =                                                         ( Funcbody(p,b) ) in
            (match _menhir_s with
            | MenhirState129 ->
                let _menhir_stack = Obj.magic _menhir_stack in
                let _menhir_stack = Obj.magic _menhir_stack in
                let (fb : (Ast.funcbody)) = _v in
                let ((_menhir_stack, _menhir_s), (fn : (Ast.funcname))) = _menhir_stack in
                let _1 = () in
                let _v : (Ast.stat) =                                      ( Function(fn, fb) ) in
                _menhir_goto_stat _menhir_env _menhir_stack _menhir_s _v
            | MenhirState18 ->
                let _menhir_stack = Obj.magic _menhir_stack in
                let _menhir_stack = Obj.magic _menhir_stack in
                let (f : (Ast.funcbody)) = _v in
                let (_menhir_stack, _menhir_s) = _menhir_stack in
                let _1 = () in
                let _v : (Ast.functiondef) =                         ( FuncDef(f) ) in
                let _menhir_stack = Obj.magic _menhir_stack in
                let _menhir_stack = Obj.magic _menhir_stack in
                let (_1 : (Ast.functiondef)) = _v in
                let _v : (Ast.exp) =                 ( FunctionDef ) in
                _menhir_goto_exp _menhir_env _menhir_stack _menhir_s _v
            | _ ->
                _menhir_fail ())
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | MenhirState203 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | END ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_env = _menhir_discard _menhir_env in
            let _menhir_stack = Obj.magic _menhir_stack in
            let ((((_menhir_stack, _menhir_s), _, (e : (Ast.exp))), _), _, (b : (Ast.block))) = _menhir_stack in
            let _5 = () in
            let _3 = () in
            let _1 = () in
            let _v : (Ast.stat) =                                ( While(e,b)) in
            _menhir_goto_stat _menhir_env _menhir_stack _menhir_s _v
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | MenhirState0 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | EOF ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, (b : (Ast.block))) = _menhir_stack in
            let _2 = () in
            let _v : (Ast.program) =                 ( Program(b) ) in
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_1 : (Ast.program)) = _v in
            Obj.magic _1
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | _ ->
        _menhir_fail ()

and _menhir_goto_args : _menhir_env -> 'ttv_tail -> _menhir_state -> (Ast.args) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    match _menhir_s with
    | MenhirState47 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_stack = Obj.magic _menhir_stack in
        let (a : (Ast.args)) = _v in
        let (((_menhir_stack, _menhir_s, (p : (Ast.prefixexp))), _), (i : (string))) = _menhir_stack in
        let _2 = () in
        let _v : (Ast.functioncall) =                                        ( PrefixoDoisPontosIdArgs(p, i, a) ) in
        _menhir_goto_functioncall _menhir_env _menhir_stack _menhir_s _v
    | MenhirState152 | MenhirState43 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_stack = Obj.magic _menhir_stack in
        let (a : (Ast.args)) = _v in
        let (_menhir_stack, _menhir_s, (p : (Ast.prefixexp))) = _menhir_stack in
        let _v : (Ast.functioncall) =                        ( PrefixexpArgs(p,a) ) in
        _menhir_goto_functioncall _menhir_env _menhir_stack _menhir_s _v
    | MenhirState31 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_stack = Obj.magic _menhir_stack in
        let (a : (Ast.args)) = _v in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        let _1 = () in
        let _v : (Ast.stat) =                  ( Print(a) ) in
        _menhir_goto_stat _menhir_env _menhir_stack _menhir_s _v
    | _ ->
        _menhir_fail ()

and _menhir_reduce77 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _v : (Ast.explist option) =     ( None ) in
    _menhir_goto_option_explist_ _menhir_env _menhir_stack _menhir_s _v

and _menhir_goto_var : _menhir_env -> 'ttv_tail -> _menhir_state -> (Ast.var) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    match _menhir_s with
    | MenhirState1 | MenhirState192 | MenhirState179 | MenhirState173 | MenhirState161 | MenhirState147 | MenhirState137 | MenhirState135 | MenhirState133 | MenhirState113 | MenhirState109 | MenhirState100 | MenhirState33 | MenhirState36 | MenhirState91 | MenhirState37 | MenhirState78 | MenhirState75 | MenhirState70 | MenhirState50 | MenhirState41 | MenhirState39 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        _menhir_reduce92 _menhir_env (Obj.magic _menhir_stack)
    | MenhirState0 | MenhirState203 | MenhirState29 | MenhirState30 | MenhirState184 | MenhirState181 | MenhirState115 | MenhirState175 | MenhirState140 | MenhirState156 | MenhirState144 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | VIRGULA ->
            _menhir_run150 _menhir_env (Obj.magic _menhir_stack) MenhirState149
        | ABRECHAVES | ABRECOLCHETE | ABREPARENTESE | DOISPONTOS | PONTO | STRING _ ->
            _menhir_reduce92 _menhir_env (Obj.magic _menhir_stack)
        | ATRIBUICAO ->
            _menhir_reduce64 _menhir_env (Obj.magic _menhir_stack) MenhirState149
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState149)
    | MenhirState150 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | ATRIBUICAO | VIRGULA ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let ((_menhir_stack, _menhir_s), _, (v : (Ast.var))) = _menhir_stack in
            let _1 = () in
            let _v : (Ast.virgula_var_rule) =                   ( VirgulaVarRule(v) ) in
            let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
            let _menhir_stack = Obj.magic _menhir_stack in
            assert (not _menhir_env._menhir_error);
            let _tok = _menhir_env._menhir_token in
            (match _tok with
            | VIRGULA ->
                _menhir_run150 _menhir_env (Obj.magic _menhir_stack) MenhirState153
            | ATRIBUICAO ->
                _menhir_reduce64 _menhir_env (Obj.magic _menhir_stack) MenhirState153
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState153)
        | ABRECHAVES | ABRECOLCHETE | ABREPARENTESE | DOISPONTOS | PONTO | STRING _ ->
            _menhir_reduce92 _menhir_env (Obj.magic _menhir_stack)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | _ ->
        _menhir_fail ()

and _menhir_goto_list_ponto_id_rule_ : _menhir_env -> 'ttv_tail -> _menhir_state -> (Ast.ponto_id_rule list) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    match _menhir_s with
    | MenhirState122 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_stack = Obj.magic _menhir_stack in
        let ((_menhir_stack, _menhir_s, (x : (Ast.ponto_id_rule))), _, (xs : (Ast.ponto_id_rule list))) = _menhir_stack in
        let _v : (Ast.ponto_id_rule list) =     ( x :: xs ) in
        _menhir_goto_list_ponto_id_rule_ _menhir_env _menhir_stack _menhir_s _v
    | MenhirState119 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | DOISPONTOS ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            (match _tok with
            | ID _v ->
                let _menhir_stack = Obj.magic _menhir_stack in
                let _menhir_env = _menhir_discard _menhir_env in
                let _menhir_stack = Obj.magic _menhir_stack in
                let (i : (string)) = _v in
                let _1 = () in
                let _v : (Ast.doispontos_id_rule) =                     ( Doispontos(i) ) in
                let _menhir_stack = Obj.magic _menhir_stack in
                let _menhir_stack = Obj.magic _menhir_stack in
                let (x : (Ast.doispontos_id_rule)) = _v in
                let _v : (Ast.doispontos_id_rule option) =     ( Some x ) in
                _menhir_goto_option_doispontos_id_rule_ _menhir_env _menhir_stack _v
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                let _menhir_stack = Obj.magic _menhir_stack in
                raise _eRR)
        | ABREPARENTESE ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _v : (Ast.doispontos_id_rule option) =     ( None ) in
            _menhir_goto_option_doispontos_id_rule_ _menhir_env _menhir_stack _v
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | _ ->
        _menhir_fail ()

and _menhir_goto_list_virgula_id_rule_ : _menhir_env -> 'ttv_tail -> _menhir_state -> (Ast.virgula_id_rule list) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    match _menhir_s with
    | MenhirState24 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_stack = Obj.magic _menhir_stack in
        let (xs : (Ast.virgula_id_rule list)) = _v in
        let (_menhir_stack, _menhir_s, (x : (Ast.virgula_id_rule))) = _menhir_stack in
        let _v : (Ast.virgula_id_rule list) =     ( x :: xs ) in
        _menhir_goto_list_virgula_id_rule_ _menhir_env _menhir_stack _menhir_s _v
    | MenhirState132 | MenhirState21 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_stack = Obj.magic _menhir_stack in
        let (v : (Ast.virgula_id_rule list)) = _v in
        let (_menhir_stack, _menhir_s, (i : (string))) = _menhir_stack in
        let _v : (Ast.namelist) =                             ( Namelist(i,v) ) in
        let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
        (match _menhir_s with
        | MenhirState107 ->
            let _menhir_stack = Obj.magic _menhir_stack in
            assert (not _menhir_env._menhir_error);
            let _tok = _menhir_env._menhir_token in
            (match _tok with
            | ATRIBUICAO ->
                let _menhir_stack = Obj.magic _menhir_stack in
                let _menhir_env = _menhir_discard _menhir_env in
                let _tok = _menhir_env._menhir_token in
                (match _tok with
                | ABRECHAVES ->
                    _menhir_run37 _menhir_env (Obj.magic _menhir_stack) MenhirState109
                | ABREPARENTESE ->
                    _menhir_run36 _menhir_env (Obj.magic _menhir_stack) MenhirState109
                | FALSE ->
                    _menhir_run35 _menhir_env (Obj.magic _menhir_stack) MenhirState109
                | FLOAT _v ->
                    _menhir_run34 _menhir_env (Obj.magic _menhir_stack) MenhirState109 _v
                | FUNCTION ->
                    _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState109
                | ID _v ->
                    _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState109 _v
                | INT _v ->
                    _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState109 _v
                | NIL ->
                    _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState109
                | NOT ->
                    _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState109
                | PONTOPONTOPONTO ->
                    _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState109
                | QUADRADO ->
                    _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState109
                | STRING _v ->
                    _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState109 _v
                | SUBTRACAO ->
                    _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState109
                | TONUMBER ->
                    _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState109
                | TRUE ->
                    _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState109
                | _ ->
                    assert (not _menhir_env._menhir_error);
                    _menhir_env._menhir_error <- true;
                    _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState109)
            | ABREPARENTESE | BREAK | DO | DOISDOISPONTOS | ELSE | ELSEIF | END | EOF | FOR | FUNCTION | GOTO | ID _ | IF | LOCAL | PONTOEVIRGULA | PRINT | REPEAT | RETURN | UNTIL | WHILE ->
                let _menhir_stack = Obj.magic _menhir_stack in
                let _v : (Ast.atribuicao_explist_rule option) =     ( None ) in
                _menhir_goto_option_atribuicao_explist_rule_ _menhir_env _menhir_stack _v
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                let _menhir_stack = Obj.magic _menhir_stack in
                let (_menhir_stack, _menhir_s, _) = _menhir_stack in
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
        | MenhirState131 ->
            let _menhir_stack = Obj.magic _menhir_stack in
            assert (not _menhir_env._menhir_error);
            let _tok = _menhir_env._menhir_token in
            (match _tok with
            | IN ->
                let _menhir_stack = Obj.magic _menhir_stack in
                let _menhir_env = _menhir_discard _menhir_env in
                let _tok = _menhir_env._menhir_token in
                (match _tok with
                | ABRECHAVES ->
                    _menhir_run37 _menhir_env (Obj.magic _menhir_stack) MenhirState173
                | ABREPARENTESE ->
                    _menhir_run36 _menhir_env (Obj.magic _menhir_stack) MenhirState173
                | FALSE ->
                    _menhir_run35 _menhir_env (Obj.magic _menhir_stack) MenhirState173
                | FLOAT _v ->
                    _menhir_run34 _menhir_env (Obj.magic _menhir_stack) MenhirState173 _v
                | FUNCTION ->
                    _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState173
                | ID _v ->
                    _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState173 _v
                | INT _v ->
                    _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState173 _v
                | NIL ->
                    _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState173
                | NOT ->
                    _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState173
                | PONTOPONTOPONTO ->
                    _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState173
                | QUADRADO ->
                    _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState173
                | STRING _v ->
                    _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState173 _v
                | SUBTRACAO ->
                    _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState173
                | TONUMBER ->
                    _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState173
                | TRUE ->
                    _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState173
                | _ ->
                    assert (not _menhir_env._menhir_error);
                    _menhir_env._menhir_error <- true;
                    _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState173)
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                let _menhir_stack = Obj.magic _menhir_stack in
                let (_menhir_stack, _menhir_s, _) = _menhir_stack in
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
        | MenhirState19 ->
            let _menhir_stack = Obj.magic _menhir_stack in
            assert (not _menhir_env._menhir_error);
            let _tok = _menhir_env._menhir_token in
            (match _tok with
            | VIRGULA ->
                let _menhir_stack = Obj.magic _menhir_stack in
                let _menhir_env = _menhir_discard _menhir_env in
                let _tok = _menhir_env._menhir_token in
                (match _tok with
                | PONTOPONTOPONTO ->
                    let _menhir_stack = Obj.magic _menhir_stack in
                    let _menhir_env = _menhir_discard _menhir_env in
                    let _menhir_stack = Obj.magic _menhir_stack in
                    let _2 = () in
                    let _1 = () in
                    let _v : (Ast.virgula_tres_pontos_rule) =                             (  VirgulaPPP ) in
                    let _menhir_stack = Obj.magic _menhir_stack in
                    let _menhir_stack = Obj.magic _menhir_stack in
                    let (x : (Ast.virgula_tres_pontos_rule)) = _v in
                    let _v : (Ast.virgula_tres_pontos_rule option) =     ( Some x ) in
                    _menhir_goto_option_virgula_tres_pontos_rule_ _menhir_env _menhir_stack _v
                | _ ->
                    assert (not _menhir_env._menhir_error);
                    _menhir_env._menhir_error <- true;
                    let _menhir_stack = Obj.magic _menhir_stack in
                    raise _eRR)
            | FECHAPARENTESE ->
                let _menhir_stack = Obj.magic _menhir_stack in
                let _v : (Ast.virgula_tres_pontos_rule option) =     ( None ) in
                _menhir_goto_option_virgula_tres_pontos_rule_ _menhir_env _menhir_stack _v
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                let _menhir_stack = Obj.magic _menhir_stack in
                let (_menhir_stack, _menhir_s, _) = _menhir_stack in
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
        | _ ->
            _menhir_fail ())
    | _ ->
        _menhir_fail ()

and _menhir_goto_unop : _menhir_env -> 'ttv_tail -> _menhir_state -> (Ast.unop) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    let _menhir_stack = Obj.magic _menhir_stack in
    assert (not _menhir_env._menhir_error);
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ABRECHAVES ->
        _menhir_run37 _menhir_env (Obj.magic _menhir_stack) MenhirState41
    | ABREPARENTESE ->
        _menhir_run36 _menhir_env (Obj.magic _menhir_stack) MenhirState41
    | FALSE ->
        _menhir_run35 _menhir_env (Obj.magic _menhir_stack) MenhirState41
    | FLOAT _v ->
        _menhir_run34 _menhir_env (Obj.magic _menhir_stack) MenhirState41 _v
    | FUNCTION ->
        _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState41
    | ID _v ->
        _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState41 _v
    | INT _v ->
        _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState41 _v
    | NIL ->
        _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState41
    | NOT ->
        _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState41
    | PONTOPONTOPONTO ->
        _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState41
    | QUADRADO ->
        _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState41
    | STRING _v ->
        _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState41 _v
    | SUBTRACAO ->
        _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState41
    | TONUMBER ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState41
    | TRUE ->
        _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState41
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState41

and _menhir_run19 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ID _v ->
        _menhir_run21 _menhir_env (Obj.magic _menhir_stack) MenhirState19 _v
    | PONTOPONTOPONTO ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_s = MenhirState19 in
        let _menhir_env = _menhir_discard _menhir_env in
        let _menhir_stack = Obj.magic _menhir_stack in
        let _1 = () in
        let _v : (Ast.parlist) =                     ( PontoPontoPonto) in
        _menhir_goto_parlist _menhir_env _menhir_stack _menhir_s _v
    | FECHAPARENTESE ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_s = MenhirState19 in
        let _v : (Ast.parlist option) =     ( None ) in
        _menhir_goto_option_parlist_ _menhir_env _menhir_stack _menhir_s _v
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState19

and _menhir_goto_exp : _menhir_env -> 'ttv_tail -> _menhir_state -> (Ast.exp) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    match _menhir_s with
    | MenhirState50 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | AND ->
            _menhir_run69 _menhir_env (Obj.magic _menhir_stack) MenhirState53
        | DIFERENTE ->
            _menhir_run68 _menhir_env (Obj.magic _menhir_stack) MenhirState53
        | DIVISAO ->
            _menhir_run67 _menhir_env (Obj.magic _menhir_stack) MenhirState53
        | EXPONENCIACAO ->
            _menhir_run66 _menhir_env (Obj.magic _menhir_stack) MenhirState53
        | FECHACOLCHETE ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_s = MenhirState53 in
            let _menhir_env = _menhir_discard _menhir_env in
            let _menhir_stack = Obj.magic _menhir_stack in
            let (((_menhir_stack, _menhir_s, (p : (Ast.prefixexp))), _), _, (e : (Ast.exp))) = _menhir_stack in
            let _4 = () in
            let _2 = () in
            let _v : (Ast.var) =                                                  ( Varcol(p,e) ) in
            _menhir_goto_var _menhir_env _menhir_stack _menhir_s _v
        | IGUALDADE ->
            _menhir_run64 _menhir_env (Obj.magic _menhir_stack) MenhirState53
        | MAIOR ->
            _menhir_run63 _menhir_env (Obj.magic _menhir_stack) MenhirState53
        | MAIORIGUAL ->
            _menhir_run62 _menhir_env (Obj.magic _menhir_stack) MenhirState53
        | MENOR ->
            _menhir_run61 _menhir_env (Obj.magic _menhir_stack) MenhirState53
        | MENORIGUAL ->
            _menhir_run60 _menhir_env (Obj.magic _menhir_stack) MenhirState53
        | MODULO ->
            _menhir_run59 _menhir_env (Obj.magic _menhir_stack) MenhirState53
        | MULTIPLICACAO ->
            _menhir_run58 _menhir_env (Obj.magic _menhir_stack) MenhirState53
        | OR ->
            _menhir_run57 _menhir_env (Obj.magic _menhir_stack) MenhirState53
        | PONTOPONTO ->
            _menhir_run56 _menhir_env (Obj.magic _menhir_stack) MenhirState53
        | SOMA ->
            _menhir_run55 _menhir_env (Obj.magic _menhir_stack) MenhirState53
        | SUBTRACAO ->
            _menhir_run54 _menhir_env (Obj.magic _menhir_stack) MenhirState53
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState53)
    | MenhirState70 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | AND ->
            _menhir_run69 _menhir_env (Obj.magic _menhir_stack) MenhirState71
        | DIFERENTE ->
            _menhir_run68 _menhir_env (Obj.magic _menhir_stack) MenhirState71
        | DIVISAO ->
            _menhir_run67 _menhir_env (Obj.magic _menhir_stack) MenhirState71
        | EXPONENCIACAO ->
            _menhir_run66 _menhir_env (Obj.magic _menhir_stack) MenhirState71
        | IGUALDADE ->
            _menhir_run64 _menhir_env (Obj.magic _menhir_stack) MenhirState71
        | MAIOR ->
            _menhir_run63 _menhir_env (Obj.magic _menhir_stack) MenhirState71
        | MAIORIGUAL ->
            _menhir_run62 _menhir_env (Obj.magic _menhir_stack) MenhirState71
        | MENOR ->
            _menhir_run61 _menhir_env (Obj.magic _menhir_stack) MenhirState71
        | MENORIGUAL ->
            _menhir_run60 _menhir_env (Obj.magic _menhir_stack) MenhirState71
        | MODULO ->
            _menhir_run59 _menhir_env (Obj.magic _menhir_stack) MenhirState71
        | MULTIPLICACAO ->
            _menhir_run58 _menhir_env (Obj.magic _menhir_stack) MenhirState71
        | OR ->
            _menhir_run57 _menhir_env (Obj.magic _menhir_stack) MenhirState71
        | PONTOPONTO ->
            _menhir_run56 _menhir_env (Obj.magic _menhir_stack) MenhirState71
        | SOMA ->
            _menhir_run55 _menhir_env (Obj.magic _menhir_stack) MenhirState71
        | SUBTRACAO ->
            _menhir_run54 _menhir_env (Obj.magic _menhir_stack) MenhirState71
        | ABREPARENTESE | BREAK | DO | DOISDOISPONTOS | ELSE | ELSEIF | END | EOF | FECHACHAVES | FECHACOLCHETE | FECHAPARENTESE | FOR | FUNCTION | GOTO | ID _ | IF | LOCAL | PONTOEVIRGULA | PRINT | REPEAT | RETURN | THEN | UNTIL | VIRGULA | WHILE ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let (((_menhir_stack, _menhir_s, (e : (Ast.exp))), _, (b : (Ast.binop))), _, (e2 : (Ast.exp))) = _menhir_stack in
            let _v : (Ast.exp) =                          ( ExpressaoBinaria(e, b, e2) ) in
            _menhir_goto_exp _menhir_env _menhir_stack _menhir_s _v
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState71)
    | MenhirState41 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | AND ->
            _menhir_run69 _menhir_env (Obj.magic _menhir_stack) MenhirState73
        | DIFERENTE ->
            _menhir_run68 _menhir_env (Obj.magic _menhir_stack) MenhirState73
        | DIVISAO ->
            _menhir_run67 _menhir_env (Obj.magic _menhir_stack) MenhirState73
        | EXPONENCIACAO ->
            _menhir_run66 _menhir_env (Obj.magic _menhir_stack) MenhirState73
        | IGUALDADE ->
            _menhir_run64 _menhir_env (Obj.magic _menhir_stack) MenhirState73
        | MAIOR ->
            _menhir_run63 _menhir_env (Obj.magic _menhir_stack) MenhirState73
        | MAIORIGUAL ->
            _menhir_run62 _menhir_env (Obj.magic _menhir_stack) MenhirState73
        | MENOR ->
            _menhir_run61 _menhir_env (Obj.magic _menhir_stack) MenhirState73
        | MENORIGUAL ->
            _menhir_run60 _menhir_env (Obj.magic _menhir_stack) MenhirState73
        | MODULO ->
            _menhir_run59 _menhir_env (Obj.magic _menhir_stack) MenhirState73
        | MULTIPLICACAO ->
            _menhir_run58 _menhir_env (Obj.magic _menhir_stack) MenhirState73
        | OR ->
            _menhir_run57 _menhir_env (Obj.magic _menhir_stack) MenhirState73
        | PONTOPONTO ->
            _menhir_run56 _menhir_env (Obj.magic _menhir_stack) MenhirState73
        | SOMA ->
            _menhir_run55 _menhir_env (Obj.magic _menhir_stack) MenhirState73
        | SUBTRACAO ->
            _menhir_run54 _menhir_env (Obj.magic _menhir_stack) MenhirState73
        | ABREPARENTESE | BREAK | DO | DOISDOISPONTOS | ELSE | ELSEIF | END | EOF | FECHACHAVES | FECHACOLCHETE | FECHAPARENTESE | FOR | FUNCTION | GOTO | ID _ | IF | LOCAL | PONTOEVIRGULA | PRINT | REPEAT | RETURN | THEN | UNTIL | VIRGULA | WHILE ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let ((_menhir_stack, _menhir_s, (u : (Ast.unop))), _, (e : (Ast.exp))) = _menhir_stack in
            let _v : (Ast.exp) =                  ( ExpressaoUnaria(u,e)) in
            _menhir_goto_exp _menhir_env _menhir_stack _menhir_s _v
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState73)
    | MenhirState39 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | AND ->
            _menhir_run69 _menhir_env (Obj.magic _menhir_stack) MenhirState74
        | DIFERENTE ->
            _menhir_run68 _menhir_env (Obj.magic _menhir_stack) MenhirState74
        | DIVISAO ->
            _menhir_run67 _menhir_env (Obj.magic _menhir_stack) MenhirState74
        | EXPONENCIACAO ->
            _menhir_run66 _menhir_env (Obj.magic _menhir_stack) MenhirState74
        | IGUALDADE ->
            _menhir_run64 _menhir_env (Obj.magic _menhir_stack) MenhirState74
        | MAIOR ->
            _menhir_run63 _menhir_env (Obj.magic _menhir_stack) MenhirState74
        | MAIORIGUAL ->
            _menhir_run62 _menhir_env (Obj.magic _menhir_stack) MenhirState74
        | MENOR ->
            _menhir_run61 _menhir_env (Obj.magic _menhir_stack) MenhirState74
        | MENORIGUAL ->
            _menhir_run60 _menhir_env (Obj.magic _menhir_stack) MenhirState74
        | MODULO ->
            _menhir_run59 _menhir_env (Obj.magic _menhir_stack) MenhirState74
        | MULTIPLICACAO ->
            _menhir_run58 _menhir_env (Obj.magic _menhir_stack) MenhirState74
        | OR ->
            _menhir_run57 _menhir_env (Obj.magic _menhir_stack) MenhirState74
        | PONTOPONTO ->
            _menhir_run56 _menhir_env (Obj.magic _menhir_stack) MenhirState74
        | SOMA ->
            _menhir_run55 _menhir_env (Obj.magic _menhir_stack) MenhirState74
        | SUBTRACAO ->
            _menhir_run54 _menhir_env (Obj.magic _menhir_stack) MenhirState74
        | FECHACHAVES | PONTOEVIRGULA | VIRGULA ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let ((_menhir_stack, _menhir_s, (i : (string))), _, (e : (Ast.exp))) = _menhir_stack in
            let _2 = () in
            let _v : (Ast.field) =                           ( Campo2(i,e) ) in
            _menhir_goto_field _menhir_env _menhir_stack _menhir_s _v
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState74)
    | MenhirState75 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | AND ->
            _menhir_run69 _menhir_env (Obj.magic _menhir_stack) MenhirState76
        | DIFERENTE ->
            _menhir_run68 _menhir_env (Obj.magic _menhir_stack) MenhirState76
        | DIVISAO ->
            _menhir_run67 _menhir_env (Obj.magic _menhir_stack) MenhirState76
        | EXPONENCIACAO ->
            _menhir_run66 _menhir_env (Obj.magic _menhir_stack) MenhirState76
        | FECHACOLCHETE ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_s = MenhirState76 in
            let _menhir_stack = (_menhir_stack, _menhir_s) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            (match _tok with
            | ATRIBUICAO ->
                let _menhir_stack = Obj.magic _menhir_stack in
                let _menhir_env = _menhir_discard _menhir_env in
                let _tok = _menhir_env._menhir_token in
                (match _tok with
                | ABRECHAVES ->
                    _menhir_run37 _menhir_env (Obj.magic _menhir_stack) MenhirState78
                | ABREPARENTESE ->
                    _menhir_run36 _menhir_env (Obj.magic _menhir_stack) MenhirState78
                | FALSE ->
                    _menhir_run35 _menhir_env (Obj.magic _menhir_stack) MenhirState78
                | FLOAT _v ->
                    _menhir_run34 _menhir_env (Obj.magic _menhir_stack) MenhirState78 _v
                | FUNCTION ->
                    _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState78
                | ID _v ->
                    _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState78 _v
                | INT _v ->
                    _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState78 _v
                | NIL ->
                    _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState78
                | NOT ->
                    _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState78
                | PONTOPONTOPONTO ->
                    _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState78
                | QUADRADO ->
                    _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState78
                | STRING _v ->
                    _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState78 _v
                | SUBTRACAO ->
                    _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState78
                | TONUMBER ->
                    _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState78
                | TRUE ->
                    _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState78
                | _ ->
                    assert (not _menhir_env._menhir_error);
                    _menhir_env._menhir_error <- true;
                    _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState78)
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                let _menhir_stack = Obj.magic _menhir_stack in
                let (_menhir_stack, _menhir_s) = _menhir_stack in
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
        | IGUALDADE ->
            _menhir_run64 _menhir_env (Obj.magic _menhir_stack) MenhirState76
        | MAIOR ->
            _menhir_run63 _menhir_env (Obj.magic _menhir_stack) MenhirState76
        | MAIORIGUAL ->
            _menhir_run62 _menhir_env (Obj.magic _menhir_stack) MenhirState76
        | MENOR ->
            _menhir_run61 _menhir_env (Obj.magic _menhir_stack) MenhirState76
        | MENORIGUAL ->
            _menhir_run60 _menhir_env (Obj.magic _menhir_stack) MenhirState76
        | MODULO ->
            _menhir_run59 _menhir_env (Obj.magic _menhir_stack) MenhirState76
        | MULTIPLICACAO ->
            _menhir_run58 _menhir_env (Obj.magic _menhir_stack) MenhirState76
        | OR ->
            _menhir_run57 _menhir_env (Obj.magic _menhir_stack) MenhirState76
        | PONTOPONTO ->
            _menhir_run56 _menhir_env (Obj.magic _menhir_stack) MenhirState76
        | SOMA ->
            _menhir_run55 _menhir_env (Obj.magic _menhir_stack) MenhirState76
        | SUBTRACAO ->
            _menhir_run54 _menhir_env (Obj.magic _menhir_stack) MenhirState76
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState76)
    | MenhirState78 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | AND ->
            _menhir_run69 _menhir_env (Obj.magic _menhir_stack) MenhirState79
        | DIFERENTE ->
            _menhir_run68 _menhir_env (Obj.magic _menhir_stack) MenhirState79
        | DIVISAO ->
            _menhir_run67 _menhir_env (Obj.magic _menhir_stack) MenhirState79
        | EXPONENCIACAO ->
            _menhir_run66 _menhir_env (Obj.magic _menhir_stack) MenhirState79
        | IGUALDADE ->
            _menhir_run64 _menhir_env (Obj.magic _menhir_stack) MenhirState79
        | MAIOR ->
            _menhir_run63 _menhir_env (Obj.magic _menhir_stack) MenhirState79
        | MAIORIGUAL ->
            _menhir_run62 _menhir_env (Obj.magic _menhir_stack) MenhirState79
        | MENOR ->
            _menhir_run61 _menhir_env (Obj.magic _menhir_stack) MenhirState79
        | MENORIGUAL ->
            _menhir_run60 _menhir_env (Obj.magic _menhir_stack) MenhirState79
        | MODULO ->
            _menhir_run59 _menhir_env (Obj.magic _menhir_stack) MenhirState79
        | MULTIPLICACAO ->
            _menhir_run58 _menhir_env (Obj.magic _menhir_stack) MenhirState79
        | OR ->
            _menhir_run57 _menhir_env (Obj.magic _menhir_stack) MenhirState79
        | PONTOPONTO ->
            _menhir_run56 _menhir_env (Obj.magic _menhir_stack) MenhirState79
        | SOMA ->
            _menhir_run55 _menhir_env (Obj.magic _menhir_stack) MenhirState79
        | SUBTRACAO ->
            _menhir_run54 _menhir_env (Obj.magic _menhir_stack) MenhirState79
        | FECHACHAVES | PONTOEVIRGULA | VIRGULA ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let ((((_menhir_stack, _menhir_s), _, (e1 : (Ast.exp))), _), _, (e2 : (Ast.exp))) = _menhir_stack in
            let _4 = () in
            let _3 = () in
            let _1 = () in
            let _v : (Ast.field) =                                                         ( Campo1(e1,e2)) in
            _menhir_goto_field _menhir_env _menhir_stack _menhir_s _v
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState79)
    | MenhirState37 | MenhirState91 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | AND ->
            _menhir_run69 _menhir_env (Obj.magic _menhir_stack) MenhirState93
        | DIFERENTE ->
            _menhir_run68 _menhir_env (Obj.magic _menhir_stack) MenhirState93
        | DIVISAO ->
            _menhir_run67 _menhir_env (Obj.magic _menhir_stack) MenhirState93
        | EXPONENCIACAO ->
            _menhir_run66 _menhir_env (Obj.magic _menhir_stack) MenhirState93
        | IGUALDADE ->
            _menhir_run64 _menhir_env (Obj.magic _menhir_stack) MenhirState93
        | MAIOR ->
            _menhir_run63 _menhir_env (Obj.magic _menhir_stack) MenhirState93
        | MAIORIGUAL ->
            _menhir_run62 _menhir_env (Obj.magic _menhir_stack) MenhirState93
        | MENOR ->
            _menhir_run61 _menhir_env (Obj.magic _menhir_stack) MenhirState93
        | MENORIGUAL ->
            _menhir_run60 _menhir_env (Obj.magic _menhir_stack) MenhirState93
        | MODULO ->
            _menhir_run59 _menhir_env (Obj.magic _menhir_stack) MenhirState93
        | MULTIPLICACAO ->
            _menhir_run58 _menhir_env (Obj.magic _menhir_stack) MenhirState93
        | OR ->
            _menhir_run57 _menhir_env (Obj.magic _menhir_stack) MenhirState93
        | PONTOPONTO ->
            _menhir_run56 _menhir_env (Obj.magic _menhir_stack) MenhirState93
        | SOMA ->
            _menhir_run55 _menhir_env (Obj.magic _menhir_stack) MenhirState93
        | SUBTRACAO ->
            _menhir_run54 _menhir_env (Obj.magic _menhir_stack) MenhirState93
        | FECHACHAVES | PONTOEVIRGULA | VIRGULA ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, (e : (Ast.exp))) = _menhir_stack in
            let _v : (Ast.field) =           ( Campo3(e) ) in
            _menhir_goto_field _menhir_env _menhir_stack _menhir_s _v
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState93)
    | MenhirState36 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | AND ->
            _menhir_run69 _menhir_env (Obj.magic _menhir_stack) MenhirState94
        | DIFERENTE ->
            _menhir_run68 _menhir_env (Obj.magic _menhir_stack) MenhirState94
        | DIVISAO ->
            _menhir_run67 _menhir_env (Obj.magic _menhir_stack) MenhirState94
        | EXPONENCIACAO ->
            _menhir_run66 _menhir_env (Obj.magic _menhir_stack) MenhirState94
        | FECHAPARENTESE ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_s = MenhirState94 in
            let _menhir_env = _menhir_discard _menhir_env in
            let _menhir_stack = Obj.magic _menhir_stack in
            let ((_menhir_stack, _menhir_s), _, (e : (Ast.exp))) = _menhir_stack in
            let _3 = () in
            let _1 = () in
            let _v : (Ast.prefixexp) =                                        ( ExpressaoParentese(e) ) in
            _menhir_goto_prefixexp _menhir_env _menhir_stack _menhir_s _v
        | IGUALDADE ->
            _menhir_run64 _menhir_env (Obj.magic _menhir_stack) MenhirState94
        | MAIOR ->
            _menhir_run63 _menhir_env (Obj.magic _menhir_stack) MenhirState94
        | MAIORIGUAL ->
            _menhir_run62 _menhir_env (Obj.magic _menhir_stack) MenhirState94
        | MENOR ->
            _menhir_run61 _menhir_env (Obj.magic _menhir_stack) MenhirState94
        | MENORIGUAL ->
            _menhir_run60 _menhir_env (Obj.magic _menhir_stack) MenhirState94
        | MODULO ->
            _menhir_run59 _menhir_env (Obj.magic _menhir_stack) MenhirState94
        | MULTIPLICACAO ->
            _menhir_run58 _menhir_env (Obj.magic _menhir_stack) MenhirState94
        | OR ->
            _menhir_run57 _menhir_env (Obj.magic _menhir_stack) MenhirState94
        | PONTOPONTO ->
            _menhir_run56 _menhir_env (Obj.magic _menhir_stack) MenhirState94
        | SOMA ->
            _menhir_run55 _menhir_env (Obj.magic _menhir_stack) MenhirState94
        | SUBTRACAO ->
            _menhir_run54 _menhir_env (Obj.magic _menhir_stack) MenhirState94
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState94)
    | MenhirState173 | MenhirState161 | MenhirState147 | MenhirState109 | MenhirState33 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | AND ->
            _menhir_run69 _menhir_env (Obj.magic _menhir_stack) MenhirState99
        | DIFERENTE ->
            _menhir_run68 _menhir_env (Obj.magic _menhir_stack) MenhirState99
        | DIVISAO ->
            _menhir_run67 _menhir_env (Obj.magic _menhir_stack) MenhirState99
        | EXPONENCIACAO ->
            _menhir_run66 _menhir_env (Obj.magic _menhir_stack) MenhirState99
        | IGUALDADE ->
            _menhir_run64 _menhir_env (Obj.magic _menhir_stack) MenhirState99
        | MAIOR ->
            _menhir_run63 _menhir_env (Obj.magic _menhir_stack) MenhirState99
        | MAIORIGUAL ->
            _menhir_run62 _menhir_env (Obj.magic _menhir_stack) MenhirState99
        | MENOR ->
            _menhir_run61 _menhir_env (Obj.magic _menhir_stack) MenhirState99
        | MENORIGUAL ->
            _menhir_run60 _menhir_env (Obj.magic _menhir_stack) MenhirState99
        | MODULO ->
            _menhir_run59 _menhir_env (Obj.magic _menhir_stack) MenhirState99
        | MULTIPLICACAO ->
            _menhir_run58 _menhir_env (Obj.magic _menhir_stack) MenhirState99
        | OR ->
            _menhir_run57 _menhir_env (Obj.magic _menhir_stack) MenhirState99
        | PONTOPONTO ->
            _menhir_run56 _menhir_env (Obj.magic _menhir_stack) MenhirState99
        | SOMA ->
            _menhir_run55 _menhir_env (Obj.magic _menhir_stack) MenhirState99
        | SUBTRACAO ->
            _menhir_run54 _menhir_env (Obj.magic _menhir_stack) MenhirState99
        | VIRGULA ->
            _menhir_run100 _menhir_env (Obj.magic _menhir_stack) MenhirState99
        | ABREPARENTESE | BREAK | DO | DOISDOISPONTOS | ELSE | ELSEIF | END | EOF | FECHAPARENTESE | FOR | FUNCTION | GOTO | ID _ | IF | LOCAL | PONTOEVIRGULA | PRINT | REPEAT | RETURN | UNTIL | WHILE ->
            _menhir_reduce60 _menhir_env (Obj.magic _menhir_stack) MenhirState99
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState99)
    | MenhirState100 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | AND ->
            _menhir_run69 _menhir_env (Obj.magic _menhir_stack) MenhirState101
        | DIFERENTE ->
            _menhir_run68 _menhir_env (Obj.magic _menhir_stack) MenhirState101
        | DIVISAO ->
            _menhir_run67 _menhir_env (Obj.magic _menhir_stack) MenhirState101
        | EXPONENCIACAO ->
            _menhir_run66 _menhir_env (Obj.magic _menhir_stack) MenhirState101
        | IGUALDADE ->
            _menhir_run64 _menhir_env (Obj.magic _menhir_stack) MenhirState101
        | MAIOR ->
            _menhir_run63 _menhir_env (Obj.magic _menhir_stack) MenhirState101
        | MAIORIGUAL ->
            _menhir_run62 _menhir_env (Obj.magic _menhir_stack) MenhirState101
        | MENOR ->
            _menhir_run61 _menhir_env (Obj.magic _menhir_stack) MenhirState101
        | MENORIGUAL ->
            _menhir_run60 _menhir_env (Obj.magic _menhir_stack) MenhirState101
        | MODULO ->
            _menhir_run59 _menhir_env (Obj.magic _menhir_stack) MenhirState101
        | MULTIPLICACAO ->
            _menhir_run58 _menhir_env (Obj.magic _menhir_stack) MenhirState101
        | OR ->
            _menhir_run57 _menhir_env (Obj.magic _menhir_stack) MenhirState101
        | PONTOPONTO ->
            _menhir_run56 _menhir_env (Obj.magic _menhir_stack) MenhirState101
        | SOMA ->
            _menhir_run55 _menhir_env (Obj.magic _menhir_stack) MenhirState101
        | SUBTRACAO ->
            _menhir_run54 _menhir_env (Obj.magic _menhir_stack) MenhirState101
        | ABREPARENTESE | BREAK | DO | DOISDOISPONTOS | ELSE | ELSEIF | END | EOF | FECHAPARENTESE | FOR | FUNCTION | GOTO | ID _ | IF | LOCAL | PONTOEVIRGULA | PRINT | REPEAT | RETURN | UNTIL | VIRGULA | WHILE ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let ((_menhir_stack, _menhir_s), _, (e : (Ast.exp))) = _menhir_stack in
            let _1 = () in
            let _v : (Ast.virgula_exp_rule) =                   ( VirgulaExp(e) ) in
            let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
            let _menhir_stack = Obj.magic _menhir_stack in
            assert (not _menhir_env._menhir_error);
            let _tok = _menhir_env._menhir_token in
            (match _tok with
            | VIRGULA ->
                _menhir_run100 _menhir_env (Obj.magic _menhir_stack) MenhirState102
            | ABREPARENTESE | BREAK | DO | DOISDOISPONTOS | ELSE | ELSEIF | END | EOF | FECHAPARENTESE | FOR | FUNCTION | GOTO | ID _ | IF | LOCAL | PONTOEVIRGULA | PRINT | REPEAT | RETURN | UNTIL | WHILE ->
                _menhir_reduce60 _menhir_env (Obj.magic _menhir_stack) MenhirState102
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState102)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState101)
    | MenhirState113 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | AND ->
            _menhir_run69 _menhir_env (Obj.magic _menhir_stack) MenhirState114
        | DIFERENTE ->
            _menhir_run68 _menhir_env (Obj.magic _menhir_stack) MenhirState114
        | DIVISAO ->
            _menhir_run67 _menhir_env (Obj.magic _menhir_stack) MenhirState114
        | EXPONENCIACAO ->
            _menhir_run66 _menhir_env (Obj.magic _menhir_stack) MenhirState114
        | IGUALDADE ->
            _menhir_run64 _menhir_env (Obj.magic _menhir_stack) MenhirState114
        | MAIOR ->
            _menhir_run63 _menhir_env (Obj.magic _menhir_stack) MenhirState114
        | MAIORIGUAL ->
            _menhir_run62 _menhir_env (Obj.magic _menhir_stack) MenhirState114
        | MENOR ->
            _menhir_run61 _menhir_env (Obj.magic _menhir_stack) MenhirState114
        | MENORIGUAL ->
            _menhir_run60 _menhir_env (Obj.magic _menhir_stack) MenhirState114
        | MODULO ->
            _menhir_run59 _menhir_env (Obj.magic _menhir_stack) MenhirState114
        | MULTIPLICACAO ->
            _menhir_run58 _menhir_env (Obj.magic _menhir_stack) MenhirState114
        | OR ->
            _menhir_run57 _menhir_env (Obj.magic _menhir_stack) MenhirState114
        | PONTOPONTO ->
            _menhir_run56 _menhir_env (Obj.magic _menhir_stack) MenhirState114
        | SOMA ->
            _menhir_run55 _menhir_env (Obj.magic _menhir_stack) MenhirState114
        | SUBTRACAO ->
            _menhir_run54 _menhir_env (Obj.magic _menhir_stack) MenhirState114
        | THEN ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_s = MenhirState114 in
            let _menhir_stack = (_menhir_stack, _menhir_s) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            (match _tok with
            | ABREPARENTESE ->
                _menhir_run36 _menhir_env (Obj.magic _menhir_stack) MenhirState115
            | BREAK ->
                _menhir_run145 _menhir_env (Obj.magic _menhir_stack) MenhirState115
            | DO ->
                _menhir_run144 _menhir_env (Obj.magic _menhir_stack) MenhirState115
            | DOISDOISPONTOS ->
                _menhir_run141 _menhir_env (Obj.magic _menhir_stack) MenhirState115
            | FOR ->
                _menhir_run131 _menhir_env (Obj.magic _menhir_stack) MenhirState115
            | FUNCTION ->
                _menhir_run118 _menhir_env (Obj.magic _menhir_stack) MenhirState115
            | GOTO ->
                _menhir_run116 _menhir_env (Obj.magic _menhir_stack) MenhirState115
            | ID _v ->
                _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState115 _v
            | IF ->
                _menhir_run113 _menhir_env (Obj.magic _menhir_stack) MenhirState115
            | LOCAL ->
                _menhir_run107 _menhir_env (Obj.magic _menhir_stack) MenhirState115
            | PONTOEVIRGULA ->
                _menhir_run106 _menhir_env (Obj.magic _menhir_stack) MenhirState115
            | PRINT ->
                _menhir_run31 _menhir_env (Obj.magic _menhir_stack) MenhirState115
            | REPEAT ->
                _menhir_run30 _menhir_env (Obj.magic _menhir_stack) MenhirState115
            | WHILE ->
                _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState115
            | ELSE | ELSEIF | END | RETURN ->
                _menhir_reduce58 _menhir_env (Obj.magic _menhir_stack) MenhirState115
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState115)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState114)
    | MenhirState133 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | AND ->
            _menhir_run69 _menhir_env (Obj.magic _menhir_stack) MenhirState134
        | DIFERENTE ->
            _menhir_run68 _menhir_env (Obj.magic _menhir_stack) MenhirState134
        | DIVISAO ->
            _menhir_run67 _menhir_env (Obj.magic _menhir_stack) MenhirState134
        | EXPONENCIACAO ->
            _menhir_run66 _menhir_env (Obj.magic _menhir_stack) MenhirState134
        | IGUALDADE ->
            _menhir_run64 _menhir_env (Obj.magic _menhir_stack) MenhirState134
        | MAIOR ->
            _menhir_run63 _menhir_env (Obj.magic _menhir_stack) MenhirState134
        | MAIORIGUAL ->
            _menhir_run62 _menhir_env (Obj.magic _menhir_stack) MenhirState134
        | MENOR ->
            _menhir_run61 _menhir_env (Obj.magic _menhir_stack) MenhirState134
        | MENORIGUAL ->
            _menhir_run60 _menhir_env (Obj.magic _menhir_stack) MenhirState134
        | MODULO ->
            _menhir_run59 _menhir_env (Obj.magic _menhir_stack) MenhirState134
        | MULTIPLICACAO ->
            _menhir_run58 _menhir_env (Obj.magic _menhir_stack) MenhirState134
        | OR ->
            _menhir_run57 _menhir_env (Obj.magic _menhir_stack) MenhirState134
        | PONTOPONTO ->
            _menhir_run56 _menhir_env (Obj.magic _menhir_stack) MenhirState134
        | SOMA ->
            _menhir_run55 _menhir_env (Obj.magic _menhir_stack) MenhirState134
        | SUBTRACAO ->
            _menhir_run54 _menhir_env (Obj.magic _menhir_stack) MenhirState134
        | VIRGULA ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_s = MenhirState134 in
            let _menhir_stack = (_menhir_stack, _menhir_s) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            (match _tok with
            | ABRECHAVES ->
                _menhir_run37 _menhir_env (Obj.magic _menhir_stack) MenhirState135
            | ABREPARENTESE ->
                _menhir_run36 _menhir_env (Obj.magic _menhir_stack) MenhirState135
            | FALSE ->
                _menhir_run35 _menhir_env (Obj.magic _menhir_stack) MenhirState135
            | FLOAT _v ->
                _menhir_run34 _menhir_env (Obj.magic _menhir_stack) MenhirState135 _v
            | FUNCTION ->
                _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState135
            | ID _v ->
                _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState135 _v
            | INT _v ->
                _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState135 _v
            | NIL ->
                _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState135
            | NOT ->
                _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState135
            | PONTOPONTOPONTO ->
                _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState135
            | QUADRADO ->
                _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState135
            | STRING _v ->
                _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState135 _v
            | SUBTRACAO ->
                _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState135
            | TONUMBER ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState135
            | TRUE ->
                _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState135
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState135)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState134)
    | MenhirState135 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | AND ->
            _menhir_run69 _menhir_env (Obj.magic _menhir_stack) MenhirState136
        | DIFERENTE ->
            _menhir_run68 _menhir_env (Obj.magic _menhir_stack) MenhirState136
        | DIVISAO ->
            _menhir_run67 _menhir_env (Obj.magic _menhir_stack) MenhirState136
        | EXPONENCIACAO ->
            _menhir_run66 _menhir_env (Obj.magic _menhir_stack) MenhirState136
        | IGUALDADE ->
            _menhir_run64 _menhir_env (Obj.magic _menhir_stack) MenhirState136
        | MAIOR ->
            _menhir_run63 _menhir_env (Obj.magic _menhir_stack) MenhirState136
        | MAIORIGUAL ->
            _menhir_run62 _menhir_env (Obj.magic _menhir_stack) MenhirState136
        | MENOR ->
            _menhir_run61 _menhir_env (Obj.magic _menhir_stack) MenhirState136
        | MENORIGUAL ->
            _menhir_run60 _menhir_env (Obj.magic _menhir_stack) MenhirState136
        | MODULO ->
            _menhir_run59 _menhir_env (Obj.magic _menhir_stack) MenhirState136
        | MULTIPLICACAO ->
            _menhir_run58 _menhir_env (Obj.magic _menhir_stack) MenhirState136
        | OR ->
            _menhir_run57 _menhir_env (Obj.magic _menhir_stack) MenhirState136
        | PONTOPONTO ->
            _menhir_run56 _menhir_env (Obj.magic _menhir_stack) MenhirState136
        | SOMA ->
            _menhir_run55 _menhir_env (Obj.magic _menhir_stack) MenhirState136
        | SUBTRACAO ->
            _menhir_run54 _menhir_env (Obj.magic _menhir_stack) MenhirState136
        | VIRGULA ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_s = MenhirState136 in
            let _menhir_stack = (_menhir_stack, _menhir_s) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            (match _tok with
            | ABRECHAVES ->
                _menhir_run37 _menhir_env (Obj.magic _menhir_stack) MenhirState137
            | ABREPARENTESE ->
                _menhir_run36 _menhir_env (Obj.magic _menhir_stack) MenhirState137
            | FALSE ->
                _menhir_run35 _menhir_env (Obj.magic _menhir_stack) MenhirState137
            | FLOAT _v ->
                _menhir_run34 _menhir_env (Obj.magic _menhir_stack) MenhirState137 _v
            | FUNCTION ->
                _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState137
            | ID _v ->
                _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState137 _v
            | INT _v ->
                _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState137 _v
            | NIL ->
                _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState137
            | NOT ->
                _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState137
            | PONTOPONTOPONTO ->
                _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState137
            | QUADRADO ->
                _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState137
            | STRING _v ->
                _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState137 _v
            | SUBTRACAO ->
                _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState137
            | TONUMBER ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState137
            | TRUE ->
                _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState137
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState137)
        | DO ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_s = MenhirState136 in
            let _v : (Ast.comma_exp_rule option) =     ( None ) in
            _menhir_goto_option_comma_exp_rule_ _menhir_env _menhir_stack _menhir_s _v
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState136)
    | MenhirState137 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | AND ->
            _menhir_run69 _menhir_env (Obj.magic _menhir_stack) MenhirState138
        | DIFERENTE ->
            _menhir_run68 _menhir_env (Obj.magic _menhir_stack) MenhirState138
        | DIVISAO ->
            _menhir_run67 _menhir_env (Obj.magic _menhir_stack) MenhirState138
        | EXPONENCIACAO ->
            _menhir_run66 _menhir_env (Obj.magic _menhir_stack) MenhirState138
        | IGUALDADE ->
            _menhir_run64 _menhir_env (Obj.magic _menhir_stack) MenhirState138
        | MAIOR ->
            _menhir_run63 _menhir_env (Obj.magic _menhir_stack) MenhirState138
        | MAIORIGUAL ->
            _menhir_run62 _menhir_env (Obj.magic _menhir_stack) MenhirState138
        | MENOR ->
            _menhir_run61 _menhir_env (Obj.magic _menhir_stack) MenhirState138
        | MENORIGUAL ->
            _menhir_run60 _menhir_env (Obj.magic _menhir_stack) MenhirState138
        | MODULO ->
            _menhir_run59 _menhir_env (Obj.magic _menhir_stack) MenhirState138
        | MULTIPLICACAO ->
            _menhir_run58 _menhir_env (Obj.magic _menhir_stack) MenhirState138
        | OR ->
            _menhir_run57 _menhir_env (Obj.magic _menhir_stack) MenhirState138
        | PONTOPONTO ->
            _menhir_run56 _menhir_env (Obj.magic _menhir_stack) MenhirState138
        | SOMA ->
            _menhir_run55 _menhir_env (Obj.magic _menhir_stack) MenhirState138
        | SUBTRACAO ->
            _menhir_run54 _menhir_env (Obj.magic _menhir_stack) MenhirState138
        | DO ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let ((_menhir_stack, _menhir_s), _, (e : (Ast.exp))) = _menhir_stack in
            let _1 = () in
            let _v : (Ast.comma_exp_rule) =                   ( Virgula(e) ) in
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_stack = Obj.magic _menhir_stack in
            let (x : (Ast.comma_exp_rule)) = _v in
            let _v : (Ast.comma_exp_rule option) =     ( Some x ) in
            _menhir_goto_option_comma_exp_rule_ _menhir_env _menhir_stack _menhir_s _v
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState138)
    | MenhirState179 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | AND ->
            _menhir_run69 _menhir_env (Obj.magic _menhir_stack) MenhirState180
        | DIFERENTE ->
            _menhir_run68 _menhir_env (Obj.magic _menhir_stack) MenhirState180
        | DIVISAO ->
            _menhir_run67 _menhir_env (Obj.magic _menhir_stack) MenhirState180
        | EXPONENCIACAO ->
            _menhir_run66 _menhir_env (Obj.magic _menhir_stack) MenhirState180
        | IGUALDADE ->
            _menhir_run64 _menhir_env (Obj.magic _menhir_stack) MenhirState180
        | MAIOR ->
            _menhir_run63 _menhir_env (Obj.magic _menhir_stack) MenhirState180
        | MAIORIGUAL ->
            _menhir_run62 _menhir_env (Obj.magic _menhir_stack) MenhirState180
        | MENOR ->
            _menhir_run61 _menhir_env (Obj.magic _menhir_stack) MenhirState180
        | MENORIGUAL ->
            _menhir_run60 _menhir_env (Obj.magic _menhir_stack) MenhirState180
        | MODULO ->
            _menhir_run59 _menhir_env (Obj.magic _menhir_stack) MenhirState180
        | MULTIPLICACAO ->
            _menhir_run58 _menhir_env (Obj.magic _menhir_stack) MenhirState180
        | OR ->
            _menhir_run57 _menhir_env (Obj.magic _menhir_stack) MenhirState180
        | PONTOPONTO ->
            _menhir_run56 _menhir_env (Obj.magic _menhir_stack) MenhirState180
        | SOMA ->
            _menhir_run55 _menhir_env (Obj.magic _menhir_stack) MenhirState180
        | SUBTRACAO ->
            _menhir_run54 _menhir_env (Obj.magic _menhir_stack) MenhirState180
        | THEN ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_s = MenhirState180 in
            let _menhir_stack = (_menhir_stack, _menhir_s) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            (match _tok with
            | ABREPARENTESE ->
                _menhir_run36 _menhir_env (Obj.magic _menhir_stack) MenhirState181
            | BREAK ->
                _menhir_run145 _menhir_env (Obj.magic _menhir_stack) MenhirState181
            | DO ->
                _menhir_run144 _menhir_env (Obj.magic _menhir_stack) MenhirState181
            | DOISDOISPONTOS ->
                _menhir_run141 _menhir_env (Obj.magic _menhir_stack) MenhirState181
            | FOR ->
                _menhir_run131 _menhir_env (Obj.magic _menhir_stack) MenhirState181
            | FUNCTION ->
                _menhir_run118 _menhir_env (Obj.magic _menhir_stack) MenhirState181
            | GOTO ->
                _menhir_run116 _menhir_env (Obj.magic _menhir_stack) MenhirState181
            | ID _v ->
                _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState181 _v
            | IF ->
                _menhir_run113 _menhir_env (Obj.magic _menhir_stack) MenhirState181
            | LOCAL ->
                _menhir_run107 _menhir_env (Obj.magic _menhir_stack) MenhirState181
            | PONTOEVIRGULA ->
                _menhir_run106 _menhir_env (Obj.magic _menhir_stack) MenhirState181
            | PRINT ->
                _menhir_run31 _menhir_env (Obj.magic _menhir_stack) MenhirState181
            | REPEAT ->
                _menhir_run30 _menhir_env (Obj.magic _menhir_stack) MenhirState181
            | WHILE ->
                _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState181
            | ELSE | ELSEIF | END | RETURN ->
                _menhir_reduce58 _menhir_env (Obj.magic _menhir_stack) MenhirState181
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState181)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState180)
    | MenhirState192 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | AND ->
            _menhir_run69 _menhir_env (Obj.magic _menhir_stack) MenhirState193
        | DIFERENTE ->
            _menhir_run68 _menhir_env (Obj.magic _menhir_stack) MenhirState193
        | DIVISAO ->
            _menhir_run67 _menhir_env (Obj.magic _menhir_stack) MenhirState193
        | EXPONENCIACAO ->
            _menhir_run66 _menhir_env (Obj.magic _menhir_stack) MenhirState193
        | IGUALDADE ->
            _menhir_run64 _menhir_env (Obj.magic _menhir_stack) MenhirState193
        | MAIOR ->
            _menhir_run63 _menhir_env (Obj.magic _menhir_stack) MenhirState193
        | MAIORIGUAL ->
            _menhir_run62 _menhir_env (Obj.magic _menhir_stack) MenhirState193
        | MENOR ->
            _menhir_run61 _menhir_env (Obj.magic _menhir_stack) MenhirState193
        | MENORIGUAL ->
            _menhir_run60 _menhir_env (Obj.magic _menhir_stack) MenhirState193
        | MODULO ->
            _menhir_run59 _menhir_env (Obj.magic _menhir_stack) MenhirState193
        | MULTIPLICACAO ->
            _menhir_run58 _menhir_env (Obj.magic _menhir_stack) MenhirState193
        | OR ->
            _menhir_run57 _menhir_env (Obj.magic _menhir_stack) MenhirState193
        | PONTOPONTO ->
            _menhir_run56 _menhir_env (Obj.magic _menhir_stack) MenhirState193
        | SOMA ->
            _menhir_run55 _menhir_env (Obj.magic _menhir_stack) MenhirState193
        | SUBTRACAO ->
            _menhir_run54 _menhir_env (Obj.magic _menhir_stack) MenhirState193
        | ABREPARENTESE | BREAK | DO | DOISDOISPONTOS | ELSE | ELSEIF | END | EOF | FOR | FUNCTION | GOTO | ID _ | IF | LOCAL | PONTOEVIRGULA | PRINT | REPEAT | RETURN | UNTIL | WHILE ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let (((_menhir_stack, _menhir_s), _, (b : (Ast.block))), _, (e : (Ast.exp))) = _menhir_stack in
            let _3 = () in
            let _1 = () in
            let _v : (Ast.stat) =                                ( Repeat(b,e)) in
            _menhir_goto_stat _menhir_env _menhir_stack _menhir_s _v
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState193)
    | MenhirState1 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | AND ->
            _menhir_run69 _menhir_env (Obj.magic _menhir_stack) MenhirState202
        | DIFERENTE ->
            _menhir_run68 _menhir_env (Obj.magic _menhir_stack) MenhirState202
        | DIVISAO ->
            _menhir_run67 _menhir_env (Obj.magic _menhir_stack) MenhirState202
        | DO ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_s = MenhirState202 in
            let _menhir_stack = (_menhir_stack, _menhir_s) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            (match _tok with
            | ABREPARENTESE ->
                _menhir_run36 _menhir_env (Obj.magic _menhir_stack) MenhirState203
            | BREAK ->
                _menhir_run145 _menhir_env (Obj.magic _menhir_stack) MenhirState203
            | DO ->
                _menhir_run144 _menhir_env (Obj.magic _menhir_stack) MenhirState203
            | DOISDOISPONTOS ->
                _menhir_run141 _menhir_env (Obj.magic _menhir_stack) MenhirState203
            | FOR ->
                _menhir_run131 _menhir_env (Obj.magic _menhir_stack) MenhirState203
            | FUNCTION ->
                _menhir_run118 _menhir_env (Obj.magic _menhir_stack) MenhirState203
            | GOTO ->
                _menhir_run116 _menhir_env (Obj.magic _menhir_stack) MenhirState203
            | ID _v ->
                _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState203 _v
            | IF ->
                _menhir_run113 _menhir_env (Obj.magic _menhir_stack) MenhirState203
            | LOCAL ->
                _menhir_run107 _menhir_env (Obj.magic _menhir_stack) MenhirState203
            | PONTOEVIRGULA ->
                _menhir_run106 _menhir_env (Obj.magic _menhir_stack) MenhirState203
            | PRINT ->
                _menhir_run31 _menhir_env (Obj.magic _menhir_stack) MenhirState203
            | REPEAT ->
                _menhir_run30 _menhir_env (Obj.magic _menhir_stack) MenhirState203
            | WHILE ->
                _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState203
            | END | RETURN ->
                _menhir_reduce58 _menhir_env (Obj.magic _menhir_stack) MenhirState203
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState203)
        | EXPONENCIACAO ->
            _menhir_run66 _menhir_env (Obj.magic _menhir_stack) MenhirState202
        | IGUALDADE ->
            _menhir_run64 _menhir_env (Obj.magic _menhir_stack) MenhirState202
        | MAIOR ->
            _menhir_run63 _menhir_env (Obj.magic _menhir_stack) MenhirState202
        | MAIORIGUAL ->
            _menhir_run62 _menhir_env (Obj.magic _menhir_stack) MenhirState202
        | MENOR ->
            _menhir_run61 _menhir_env (Obj.magic _menhir_stack) MenhirState202
        | MENORIGUAL ->
            _menhir_run60 _menhir_env (Obj.magic _menhir_stack) MenhirState202
        | MODULO ->
            _menhir_run59 _menhir_env (Obj.magic _menhir_stack) MenhirState202
        | MULTIPLICACAO ->
            _menhir_run58 _menhir_env (Obj.magic _menhir_stack) MenhirState202
        | OR ->
            _menhir_run57 _menhir_env (Obj.magic _menhir_stack) MenhirState202
        | PONTOPONTO ->
            _menhir_run56 _menhir_env (Obj.magic _menhir_stack) MenhirState202
        | SOMA ->
            _menhir_run55 _menhir_env (Obj.magic _menhir_stack) MenhirState202
        | SUBTRACAO ->
            _menhir_run54 _menhir_env (Obj.magic _menhir_stack) MenhirState202
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState202)
    | _ ->
        _menhir_fail ()

and _menhir_goto_option_fieldlist_ : _menhir_env -> 'ttv_tail -> _menhir_state -> (Ast.fieldlist option) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    let _menhir_stack = Obj.magic _menhir_stack in
    assert (not _menhir_env._menhir_error);
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | FECHACHAVES ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_env = _menhir_discard _menhir_env in
        let _menhir_stack = Obj.magic _menhir_stack in
        let ((_menhir_stack, _menhir_s), _, (f : (Ast.fieldlist option))) = _menhir_stack in
        let _3 = () in
        let _1 = () in
        let _v : (Ast.tableconstructor) =                                         ( FieldList(f) ) in
        (match _menhir_s with
        | MenhirState1 | MenhirState192 | MenhirState179 | MenhirState173 | MenhirState161 | MenhirState147 | MenhirState137 | MenhirState135 | MenhirState133 | MenhirState113 | MenhirState109 | MenhirState100 | MenhirState33 | MenhirState36 | MenhirState91 | MenhirState37 | MenhirState78 | MenhirState75 | MenhirState39 | MenhirState70 | MenhirState50 | MenhirState41 ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_stack = Obj.magic _menhir_stack in
            let (t : (Ast.tableconstructor)) = _v in
            let _v : (Ast.exp) =                        ( TableConstructor(t) ) in
            _menhir_goto_exp _menhir_env _menhir_stack _menhir_s _v
        | MenhirState152 | MenhirState31 | MenhirState43 | MenhirState47 ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_stack = Obj.magic _menhir_stack in
            let (t : (Ast.tableconstructor)) = _v in
            let _v : (Ast.args) =                        ( TableConstructor(t) ) in
            _menhir_goto_args _menhir_env _menhir_stack _menhir_s _v
        | _ ->
            _menhir_fail ())
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s

and _menhir_run38 : _menhir_env -> 'ttv_tail -> _menhir_state -> (string) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ATRIBUICAO ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | ABRECHAVES ->
            _menhir_run37 _menhir_env (Obj.magic _menhir_stack) MenhirState39
        | ABREPARENTESE ->
            _menhir_run36 _menhir_env (Obj.magic _menhir_stack) MenhirState39
        | FALSE ->
            _menhir_run35 _menhir_env (Obj.magic _menhir_stack) MenhirState39
        | FLOAT _v ->
            _menhir_run34 _menhir_env (Obj.magic _menhir_stack) MenhirState39 _v
        | FUNCTION ->
            _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState39
        | ID _v ->
            _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState39 _v
        | INT _v ->
            _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState39 _v
        | NIL ->
            _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState39
        | NOT ->
            _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState39
        | PONTOPONTOPONTO ->
            _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState39
        | QUADRADO ->
            _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState39
        | STRING _v ->
            _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState39 _v
        | SUBTRACAO ->
            _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState39
        | TONUMBER ->
            _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState39
        | TRUE ->
            _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState39
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState39)
    | ABRECHAVES | ABRECOLCHETE | ABREPARENTESE | AND | DIFERENTE | DIVISAO | DOISPONTOS | EXPONENCIACAO | FECHACHAVES | IGUALDADE | MAIOR | MAIORIGUAL | MENOR | MENORIGUAL | MODULO | MULTIPLICACAO | OR | PONTO | PONTOEVIRGULA | PONTOPONTO | SOMA | STRING _ | SUBTRACAO | VIRGULA ->
        _menhir_reduce117 _menhir_env (Obj.magic _menhir_stack)
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s

and _menhir_run75 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ABRECHAVES ->
        _menhir_run37 _menhir_env (Obj.magic _menhir_stack) MenhirState75
    | ABREPARENTESE ->
        _menhir_run36 _menhir_env (Obj.magic _menhir_stack) MenhirState75
    | FALSE ->
        _menhir_run35 _menhir_env (Obj.magic _menhir_stack) MenhirState75
    | FLOAT _v ->
        _menhir_run34 _menhir_env (Obj.magic _menhir_stack) MenhirState75 _v
    | FUNCTION ->
        _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState75
    | ID _v ->
        _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState75 _v
    | INT _v ->
        _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState75 _v
    | NIL ->
        _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState75
    | NOT ->
        _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState75
    | PONTOPONTOPONTO ->
        _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState75
    | QUADRADO ->
        _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState75
    | STRING _v ->
        _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState75 _v
    | SUBTRACAO ->
        _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState75
    | TONUMBER ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState75
    | TRUE ->
        _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState75
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState75

and _menhir_goto_list_stat_ : _menhir_env -> 'ttv_tail -> _menhir_state -> (Ast.stat list) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    match _menhir_s with
    | MenhirState156 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_stack = Obj.magic _menhir_stack in
        let ((_menhir_stack, _menhir_s, (x : (Ast.stat))), _, (xs : (Ast.stat list))) = _menhir_stack in
        let _v : (Ast.stat list) =     ( x :: xs ) in
        _menhir_goto_list_stat_ _menhir_env _menhir_stack _menhir_s _v
    | MenhirState0 | MenhirState203 | MenhirState29 | MenhirState30 | MenhirState184 | MenhirState181 | MenhirState115 | MenhirState175 | MenhirState140 | MenhirState144 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | RETURN ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            (match _tok with
            | ABRECHAVES ->
                _menhir_run37 _menhir_env (Obj.magic _menhir_stack) MenhirState161
            | ABREPARENTESE ->
                _menhir_run36 _menhir_env (Obj.magic _menhir_stack) MenhirState161
            | FALSE ->
                _menhir_run35 _menhir_env (Obj.magic _menhir_stack) MenhirState161
            | FLOAT _v ->
                _menhir_run34 _menhir_env (Obj.magic _menhir_stack) MenhirState161 _v
            | FUNCTION ->
                _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState161
            | ID _v ->
                _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState161 _v
            | INT _v ->
                _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState161 _v
            | NIL ->
                _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState161
            | NOT ->
                _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState161
            | PONTOPONTOPONTO ->
                _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState161
            | QUADRADO ->
                _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState161
            | STRING _v ->
                _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState161 _v
            | SUBTRACAO ->
                _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState161
            | TONUMBER ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState161
            | TRUE ->
                _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState161
            | ELSE | ELSEIF | END | EOF | PONTOEVIRGULA | UNTIL ->
                _menhir_reduce77 _menhir_env (Obj.magic _menhir_stack) MenhirState161
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState161)
        | ELSE | ELSEIF | END | EOF | UNTIL ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _v : (Ast.retstat option) =     ( None ) in
            _menhir_goto_option_retstat_ _menhir_env _menhir_stack _v
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | _ ->
        _menhir_fail ()

and _menhir_run32 : _menhir_env -> 'ttv_tail -> _menhir_state -> (string) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _menhir_stack = Obj.magic _menhir_stack in
    let (s : (string)) = _v in
    let _v : (Ast.args) =              ( String(s) ) in
    _menhir_goto_args _menhir_env _menhir_stack _menhir_s _v

and _menhir_run33 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ABRECHAVES ->
        _menhir_run37 _menhir_env (Obj.magic _menhir_stack) MenhirState33
    | ABREPARENTESE ->
        _menhir_run36 _menhir_env (Obj.magic _menhir_stack) MenhirState33
    | FALSE ->
        _menhir_run35 _menhir_env (Obj.magic _menhir_stack) MenhirState33
    | FLOAT _v ->
        _menhir_run34 _menhir_env (Obj.magic _menhir_stack) MenhirState33 _v
    | FUNCTION ->
        _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState33
    | ID _v ->
        _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState33 _v
    | INT _v ->
        _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState33 _v
    | NIL ->
        _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState33
    | NOT ->
        _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState33
    | PONTOPONTOPONTO ->
        _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState33
    | QUADRADO ->
        _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState33
    | STRING _v ->
        _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState33 _v
    | SUBTRACAO ->
        _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState33
    | TONUMBER ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState33
    | TRUE ->
        _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState33
    | FECHAPARENTESE ->
        _menhir_reduce77 _menhir_env (Obj.magic _menhir_stack) MenhirState33
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState33

and _menhir_run21 : _menhir_env -> 'ttv_tail -> _menhir_state -> (string) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | VIRGULA ->
        _menhir_run22 _menhir_env (Obj.magic _menhir_stack) MenhirState21
    | ABREPARENTESE | ATRIBUICAO | BREAK | DO | DOISDOISPONTOS | ELSE | ELSEIF | END | EOF | FECHAPARENTESE | FOR | FUNCTION | GOTO | ID _ | IF | LOCAL | PONTOEVIRGULA | PRINT | REPEAT | RETURN | UNTIL | WHILE ->
        _menhir_reduce62 _menhir_env (Obj.magic _menhir_stack) MenhirState21
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState21

and _menhir_reduce117 : _menhir_env -> 'ttv_tail * _menhir_state * (string) -> 'ttv_return =
  fun _menhir_env _menhir_stack ->
    let (_menhir_stack, _menhir_s, (i : (string))) = _menhir_stack in
    let _v : (Ast.var) =          ( Id(i) ) in
    _menhir_goto_var _menhir_env _menhir_stack _menhir_s _v

and _menhir_reduce56 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _v : (Ast.ponto_id_rule list) =     ( [] ) in
    _menhir_goto_list_ponto_id_rule_ _menhir_env _menhir_stack _menhir_s _v

and _menhir_run120 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ID _v ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_env = _menhir_discard _menhir_env in
        let _menhir_stack = Obj.magic _menhir_stack in
        let (i : (string)) = _v in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        let _1 = () in
        let _v : (Ast.ponto_id_rule) =                ( Ponto(i) ) in
        let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | PONTO ->
            _menhir_run120 _menhir_env (Obj.magic _menhir_stack) MenhirState122
        | ABREPARENTESE | DOISPONTOS ->
            _menhir_reduce56 _menhir_env (Obj.magic _menhir_stack) MenhirState122
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState122)
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s

and _menhir_reduce62 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _v : (Ast.virgula_id_rule list) =     ( [] ) in
    _menhir_goto_list_virgula_id_rule_ _menhir_env _menhir_stack _menhir_s _v

and _menhir_run22 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ID _v ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_env = _menhir_discard _menhir_env in
        let _menhir_stack = Obj.magic _menhir_stack in
        let (i : (string)) = _v in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        let _1 = () in
        let _v : (Ast.virgula_id_rule) =                  ( Virgulaid(i) ) in
        let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | VIRGULA ->
            _menhir_run22 _menhir_env (Obj.magic _menhir_stack) MenhirState24
        | ABREPARENTESE | ATRIBUICAO | BREAK | DO | DOISDOISPONTOS | ELSE | ELSEIF | END | EOF | FECHAPARENTESE | FOR | FUNCTION | GOTO | ID _ | IF | IN | LOCAL | PONTOEVIRGULA | PRINT | REPEAT | RETURN | UNTIL | WHILE ->
            _menhir_reduce62 _menhir_env (Obj.magic _menhir_stack) MenhirState24
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState24)
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s

and _menhir_goto_stat : _menhir_env -> 'ttv_tail -> _menhir_state -> (Ast.stat) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    let _menhir_stack = Obj.magic _menhir_stack in
    assert (not _menhir_env._menhir_error);
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ABREPARENTESE ->
        _menhir_run36 _menhir_env (Obj.magic _menhir_stack) MenhirState156
    | BREAK ->
        _menhir_run145 _menhir_env (Obj.magic _menhir_stack) MenhirState156
    | DO ->
        _menhir_run144 _menhir_env (Obj.magic _menhir_stack) MenhirState156
    | DOISDOISPONTOS ->
        _menhir_run141 _menhir_env (Obj.magic _menhir_stack) MenhirState156
    | FOR ->
        _menhir_run131 _menhir_env (Obj.magic _menhir_stack) MenhirState156
    | FUNCTION ->
        _menhir_run118 _menhir_env (Obj.magic _menhir_stack) MenhirState156
    | GOTO ->
        _menhir_run116 _menhir_env (Obj.magic _menhir_stack) MenhirState156
    | ID _v ->
        _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState156 _v
    | IF ->
        _menhir_run113 _menhir_env (Obj.magic _menhir_stack) MenhirState156
    | LOCAL ->
        _menhir_run107 _menhir_env (Obj.magic _menhir_stack) MenhirState156
    | PONTOEVIRGULA ->
        _menhir_run106 _menhir_env (Obj.magic _menhir_stack) MenhirState156
    | PRINT ->
        _menhir_run31 _menhir_env (Obj.magic _menhir_stack) MenhirState156
    | REPEAT ->
        _menhir_run30 _menhir_env (Obj.magic _menhir_stack) MenhirState156
    | WHILE ->
        _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState156
    | ELSE | ELSEIF | END | EOF | RETURN | UNTIL ->
        _menhir_reduce58 _menhir_env (Obj.magic _menhir_stack) MenhirState156
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState156

and _menhir_run2 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _menhir_stack = Obj.magic _menhir_stack in
    let _1 = () in
    let _v : (Ast.exp) =          ( Verdadeiro ) in
    _menhir_goto_exp _menhir_env _menhir_stack _menhir_s _v

and _menhir_run3 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ABREPARENTESE ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | READ ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            (match _tok with
            | ABREPARENTESE ->
                let _menhir_stack = Obj.magic _menhir_stack in
                let _menhir_env = _menhir_discard _menhir_env in
                let _tok = _menhir_env._menhir_token in
                (match _tok with
                | FECHAPARENTESE ->
                    let _menhir_stack = Obj.magic _menhir_stack in
                    let _menhir_env = _menhir_discard _menhir_env in
                    let _menhir_stack = Obj.magic _menhir_stack in
                    let _3 = () in
                    let _2 = () in
                    let _1 = () in
                    let _v : (Ast.read) =                                      ( Read ) in
                    let _menhir_stack = (_menhir_stack, _v) in
                    let _menhir_stack = Obj.magic _menhir_stack in
                    assert (not _menhir_env._menhir_error);
                    let _tok = _menhir_env._menhir_token in
                    (match _tok with
                    | FECHAPARENTESE ->
                        let _menhir_stack = Obj.magic _menhir_stack in
                        let _menhir_env = _menhir_discard _menhir_env in
                        let _menhir_stack = Obj.magic _menhir_stack in
                        let ((_menhir_stack, _menhir_s), (r : (Ast.read))) = _menhir_stack in
                        let _4 = () in
                        let _2 = () in
                        let _1 = () in
                        let _v : (Ast.exp) =                                                  (Tonumber(r)) in
                        _menhir_goto_exp _menhir_env _menhir_stack _menhir_s _v
                    | _ ->
                        assert (not _menhir_env._menhir_error);
                        _menhir_env._menhir_error <- true;
                        let _menhir_stack = Obj.magic _menhir_stack in
                        let ((_menhir_stack, _menhir_s), _) = _menhir_stack in
                        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
                | _ ->
                    assert (not _menhir_env._menhir_error);
                    _menhir_env._menhir_error <- true;
                    let _menhir_stack = Obj.magic _menhir_stack in
                    raise _eRR)
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                let _menhir_stack = Obj.magic _menhir_stack in
                raise _eRR)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s

and _menhir_run10 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _menhir_stack = Obj.magic _menhir_stack in
    let _1 = () in
    let _v : (Ast.unop) =               ( Subtracao) in
    _menhir_goto_unop _menhir_env _menhir_stack _menhir_s _v

and _menhir_run11 : _menhir_env -> 'ttv_tail -> _menhir_state -> (string) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _menhir_stack = Obj.magic _menhir_stack in
    let (i : (string)) = _v in
    let _v : (Ast.exp) =              ( String(i)) in
    _menhir_goto_exp _menhir_env _menhir_stack _menhir_s _v

and _menhir_run12 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _menhir_stack = Obj.magic _menhir_stack in
    let _1 = () in
    let _v : (Ast.unop) =              ( Quadrado) in
    _menhir_goto_unop _menhir_env _menhir_stack _menhir_s _v

and _menhir_run13 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _menhir_stack = Obj.magic _menhir_stack in
    let _1 = () in
    let _v : (Ast.exp) =                     ( PontoPonto ) in
    _menhir_goto_exp _menhir_env _menhir_stack _menhir_s _v

and _menhir_run14 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _menhir_stack = Obj.magic _menhir_stack in
    let _1 = () in
    let _v : (Ast.unop) =         ( Not) in
    _menhir_goto_unop _menhir_env _menhir_stack _menhir_s _v

and _menhir_run15 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _menhir_stack = Obj.magic _menhir_stack in
    let _1 = () in
    let _v : (Ast.exp) =         ( Nil ) in
    _menhir_goto_exp _menhir_env _menhir_stack _menhir_s _v

and _menhir_run16 : _menhir_env -> 'ttv_tail -> _menhir_state -> (int) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _menhir_stack = Obj.magic _menhir_stack in
    let (i : (int)) = _v in
    let _v : (Ast.exp) =           ( Int(i) ) in
    _menhir_goto_exp _menhir_env _menhir_stack _menhir_s _v

and _menhir_run18 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ABREPARENTESE ->
        _menhir_run19 _menhir_env (Obj.magic _menhir_stack) MenhirState18
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState18

and _menhir_run34 : _menhir_env -> 'ttv_tail -> _menhir_state -> (float) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _menhir_stack = Obj.magic _menhir_stack in
    let (i : (float)) = _v in
    let _v : (Ast.exp) =             ( Float(i) ) in
    _menhir_goto_exp _menhir_env _menhir_stack _menhir_s _v

and _menhir_run35 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _menhir_stack = Obj.magic _menhir_stack in
    let _1 = () in
    let _v : (Ast.exp) =           ( Falso) in
    _menhir_goto_exp _menhir_env _menhir_stack _menhir_s _v

and _menhir_run37 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ABRECHAVES ->
        _menhir_run37 _menhir_env (Obj.magic _menhir_stack) MenhirState37
    | ABRECOLCHETE ->
        _menhir_run75 _menhir_env (Obj.magic _menhir_stack) MenhirState37
    | ABREPARENTESE ->
        _menhir_run36 _menhir_env (Obj.magic _menhir_stack) MenhirState37
    | FALSE ->
        _menhir_run35 _menhir_env (Obj.magic _menhir_stack) MenhirState37
    | FLOAT _v ->
        _menhir_run34 _menhir_env (Obj.magic _menhir_stack) MenhirState37 _v
    | FUNCTION ->
        _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState37
    | ID _v ->
        _menhir_run38 _menhir_env (Obj.magic _menhir_stack) MenhirState37 _v
    | INT _v ->
        _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState37 _v
    | NIL ->
        _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState37
    | NOT ->
        _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState37
    | PONTOPONTOPONTO ->
        _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState37
    | QUADRADO ->
        _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState37
    | STRING _v ->
        _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState37 _v
    | SUBTRACAO ->
        _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState37
    | TONUMBER ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState37
    | TRUE ->
        _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState37
    | FECHACHAVES ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_s = MenhirState37 in
        let _v : (Ast.fieldlist option) =     ( None ) in
        _menhir_goto_option_fieldlist_ _menhir_env _menhir_stack _menhir_s _v
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState37

and _menhir_errorcase : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    match _menhir_s with
    | MenhirState203 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState202 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState193 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState192 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState189 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState184 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        raise _eRR
    | MenhirState181 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState180 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState179 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState178 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState175 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState173 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState161 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        raise _eRR
    | MenhirState156 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState153 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState152 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState150 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState149 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState147 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState144 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState140 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState138 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState137 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState136 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState135 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState134 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState133 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState132 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState131 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState129 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let ((_menhir_stack, _menhir_s), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState122 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState119 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        raise _eRR
    | MenhirState115 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState114 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState113 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState109 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        raise _eRR
    | MenhirState107 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState102 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState101 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState100 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState99 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState94 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState93 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState91 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState89 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState86 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState83 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState79 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState78 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState76 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState75 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState74 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState73 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState71 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState70 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState53 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState50 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState47 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let ((_menhir_stack, _menhir_s), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState43 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState41 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState39 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState37 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState36 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState33 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState31 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState30 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState29 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState24 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState21 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState19 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState18 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState1 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState0 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        raise _eRR

and _menhir_reduce58 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _v : (Ast.stat list) =     ( [] ) in
    _menhir_goto_list_stat_ _menhir_env _menhir_stack _menhir_s _v

and _menhir_run1 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ABRECHAVES ->
        _menhir_run37 _menhir_env (Obj.magic _menhir_stack) MenhirState1
    | ABREPARENTESE ->
        _menhir_run36 _menhir_env (Obj.magic _menhir_stack) MenhirState1
    | FALSE ->
        _menhir_run35 _menhir_env (Obj.magic _menhir_stack) MenhirState1
    | FLOAT _v ->
        _menhir_run34 _menhir_env (Obj.magic _menhir_stack) MenhirState1 _v
    | FUNCTION ->
        _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState1
    | ID _v ->
        _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState1 _v
    | INT _v ->
        _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState1 _v
    | NIL ->
        _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState1
    | NOT ->
        _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState1
    | PONTOPONTOPONTO ->
        _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState1
    | QUADRADO ->
        _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState1
    | STRING _v ->
        _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState1 _v
    | SUBTRACAO ->
        _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState1
    | TONUMBER ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState1
    | TRUE ->
        _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState1
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState1

and _menhir_run30 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ABREPARENTESE ->
        _menhir_run36 _menhir_env (Obj.magic _menhir_stack) MenhirState30
    | BREAK ->
        _menhir_run145 _menhir_env (Obj.magic _menhir_stack) MenhirState30
    | DO ->
        _menhir_run144 _menhir_env (Obj.magic _menhir_stack) MenhirState30
    | DOISDOISPONTOS ->
        _menhir_run141 _menhir_env (Obj.magic _menhir_stack) MenhirState30
    | FOR ->
        _menhir_run131 _menhir_env (Obj.magic _menhir_stack) MenhirState30
    | FUNCTION ->
        _menhir_run118 _menhir_env (Obj.magic _menhir_stack) MenhirState30
    | GOTO ->
        _menhir_run116 _menhir_env (Obj.magic _menhir_stack) MenhirState30
    | ID _v ->
        _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState30 _v
    | IF ->
        _menhir_run113 _menhir_env (Obj.magic _menhir_stack) MenhirState30
    | LOCAL ->
        _menhir_run107 _menhir_env (Obj.magic _menhir_stack) MenhirState30
    | PONTOEVIRGULA ->
        _menhir_run106 _menhir_env (Obj.magic _menhir_stack) MenhirState30
    | PRINT ->
        _menhir_run31 _menhir_env (Obj.magic _menhir_stack) MenhirState30
    | REPEAT ->
        _menhir_run30 _menhir_env (Obj.magic _menhir_stack) MenhirState30
    | WHILE ->
        _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState30
    | RETURN | UNTIL ->
        _menhir_reduce58 _menhir_env (Obj.magic _menhir_stack) MenhirState30
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState30

and _menhir_run31 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ABRECHAVES ->
        _menhir_run37 _menhir_env (Obj.magic _menhir_stack) MenhirState31
    | ABREPARENTESE ->
        _menhir_run33 _menhir_env (Obj.magic _menhir_stack) MenhirState31
    | STRING _v ->
        _menhir_run32 _menhir_env (Obj.magic _menhir_stack) MenhirState31 _v
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState31

and _menhir_run106 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _menhir_stack = Obj.magic _menhir_stack in
    let _1 = () in
    let _v : (Ast.stat) =                   ( Pontoevirgula ) in
    _menhir_goto_stat _menhir_env _menhir_stack _menhir_s _v

and _menhir_run107 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ID _v ->
        _menhir_run21 _menhir_env (Obj.magic _menhir_stack) MenhirState107 _v
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState107

and _menhir_run113 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ABRECHAVES ->
        _menhir_run37 _menhir_env (Obj.magic _menhir_stack) MenhirState113
    | ABREPARENTESE ->
        _menhir_run36 _menhir_env (Obj.magic _menhir_stack) MenhirState113
    | FALSE ->
        _menhir_run35 _menhir_env (Obj.magic _menhir_stack) MenhirState113
    | FLOAT _v ->
        _menhir_run34 _menhir_env (Obj.magic _menhir_stack) MenhirState113 _v
    | FUNCTION ->
        _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState113
    | ID _v ->
        _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState113 _v
    | INT _v ->
        _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState113 _v
    | NIL ->
        _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState113
    | NOT ->
        _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState113
    | PONTOPONTOPONTO ->
        _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState113
    | QUADRADO ->
        _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState113
    | STRING _v ->
        _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState113 _v
    | SUBTRACAO ->
        _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState113
    | TONUMBER ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState113
    | TRUE ->
        _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState113
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState113

and _menhir_run17 : _menhir_env -> 'ttv_tail -> _menhir_state -> (string) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    let _menhir_env = _menhir_discard _menhir_env in
    _menhir_reduce117 _menhir_env (Obj.magic _menhir_stack)

and _menhir_run116 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ID _v ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_env = _menhir_discard _menhir_env in
        let _menhir_stack = Obj.magic _menhir_stack in
        let (i : (string)) = _v in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        let _1 = () in
        let _v : (Ast.stat) =               ( Goto(i) ) in
        _menhir_goto_stat _menhir_env _menhir_stack _menhir_s _v
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s

and _menhir_run118 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ID _v ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_stack = (_menhir_stack, _v) in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | PONTO ->
            _menhir_run120 _menhir_env (Obj.magic _menhir_stack) MenhirState119
        | ABREPARENTESE | DOISPONTOS ->
            _menhir_reduce56 _menhir_env (Obj.magic _menhir_stack) MenhirState119
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState119)
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s

and _menhir_run131 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ID _v ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_s = MenhirState131 in
        let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | ATRIBUICAO ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_s = MenhirState132 in
            let _menhir_stack = (_menhir_stack, _menhir_s) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            (match _tok with
            | ABRECHAVES ->
                _menhir_run37 _menhir_env (Obj.magic _menhir_stack) MenhirState133
            | ABREPARENTESE ->
                _menhir_run36 _menhir_env (Obj.magic _menhir_stack) MenhirState133
            | FALSE ->
                _menhir_run35 _menhir_env (Obj.magic _menhir_stack) MenhirState133
            | FLOAT _v ->
                _menhir_run34 _menhir_env (Obj.magic _menhir_stack) MenhirState133 _v
            | FUNCTION ->
                _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState133
            | ID _v ->
                _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState133 _v
            | INT _v ->
                _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState133 _v
            | NIL ->
                _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState133
            | NOT ->
                _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState133
            | PONTOPONTOPONTO ->
                _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState133
            | QUADRADO ->
                _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState133
            | STRING _v ->
                _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState133 _v
            | SUBTRACAO ->
                _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState133
            | TONUMBER ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState133
            | TRUE ->
                _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState133
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState133)
        | VIRGULA ->
            _menhir_run22 _menhir_env (Obj.magic _menhir_stack) MenhirState132
        | IN ->
            _menhir_reduce62 _menhir_env (Obj.magic _menhir_stack) MenhirState132
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState132)
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState131

and _menhir_run141 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ID _v ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_stack = (_menhir_stack, _v) in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | DOISDOISPONTOS ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_env = _menhir_discard _menhir_env in
            let _menhir_stack = Obj.magic _menhir_stack in
            let ((_menhir_stack, _menhir_s), (i : (string))) = _menhir_stack in
            let _3 = () in
            let _1 = () in
            let _v : (Ast.label) =                                        ( Label(i)) in
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_stack = Obj.magic _menhir_stack in
            let (l : (Ast.label)) = _v in
            let _v : (Ast.stat) =             ( Label(l) ) in
            _menhir_goto_stat _menhir_env _menhir_stack _menhir_s _v
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let ((_menhir_stack, _menhir_s), _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s

and _menhir_run144 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ABREPARENTESE ->
        _menhir_run36 _menhir_env (Obj.magic _menhir_stack) MenhirState144
    | BREAK ->
        _menhir_run145 _menhir_env (Obj.magic _menhir_stack) MenhirState144
    | DO ->
        _menhir_run144 _menhir_env (Obj.magic _menhir_stack) MenhirState144
    | DOISDOISPONTOS ->
        _menhir_run141 _menhir_env (Obj.magic _menhir_stack) MenhirState144
    | FOR ->
        _menhir_run131 _menhir_env (Obj.magic _menhir_stack) MenhirState144
    | FUNCTION ->
        _menhir_run118 _menhir_env (Obj.magic _menhir_stack) MenhirState144
    | GOTO ->
        _menhir_run116 _menhir_env (Obj.magic _menhir_stack) MenhirState144
    | ID _v ->
        _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState144 _v
    | IF ->
        _menhir_run113 _menhir_env (Obj.magic _menhir_stack) MenhirState144
    | LOCAL ->
        _menhir_run107 _menhir_env (Obj.magic _menhir_stack) MenhirState144
    | PONTOEVIRGULA ->
        _menhir_run106 _menhir_env (Obj.magic _menhir_stack) MenhirState144
    | PRINT ->
        _menhir_run31 _menhir_env (Obj.magic _menhir_stack) MenhirState144
    | REPEAT ->
        _menhir_run30 _menhir_env (Obj.magic _menhir_stack) MenhirState144
    | WHILE ->
        _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState144
    | END | RETURN ->
        _menhir_reduce58 _menhir_env (Obj.magic _menhir_stack) MenhirState144
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState144

and _menhir_run145 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _menhir_stack = Obj.magic _menhir_stack in
    let _1 = () in
    let _v : (Ast.stat) =           ( Break ) in
    _menhir_goto_stat _menhir_env _menhir_stack _menhir_s _v

and _menhir_run36 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ABRECHAVES ->
        _menhir_run37 _menhir_env (Obj.magic _menhir_stack) MenhirState36
    | ABREPARENTESE ->
        _menhir_run36 _menhir_env (Obj.magic _menhir_stack) MenhirState36
    | FALSE ->
        _menhir_run35 _menhir_env (Obj.magic _menhir_stack) MenhirState36
    | FLOAT _v ->
        _menhir_run34 _menhir_env (Obj.magic _menhir_stack) MenhirState36 _v
    | FUNCTION ->
        _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState36
    | ID _v ->
        _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState36 _v
    | INT _v ->
        _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState36 _v
    | NIL ->
        _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState36
    | NOT ->
        _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState36
    | PONTOPONTOPONTO ->
        _menhir_run13 _menhir_env (Obj.magic _menhir_stack) MenhirState36
    | QUADRADO ->
        _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState36
    | STRING _v ->
        _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState36 _v
    | SUBTRACAO ->
        _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState36
    | TONUMBER ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState36
    | TRUE ->
        _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState36
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState36

and _menhir_discard : _menhir_env -> _menhir_env =
  fun _menhir_env ->
    let lexer = _menhir_env._menhir_lexer in
    let lexbuf = _menhir_env._menhir_lexbuf in
    let _tok = lexer lexbuf in
    {
      _menhir_lexer = lexer;
      _menhir_lexbuf = lexbuf;
      _menhir_token = _tok;
      _menhir_error = false;
    }

and program : (Lexing.lexbuf -> token) -> Lexing.lexbuf -> (Ast.program) =
  fun lexer lexbuf ->
    let _menhir_env = let _tok = Obj.magic () in
    {
      _menhir_lexer = lexer;
      _menhir_lexbuf = lexbuf;
      _menhir_token = _tok;
      _menhir_error = false;
    } in
    Obj.magic (let _menhir_stack = ((), _menhir_env._menhir_lexbuf.Lexing.lex_curr_p) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ABREPARENTESE ->
        _menhir_run36 _menhir_env (Obj.magic _menhir_stack) MenhirState0
    | BREAK ->
        _menhir_run145 _menhir_env (Obj.magic _menhir_stack) MenhirState0
    | DO ->
        _menhir_run144 _menhir_env (Obj.magic _menhir_stack) MenhirState0
    | DOISDOISPONTOS ->
        _menhir_run141 _menhir_env (Obj.magic _menhir_stack) MenhirState0
    | FOR ->
        _menhir_run131 _menhir_env (Obj.magic _menhir_stack) MenhirState0
    | FUNCTION ->
        _menhir_run118 _menhir_env (Obj.magic _menhir_stack) MenhirState0
    | GOTO ->
        _menhir_run116 _menhir_env (Obj.magic _menhir_stack) MenhirState0
    | ID _v ->
        _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState0 _v
    | IF ->
        _menhir_run113 _menhir_env (Obj.magic _menhir_stack) MenhirState0
    | LOCAL ->
        _menhir_run107 _menhir_env (Obj.magic _menhir_stack) MenhirState0
    | PONTOEVIRGULA ->
        _menhir_run106 _menhir_env (Obj.magic _menhir_stack) MenhirState0
    | PRINT ->
        _menhir_run31 _menhir_env (Obj.magic _menhir_stack) MenhirState0
    | REPEAT ->
        _menhir_run30 _menhir_env (Obj.magic _menhir_stack) MenhirState0
    | WHILE ->
        _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState0
    | EOF | RETURN ->
        _menhir_reduce58 _menhir_env (Obj.magic _menhir_stack) MenhirState0
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState0)
  

