#directory "_build";;
#load "lexer.cmo";;
#load "parser.cmo";;
#load "main.cmo";;
open Ast
open Main
let _ = run_tests();;