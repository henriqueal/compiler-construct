
module Basics = struct
  
  exception Error
  
  type token = 
    | WHILE
    | VIRGULA
    | UNTIL
    | TRUE
    | THEN
    | SUBTRACAO
    | STRING of (string)
    | SOMA
    | RETURN
    | REPEAT
    | READ
    | QUADRADO
    | PRINT
    | PONTOPONTOPONTO
    | PONTOPONTO
    | PONTOEVIRGULA
    | PONTO
    | OR
    | NOT
    | NIL
    | MULTIPLICACAO
    | MODULO
    | MENORIGUAL
    | MENOR
    | MAIORIGUAL
    | MAIOR
    | LOCAL
    | INT of (int)
    | IN
    | IGUALDADE
    | IF
    | ID of (string)
    | GOTO
    | FUNCTION
    | FOR
    | FLOAT of (float)
    | FECHAPARENTESE
    | FECHACOLCHETE
    | FECHACHAVES
    | FALSE
    | EXPONENCIACAO
    | EOF
    | END
    | ELSEIF
    | ELSE
    | DOISPONTOS
    | DOISDOISPONTOS
    | DO
    | DIVISAO
    | DIFERENTE
    | BREAK
    | ATRIBUICAO
    | AND
    | ABREPARENTESE
    | ABRECOLCHETE
    | ABRECHAVES
  
end

include Basics

let _eRR =
  Basics.Error

type _menhir_env = {
  _menhir_lexer: Lexing.lexbuf -> token;
  _menhir_lexbuf: Lexing.lexbuf;
  _menhir_token: token;
  mutable _menhir_error: bool
}

and _menhir_state = 
  | MenhirState196
  | MenhirState195
  | MenhirState186
  | MenhirState185
  | MenhirState182
  | MenhirState177
  | MenhirState174
  | MenhirState173
  | MenhirState172
  | MenhirState171
  | MenhirState168
  | MenhirState166
  | MenhirState154
  | MenhirState149
  | MenhirState146
  | MenhirState145
  | MenhirState143
  | MenhirState142
  | MenhirState140
  | MenhirState137
  | MenhirState133
  | MenhirState131
  | MenhirState130
  | MenhirState129
  | MenhirState128
  | MenhirState127
  | MenhirState126
  | MenhirState125
  | MenhirState124
  | MenhirState122
  | MenhirState115
  | MenhirState112
  | MenhirState108
  | MenhirState107
  | MenhirState106
  | MenhirState102
  | MenhirState100
  | MenhirState95
  | MenhirState94
  | MenhirState93
  | MenhirState92
  | MenhirState87
  | MenhirState86
  | MenhirState84
  | MenhirState82
  | MenhirState79
  | MenhirState76
  | MenhirState72
  | MenhirState71
  | MenhirState69
  | MenhirState68
  | MenhirState67
  | MenhirState66
  | MenhirState64
  | MenhirState63
  | MenhirState46
  | MenhirState43
  | MenhirState40
  | MenhirState36
  | MenhirState34
  | MenhirState32
  | MenhirState30
  | MenhirState29
  | MenhirState26
  | MenhirState24
  | MenhirState23
  | MenhirState22
  | MenhirState17
  | MenhirState14
  | MenhirState12
  | MenhirState11
  | MenhirState1
  | MenhirState0
  
  open Ast

let rec _menhir_goto_option_fieldsep_ : _menhir_env -> 'ttv_tail -> _menhir_state -> (Ast.fieldsep option) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = Obj.magic _menhir_stack in
    let _menhir_stack = Obj.magic _menhir_stack in
    let (fs : (Ast.fieldsep option)) = _v in
    let ((_menhir_stack, _menhir_s, (f : (Ast.field))), _, (ffr : (Ast.fieldsep_field_rule list))) = _menhir_stack in
    let _v : (Ast.fieldlist) =                                                   ( FieldLists(f, ffr, fs)) in
    let _menhir_stack = Obj.magic _menhir_stack in
    let _menhir_stack = Obj.magic _menhir_stack in
    let (x : (Ast.fieldlist)) = _v in
    let _v : (Ast.fieldlist option) =     ( Some x ) in
    _menhir_goto_option_fieldlist_ _menhir_env _menhir_stack _menhir_s _v

and _menhir_goto_list_fieldsep_field_rule_ : _menhir_env -> 'ttv_tail -> _menhir_state -> (Ast.fieldsep_field_rule list) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    match _menhir_s with
    | MenhirState76 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | PONTOEVIRGULA ->
            _menhir_run78 _menhir_env (Obj.magic _menhir_stack) MenhirState79
        | VIRGULA ->
            _menhir_run77 _menhir_env (Obj.magic _menhir_stack) MenhirState79
        | FECHACHAVES ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_s = MenhirState79 in
            let _v : (Ast.fieldsep option) =     ( None ) in
            _menhir_goto_option_fieldsep_ _menhir_env _menhir_stack _menhir_s _v
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState79)
    | MenhirState82 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_stack = Obj.magic _menhir_stack in
        let ((_menhir_stack, _menhir_s, (x : (Ast.fieldsep_field_rule))), _, (xs : (Ast.fieldsep_field_rule list))) = _menhir_stack in
        let _v : (Ast.fieldsep_field_rule list) =     ( x :: xs ) in
        _menhir_goto_list_fieldsep_field_rule_ _menhir_env _menhir_stack _menhir_s _v
    | _ ->
        _menhir_fail ()

and _menhir_goto_fieldsep : _menhir_env -> 'ttv_tail -> _menhir_state -> (Ast.fieldsep) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    match _menhir_s with
    | MenhirState79 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, (x : (Ast.fieldsep))) = _menhir_stack in
        let _v : (Ast.fieldsep option) =     ( Some x ) in
        _menhir_goto_option_fieldsep_ _menhir_env _menhir_stack _menhir_s _v
    | MenhirState76 | MenhirState82 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | ABRECHAVES ->
            _menhir_run30 _menhir_env (Obj.magic _menhir_stack) MenhirState84
        | ABRECOLCHETE ->
            _menhir_run68 _menhir_env (Obj.magic _menhir_stack) MenhirState84
        | ABREPARENTESE ->
            _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState84
        | FALSE ->
            _menhir_run28 _menhir_env (Obj.magic _menhir_stack) MenhirState84
        | FLOAT _v ->
            _menhir_run27 _menhir_env (Obj.magic _menhir_stack) MenhirState84 _v
        | FUNCTION ->
            _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState84
        | ID _v ->
            _menhir_run31 _menhir_env (Obj.magic _menhir_stack) MenhirState84 _v
        | INT _v ->
            _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState84 _v
        | NIL ->
            _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState84
        | NOT ->
            _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState84
        | PONTOPONTOPONTO ->
            _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState84
        | QUADRADO ->
            _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState84
        | STRING _v ->
            _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState84 _v
        | SUBTRACAO ->
            _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState84
        | TRUE ->
            _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState84
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState84)
    | _ ->
        _menhir_fail ()

and _menhir_goto_list_elseif_rule_ : _menhir_env -> 'ttv_tail -> _menhir_state -> (Ast.elseif_rule list) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    match _menhir_s with
    | MenhirState171 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | ELSE ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            (match _tok with
            | ABREPARENTESE ->
                _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState177
            | BREAK ->
                _menhir_run138 _menhir_env (Obj.magic _menhir_stack) MenhirState177
            | DO ->
                _menhir_run137 _menhir_env (Obj.magic _menhir_stack) MenhirState177
            | DOISDOISPONTOS ->
                _menhir_run134 _menhir_env (Obj.magic _menhir_stack) MenhirState177
            | FOR ->
                _menhir_run124 _menhir_env (Obj.magic _menhir_stack) MenhirState177
            | FUNCTION ->
                _menhir_run111 _menhir_env (Obj.magic _menhir_stack) MenhirState177
            | GOTO ->
                _menhir_run109 _menhir_env (Obj.magic _menhir_stack) MenhirState177
            | ID _v ->
                _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState177 _v
            | IF ->
                _menhir_run106 _menhir_env (Obj.magic _menhir_stack) MenhirState177
            | LOCAL ->
                _menhir_run100 _menhir_env (Obj.magic _menhir_stack) MenhirState177
            | PONTOEVIRGULA ->
                _menhir_run99 _menhir_env (Obj.magic _menhir_stack) MenhirState177
            | PRINT ->
                _menhir_run24 _menhir_env (Obj.magic _menhir_stack) MenhirState177
            | REPEAT ->
                _menhir_run23 _menhir_env (Obj.magic _menhir_stack) MenhirState177
            | WHILE ->
                _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState177
            | END | RETURN ->
                _menhir_reduce57 _menhir_env (Obj.magic _menhir_stack) MenhirState177
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState177)
        | END ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _v : (Ast.else_block_rule option) =     ( None ) in
            _menhir_goto_option_else_block_rule_ _menhir_env _menhir_stack _v
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | MenhirState182 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_stack = Obj.magic _menhir_stack in
        let ((_menhir_stack, _menhir_s, (x : (Ast.elseif_rule))), _, (xs : (Ast.elseif_rule list))) = _menhir_stack in
        let _v : (Ast.elseif_rule list) =     ( x :: xs ) in
        _menhir_goto_list_elseif_rule_ _menhir_env _menhir_stack _menhir_s _v
    | _ ->
        _menhir_fail ()

and _menhir_reduce92 : _menhir_env -> 'ttv_tail * _menhir_state * (Ast.functioncall) -> 'ttv_return =
  fun _menhir_env _menhir_stack ->
    let (_menhir_stack, _menhir_s, (f : (Ast.functioncall))) = _menhir_stack in
    let _v : (Ast.prefixexp) =                    ( Functioncall(f) ) in
    _menhir_goto_prefixexp _menhir_env _menhir_stack _menhir_s _v

and _menhir_goto_option_PONTOEVIRGULA_ : _menhir_env -> 'ttv_tail -> (unit option) -> 'ttv_return =
  fun _menhir_env _menhir_stack _v ->
    let _menhir_stack = Obj.magic _menhir_stack in
    let _menhir_stack = Obj.magic _menhir_stack in
    let (_3 : (unit option)) = _v in
    let (_menhir_stack, _, (e : (Ast.explist option))) = _menhir_stack in
    let _1 = () in
    let _v : (Ast.retstat) =                                      ( Retstat(e) ) in
    let _menhir_stack = Obj.magic _menhir_stack in
    let _menhir_stack = Obj.magic _menhir_stack in
    let (x : (Ast.retstat)) = _v in
    let _v : (Ast.retstat option) =     ( Some x ) in
    _menhir_goto_option_retstat_ _menhir_env _menhir_stack _v

and _menhir_goto_list_virgula_var_rule_ : _menhir_env -> 'ttv_tail -> _menhir_state -> (Ast.virgula_var_rule list) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    match _menhir_s with
    | MenhirState146 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_stack = Obj.magic _menhir_stack in
        let (xs : (Ast.virgula_var_rule list)) = _v in
        let (_menhir_stack, _menhir_s, (x : (Ast.virgula_var_rule))) = _menhir_stack in
        let _v : (Ast.virgula_var_rule list) =     ( x :: xs ) in
        _menhir_goto_list_virgula_var_rule_ _menhir_env _menhir_stack _menhir_s _v
    | MenhirState142 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_stack = Obj.magic _menhir_stack in
        let (vir : (Ast.virgula_var_rule list)) = _v in
        let (_menhir_stack, _menhir_s, (v : (Ast.var))) = _menhir_stack in
        let _v : (Ast.varlist) =                                 ( Varlist(v,vir) ) in
        let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | ATRIBUICAO ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            (match _tok with
            | ABRECHAVES ->
                _menhir_run30 _menhir_env (Obj.magic _menhir_stack) MenhirState140
            | ABREPARENTESE ->
                _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState140
            | FALSE ->
                _menhir_run28 _menhir_env (Obj.magic _menhir_stack) MenhirState140
            | FLOAT _v ->
                _menhir_run27 _menhir_env (Obj.magic _menhir_stack) MenhirState140 _v
            | FUNCTION ->
                _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState140
            | ID _v ->
                _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState140 _v
            | INT _v ->
                _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState140 _v
            | NIL ->
                _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState140
            | NOT ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState140
            | PONTOPONTOPONTO ->
                _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState140
            | QUADRADO ->
                _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState140
            | STRING _v ->
                _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState140 _v
            | SUBTRACAO ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState140
            | TRUE ->
                _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState140
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState140)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | _ ->
        _menhir_fail ()

and _menhir_goto_list_virgula_exp_rule_ : _menhir_env -> 'ttv_tail -> _menhir_state -> (Ast.virgula_exp_rule list) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    match _menhir_s with
    | MenhirState95 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_stack = Obj.magic _menhir_stack in
        let (xs : (Ast.virgula_exp_rule list)) = _v in
        let (_menhir_stack, _menhir_s, (x : (Ast.virgula_exp_rule))) = _menhir_stack in
        let _v : (Ast.virgula_exp_rule list) =     ( x :: xs ) in
        _menhir_goto_list_virgula_exp_rule_ _menhir_env _menhir_stack _menhir_s _v
    | MenhirState92 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_stack = Obj.magic _menhir_stack in
        let (v : (Ast.virgula_exp_rule list)) = _v in
        let (_menhir_stack, _menhir_s, (e : (Ast.exp))) = _menhir_stack in
        let _v : (Ast.explist) =                               ( ExpList(e,v)) in
        let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
        (match _menhir_s with
        | MenhirState154 | MenhirState26 ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, (x : (Ast.explist))) = _menhir_stack in
            let _v : (Ast.explist option) =     ( Some x ) in
            _menhir_goto_option_explist_ _menhir_env _menhir_stack _menhir_s _v
        | MenhirState102 ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _, (e : (Ast.explist))) = _menhir_stack in
            let _1 = () in
            let _v : (Ast.atribuicao_explist_rule) =                          ( Atribuicao(e)) in
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_stack = Obj.magic _menhir_stack in
            let (x : (Ast.atribuicao_explist_rule)) = _v in
            let _v : (Ast.atribuicao_explist_rule option) =     ( Some x ) in
            _menhir_goto_option_atribuicao_explist_rule_ _menhir_env _menhir_stack _v
        | MenhirState140 ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_stack = Obj.magic _menhir_stack in
            let ((_menhir_stack, _menhir_s, (v : (Ast.varlist))), _, (e : (Ast.explist))) = _menhir_stack in
            let _2 = () in
            let _v : (Ast.stat) =                                    ( Atribuicao(v,e) ) in
            _menhir_goto_stat _menhir_env _menhir_stack _menhir_s _v
        | MenhirState166 ->
            let _menhir_stack = Obj.magic _menhir_stack in
            assert (not _menhir_env._menhir_error);
            let _tok = _menhir_env._menhir_token in
            (match _tok with
            | DO ->
                let _menhir_stack = Obj.magic _menhir_stack in
                let _menhir_env = _menhir_discard _menhir_env in
                let _tok = _menhir_env._menhir_token in
                (match _tok with
                | ABREPARENTESE ->
                    _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState168
                | BREAK ->
                    _menhir_run138 _menhir_env (Obj.magic _menhir_stack) MenhirState168
                | DO ->
                    _menhir_run137 _menhir_env (Obj.magic _menhir_stack) MenhirState168
                | DOISDOISPONTOS ->
                    _menhir_run134 _menhir_env (Obj.magic _menhir_stack) MenhirState168
                | FOR ->
                    _menhir_run124 _menhir_env (Obj.magic _menhir_stack) MenhirState168
                | FUNCTION ->
                    _menhir_run111 _menhir_env (Obj.magic _menhir_stack) MenhirState168
                | GOTO ->
                    _menhir_run109 _menhir_env (Obj.magic _menhir_stack) MenhirState168
                | ID _v ->
                    _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState168 _v
                | IF ->
                    _menhir_run106 _menhir_env (Obj.magic _menhir_stack) MenhirState168
                | LOCAL ->
                    _menhir_run100 _menhir_env (Obj.magic _menhir_stack) MenhirState168
                | PONTOEVIRGULA ->
                    _menhir_run99 _menhir_env (Obj.magic _menhir_stack) MenhirState168
                | PRINT ->
                    _menhir_run24 _menhir_env (Obj.magic _menhir_stack) MenhirState168
                | REPEAT ->
                    _menhir_run23 _menhir_env (Obj.magic _menhir_stack) MenhirState168
                | WHILE ->
                    _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState168
                | END | RETURN ->
                    _menhir_reduce57 _menhir_env (Obj.magic _menhir_stack) MenhirState168
                | _ ->
                    assert (not _menhir_env._menhir_error);
                    _menhir_env._menhir_error <- true;
                    _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState168)
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                let _menhir_stack = Obj.magic _menhir_stack in
                let (_menhir_stack, _menhir_s, _) = _menhir_stack in
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
        | _ ->
            _menhir_fail ())
    | _ ->
        _menhir_fail ()

and _menhir_run37 : _menhir_env -> 'ttv_tail * _menhir_state * (Ast.prefixexp) -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ID _v ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_env = _menhir_discard _menhir_env in
        let _menhir_stack = Obj.magic _menhir_stack in
        let (i : (string)) = _v in
        let ((_menhir_stack, _menhir_s, (p : (Ast.prefixexp))), _) = _menhir_stack in
        let _2 = () in
        let _v : (Ast.var) =                            ( Varponto(p,i) ) in
        _menhir_goto_var _menhir_env _menhir_stack _menhir_s _v
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s

and _menhir_run39 : _menhir_env -> 'ttv_tail * _menhir_state * (Ast.prefixexp) -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ID _v ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_stack = (_menhir_stack, _v) in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | ABRECHAVES ->
            _menhir_run30 _menhir_env (Obj.magic _menhir_stack) MenhirState40
        | ABREPARENTESE ->
            _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState40
        | STRING _v ->
            _menhir_run25 _menhir_env (Obj.magic _menhir_stack) MenhirState40 _v
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState40)
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s

and _menhir_run43 : _menhir_env -> 'ttv_tail * _menhir_state * (Ast.prefixexp) -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ABRECHAVES ->
        _menhir_run30 _menhir_env (Obj.magic _menhir_stack) MenhirState43
    | ABREPARENTESE ->
        _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState43
    | FALSE ->
        _menhir_run28 _menhir_env (Obj.magic _menhir_stack) MenhirState43
    | FLOAT _v ->
        _menhir_run27 _menhir_env (Obj.magic _menhir_stack) MenhirState43 _v
    | FUNCTION ->
        _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState43
    | ID _v ->
        _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState43 _v
    | INT _v ->
        _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState43 _v
    | NIL ->
        _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState43
    | NOT ->
        _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState43
    | PONTOPONTOPONTO ->
        _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState43
    | QUADRADO ->
        _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState43
    | STRING _v ->
        _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState43 _v
    | SUBTRACAO ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState43
    | TRUE ->
        _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState43
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState43

and _menhir_reduce53 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _v : (Ast.fieldsep_field_rule list) =     ( [] ) in
    _menhir_goto_list_fieldsep_field_rule_ _menhir_env _menhir_stack _menhir_s _v

and _menhir_run77 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _menhir_stack = Obj.magic _menhir_stack in
    let _1 = () in
    let _v : (Ast.fieldsep) =             ( Virgula ) in
    _menhir_goto_fieldsep _menhir_env _menhir_stack _menhir_s _v

and _menhir_run78 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _menhir_stack = Obj.magic _menhir_stack in
    let _1 = () in
    let _v : (Ast.fieldsep) =                   ( PontoEVirgula ) in
    _menhir_goto_fieldsep _menhir_env _menhir_stack _menhir_s _v

and _menhir_goto_binop : _menhir_env -> 'ttv_tail -> _menhir_state -> (Ast.binop) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    let _menhir_stack = Obj.magic _menhir_stack in
    assert (not _menhir_env._menhir_error);
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ABRECHAVES ->
        _menhir_run30 _menhir_env (Obj.magic _menhir_stack) MenhirState63
    | ABREPARENTESE ->
        _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState63
    | FALSE ->
        _menhir_run28 _menhir_env (Obj.magic _menhir_stack) MenhirState63
    | FLOAT _v ->
        _menhir_run27 _menhir_env (Obj.magic _menhir_stack) MenhirState63 _v
    | FUNCTION ->
        _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState63
    | ID _v ->
        _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState63 _v
    | INT _v ->
        _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState63 _v
    | NIL ->
        _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState63
    | NOT ->
        _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState63
    | PONTOPONTOPONTO ->
        _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState63
    | QUADRADO ->
        _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState63
    | STRING _v ->
        _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState63 _v
    | SUBTRACAO ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState63
    | TRUE ->
        _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState63
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState63

and _menhir_goto_option_else_block_rule_ : _menhir_env -> 'ttv_tail -> (Ast.else_block_rule option) -> 'ttv_return =
  fun _menhir_env _menhir_stack _v ->
    let _menhir_stack = (_menhir_stack, _v) in
    let _menhir_stack = Obj.magic _menhir_stack in
    assert (not _menhir_env._menhir_error);
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | END ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_env = _menhir_discard _menhir_env in
        let _menhir_stack = Obj.magic _menhir_stack in
        let ((((((_menhir_stack, _menhir_s), _, (e : (Ast.exp))), _), _, (b : (Ast.block))), _, (elif : (Ast.elseif_rule list))), (elbl : (Ast.else_block_rule option))) = _menhir_stack in
        let _7 = () in
        let _3 = () in
        let _1 = () in
        let _v : (Ast.stat) =                                                                       ( If(e,b,elif, elbl) ) in
        _menhir_goto_stat _menhir_env _menhir_stack _menhir_s _v
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        let _menhir_stack = Obj.magic _menhir_stack in
        let ((_menhir_stack, _menhir_s, _), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s

and _menhir_reduce51 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _v : (Ast.elseif_rule list) =     ( [] ) in
    _menhir_goto_list_elseif_rule_ _menhir_env _menhir_stack _menhir_s _v

and _menhir_run172 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ABRECHAVES ->
        _menhir_run30 _menhir_env (Obj.magic _menhir_stack) MenhirState172
    | ABREPARENTESE ->
        _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState172
    | FALSE ->
        _menhir_run28 _menhir_env (Obj.magic _menhir_stack) MenhirState172
    | FLOAT _v ->
        _menhir_run27 _menhir_env (Obj.magic _menhir_stack) MenhirState172 _v
    | FUNCTION ->
        _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState172
    | ID _v ->
        _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState172 _v
    | INT _v ->
        _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState172 _v
    | NIL ->
        _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState172
    | NOT ->
        _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState172
    | PONTOPONTOPONTO ->
        _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState172
    | QUADRADO ->
        _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState172
    | STRING _v ->
        _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState172 _v
    | SUBTRACAO ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState172
    | TRUE ->
        _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState172
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState172

and _menhir_goto_functioncall : _menhir_env -> 'ttv_tail -> _menhir_state -> (Ast.functioncall) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    match _menhir_s with
    | MenhirState1 | MenhirState185 | MenhirState172 | MenhirState166 | MenhirState154 | MenhirState143 | MenhirState140 | MenhirState130 | MenhirState128 | MenhirState126 | MenhirState106 | MenhirState102 | MenhirState93 | MenhirState26 | MenhirState29 | MenhirState84 | MenhirState30 | MenhirState71 | MenhirState68 | MenhirState32 | MenhirState34 | MenhirState63 | MenhirState43 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        _menhir_reduce92 _menhir_env (Obj.magic _menhir_stack)
    | MenhirState0 | MenhirState196 | MenhirState22 | MenhirState23 | MenhirState177 | MenhirState174 | MenhirState108 | MenhirState168 | MenhirState133 | MenhirState137 | MenhirState149 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | ABREPARENTESE | BREAK | DO | DOISDOISPONTOS | ELSE | ELSEIF | END | EOF | FOR | FUNCTION | GOTO | ID _ | IF | LOCAL | PONTOEVIRGULA | PRINT | REPEAT | RETURN | UNTIL | WHILE ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, (f : (Ast.functioncall))) = _menhir_stack in
            let _v : (Ast.stat) =                    ( Functioncall(f) ) in
            _menhir_goto_stat _menhir_env _menhir_stack _menhir_s _v
        | ABRECHAVES | ABRECOLCHETE | DOISPONTOS | PONTO | STRING _ ->
            _menhir_reduce92 _menhir_env (Obj.magic _menhir_stack)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | _ ->
        _menhir_fail ()

and _menhir_goto_option_explist_ : _menhir_env -> 'ttv_tail -> _menhir_state -> (Ast.explist option) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    match _menhir_s with
    | MenhirState26 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | FECHAPARENTESE ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_env = _menhir_discard _menhir_env in
            let _menhir_stack = Obj.magic _menhir_stack in
            let ((_menhir_stack, _menhir_s), _, (e : (Ast.explist option))) = _menhir_stack in
            let _3 = () in
            let _1 = () in
            let _v : (Ast.args) =                                             ( ArgsParentese(e)) in
            _menhir_goto_args _menhir_env _menhir_stack _menhir_s _v
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | MenhirState154 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | PONTOEVIRGULA ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_env = _menhir_discard _menhir_env in
            let _menhir_stack = Obj.magic _menhir_stack in
            let x = () in
            let _v : (unit option) =     ( Some x ) in
            _menhir_goto_option_PONTOEVIRGULA_ _menhir_env _menhir_stack _v
        | ELSE | ELSEIF | END | EOF | UNTIL ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _v : (unit option) =     ( None ) in
            _menhir_goto_option_PONTOEVIRGULA_ _menhir_env _menhir_stack _v
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | _ ->
        _menhir_fail ()

and _menhir_reduce63 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _v : (Ast.virgula_var_rule list) =     ( [] ) in
    _menhir_goto_list_virgula_var_rule_ _menhir_env _menhir_stack _menhir_s _v

and _menhir_run143 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ABREPARENTESE ->
        _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState143
    | ID _v ->
        _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState143 _v
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState143

and _menhir_reduce91 : _menhir_env -> 'ttv_tail * _menhir_state * (Ast.var) -> 'ttv_return =
  fun _menhir_env _menhir_stack ->
    let (_menhir_stack, _menhir_s, (v : (Ast.var))) = _menhir_stack in
    let _v : (Ast.prefixexp) =           ( Var(v) ) in
    _menhir_goto_prefixexp _menhir_env _menhir_stack _menhir_s _v

and _menhir_goto_option_doispontos_id_rule_ : _menhir_env -> 'ttv_tail -> (Ast.doispontos_id_rule option) -> 'ttv_return =
  fun _menhir_env _menhir_stack _v ->
    let _menhir_stack = Obj.magic _menhir_stack in
    let _menhir_stack = Obj.magic _menhir_stack in
    let (d : (Ast.doispontos_id_rule option)) = _v in
    let ((_menhir_stack, (i : (string))), _, (p : (Ast.ponto_id_rule list))) = _menhir_stack in
    let _v : (Ast.funcname) =                                                 ( Funcname(i, p, d) ) in
    let _menhir_stack = (_menhir_stack, _v) in
    let _menhir_stack = Obj.magic _menhir_stack in
    assert (not _menhir_env._menhir_error);
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ABREPARENTESE ->
        _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState122
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState122

and _menhir_goto_option_virgula_tres_pontos_rule_ : _menhir_env -> 'ttv_tail -> (Ast.virgula_tres_pontos_rule option) -> 'ttv_return =
  fun _menhir_env _menhir_stack _v ->
    let _menhir_stack = Obj.magic _menhir_stack in
    let _menhir_stack = Obj.magic _menhir_stack in
    let (v : (Ast.virgula_tres_pontos_rule option)) = _v in
    let (_menhir_stack, _menhir_s, (n : (Ast.namelist))) = _menhir_stack in
    let _v : (Ast.parlist) =                                            ( NameListVirgula(n,v) ) in
    _menhir_goto_parlist _menhir_env _menhir_stack _menhir_s _v

and _menhir_goto_option_atribuicao_explist_rule_ : _menhir_env -> 'ttv_tail -> (Ast.atribuicao_explist_rule option) -> 'ttv_return =
  fun _menhir_env _menhir_stack _v ->
    let _menhir_stack = Obj.magic _menhir_stack in
    let _menhir_stack = Obj.magic _menhir_stack in
    let (a : (Ast.atribuicao_explist_rule option)) = _v in
    let ((_menhir_stack, _menhir_s), _, (n : (Ast.namelist))) = _menhir_stack in
    let _1 = () in
    let _v : (Ast.stat) =                                                 ( Local(n,a) ) in
    _menhir_goto_stat _menhir_env _menhir_stack _menhir_s _v

and _menhir_goto_option_parlist_ : _menhir_env -> 'ttv_tail -> _menhir_state -> (Ast.parlist option) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    let _menhir_stack = Obj.magic _menhir_stack in
    assert (not _menhir_env._menhir_error);
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | FECHAPARENTESE ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | ABREPARENTESE ->
            _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState22
        | BREAK ->
            _menhir_run138 _menhir_env (Obj.magic _menhir_stack) MenhirState22
        | DO ->
            _menhir_run137 _menhir_env (Obj.magic _menhir_stack) MenhirState22
        | DOISDOISPONTOS ->
            _menhir_run134 _menhir_env (Obj.magic _menhir_stack) MenhirState22
        | FOR ->
            _menhir_run124 _menhir_env (Obj.magic _menhir_stack) MenhirState22
        | FUNCTION ->
            _menhir_run111 _menhir_env (Obj.magic _menhir_stack) MenhirState22
        | GOTO ->
            _menhir_run109 _menhir_env (Obj.magic _menhir_stack) MenhirState22
        | ID _v ->
            _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState22 _v
        | IF ->
            _menhir_run106 _menhir_env (Obj.magic _menhir_stack) MenhirState22
        | LOCAL ->
            _menhir_run100 _menhir_env (Obj.magic _menhir_stack) MenhirState22
        | PONTOEVIRGULA ->
            _menhir_run99 _menhir_env (Obj.magic _menhir_stack) MenhirState22
        | PRINT ->
            _menhir_run24 _menhir_env (Obj.magic _menhir_stack) MenhirState22
        | REPEAT ->
            _menhir_run23 _menhir_env (Obj.magic _menhir_stack) MenhirState22
        | WHILE ->
            _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState22
        | END | RETURN ->
            _menhir_reduce57 _menhir_env (Obj.magic _menhir_stack) MenhirState22
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState22)
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s

and _menhir_goto_parlist : _menhir_env -> 'ttv_tail -> _menhir_state -> (Ast.parlist) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = Obj.magic _menhir_stack in
    let _menhir_stack = Obj.magic _menhir_stack in
    let (x : (Ast.parlist)) = _v in
    let _v : (Ast.parlist option) =     ( Some x ) in
    _menhir_goto_option_parlist_ _menhir_env _menhir_stack _menhir_s _v

and _menhir_goto_option_comma_exp_rule_ : _menhir_env -> 'ttv_tail -> _menhir_state -> (Ast.comma_exp_rule option) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    let _menhir_stack = Obj.magic _menhir_stack in
    assert (not _menhir_env._menhir_error);
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | DO ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | ABREPARENTESE ->
            _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState133
        | BREAK ->
            _menhir_run138 _menhir_env (Obj.magic _menhir_stack) MenhirState133
        | DO ->
            _menhir_run137 _menhir_env (Obj.magic _menhir_stack) MenhirState133
        | DOISDOISPONTOS ->
            _menhir_run134 _menhir_env (Obj.magic _menhir_stack) MenhirState133
        | FOR ->
            _menhir_run124 _menhir_env (Obj.magic _menhir_stack) MenhirState133
        | FUNCTION ->
            _menhir_run111 _menhir_env (Obj.magic _menhir_stack) MenhirState133
        | GOTO ->
            _menhir_run109 _menhir_env (Obj.magic _menhir_stack) MenhirState133
        | ID _v ->
            _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState133 _v
        | IF ->
            _menhir_run106 _menhir_env (Obj.magic _menhir_stack) MenhirState133
        | LOCAL ->
            _menhir_run100 _menhir_env (Obj.magic _menhir_stack) MenhirState133
        | PONTOEVIRGULA ->
            _menhir_run99 _menhir_env (Obj.magic _menhir_stack) MenhirState133
        | PRINT ->
            _menhir_run24 _menhir_env (Obj.magic _menhir_stack) MenhirState133
        | REPEAT ->
            _menhir_run23 _menhir_env (Obj.magic _menhir_stack) MenhirState133
        | WHILE ->
            _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState133
        | END | RETURN ->
            _menhir_reduce57 _menhir_env (Obj.magic _menhir_stack) MenhirState133
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState133)
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s

and _menhir_reduce59 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _v : (Ast.virgula_exp_rule list) =     ( [] ) in
    _menhir_goto_list_virgula_exp_rule_ _menhir_env _menhir_stack _menhir_s _v

and _menhir_run93 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ABRECHAVES ->
        _menhir_run30 _menhir_env (Obj.magic _menhir_stack) MenhirState93
    | ABREPARENTESE ->
        _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState93
    | FALSE ->
        _menhir_run28 _menhir_env (Obj.magic _menhir_stack) MenhirState93
    | FLOAT _v ->
        _menhir_run27 _menhir_env (Obj.magic _menhir_stack) MenhirState93 _v
    | FUNCTION ->
        _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState93
    | ID _v ->
        _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState93 _v
    | INT _v ->
        _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState93 _v
    | NIL ->
        _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState93
    | NOT ->
        _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState93
    | PONTOPONTOPONTO ->
        _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState93
    | QUADRADO ->
        _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState93
    | STRING _v ->
        _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState93 _v
    | SUBTRACAO ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState93
    | TRUE ->
        _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState93
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState93

and _menhir_goto_prefixexp : _menhir_env -> 'ttv_tail -> _menhir_state -> (Ast.prefixexp) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    match _menhir_s with
    | MenhirState1 | MenhirState185 | MenhirState172 | MenhirState166 | MenhirState154 | MenhirState140 | MenhirState130 | MenhirState128 | MenhirState126 | MenhirState106 | MenhirState102 | MenhirState93 | MenhirState26 | MenhirState29 | MenhirState84 | MenhirState30 | MenhirState71 | MenhirState68 | MenhirState32 | MenhirState63 | MenhirState43 | MenhirState34 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | ABRECHAVES ->
            _menhir_run30 _menhir_env (Obj.magic _menhir_stack) MenhirState36
        | ABRECOLCHETE ->
            _menhir_run43 _menhir_env (Obj.magic _menhir_stack) MenhirState36
        | ABREPARENTESE ->
            _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState36
        | DOISPONTOS ->
            _menhir_run39 _menhir_env (Obj.magic _menhir_stack) MenhirState36
        | PONTO ->
            _menhir_run37 _menhir_env (Obj.magic _menhir_stack) MenhirState36
        | STRING _v ->
            _menhir_run25 _menhir_env (Obj.magic _menhir_stack) MenhirState36 _v
        | AND | BREAK | DIFERENTE | DIVISAO | DO | DOISDOISPONTOS | ELSE | ELSEIF | END | EOF | EXPONENCIACAO | FECHACHAVES | FECHACOLCHETE | FECHAPARENTESE | FOR | FUNCTION | GOTO | ID _ | IF | IGUALDADE | LOCAL | MAIOR | MAIORIGUAL | MENOR | MENORIGUAL | MODULO | MULTIPLICACAO | OR | PONTOEVIRGULA | PONTOPONTO | PRINT | REPEAT | RETURN | SOMA | SUBTRACAO | THEN | UNTIL | VIRGULA | WHILE ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, (p : (Ast.prefixexp))) = _menhir_stack in
            let _v : (Ast.exp) =                 ( Prefixexp(p) ) in
            _menhir_goto_exp _menhir_env _menhir_stack _menhir_s _v
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState36)
    | MenhirState0 | MenhirState196 | MenhirState22 | MenhirState23 | MenhirState177 | MenhirState174 | MenhirState108 | MenhirState168 | MenhirState133 | MenhirState137 | MenhirState149 | MenhirState143 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | ABRECHAVES ->
            _menhir_run30 _menhir_env (Obj.magic _menhir_stack) MenhirState145
        | ABRECOLCHETE ->
            _menhir_run43 _menhir_env (Obj.magic _menhir_stack) MenhirState145
        | ABREPARENTESE ->
            _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState145
        | DOISPONTOS ->
            _menhir_run39 _menhir_env (Obj.magic _menhir_stack) MenhirState145
        | PONTO ->
            _menhir_run37 _menhir_env (Obj.magic _menhir_stack) MenhirState145
        | STRING _v ->
            _menhir_run25 _menhir_env (Obj.magic _menhir_stack) MenhirState145 _v
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState145)
    | _ ->
        _menhir_fail ()

and _menhir_goto_field : _menhir_env -> 'ttv_tail -> _menhir_state -> (Ast.field) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    match _menhir_s with
    | MenhirState30 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | PONTOEVIRGULA ->
            _menhir_run78 _menhir_env (Obj.magic _menhir_stack) MenhirState76
        | VIRGULA ->
            _menhir_run77 _menhir_env (Obj.magic _menhir_stack) MenhirState76
        | FECHACHAVES ->
            _menhir_reduce53 _menhir_env (Obj.magic _menhir_stack) MenhirState76
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState76)
    | MenhirState84 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_stack = Obj.magic _menhir_stack in
        let ((_menhir_stack, _menhir_s, (fs : (Ast.fieldsep))), _, (f : (Ast.field))) = _menhir_stack in
        let _v : (Ast.fieldsep_field_rule) =                         ( FieldSepField(fs,f)) in
        let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | PONTOEVIRGULA ->
            _menhir_run78 _menhir_env (Obj.magic _menhir_stack) MenhirState82
        | VIRGULA ->
            _menhir_run77 _menhir_env (Obj.magic _menhir_stack) MenhirState82
        | FECHACHAVES ->
            _menhir_reduce53 _menhir_env (Obj.magic _menhir_stack) MenhirState82
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState82)
    | _ ->
        _menhir_fail ()

and _menhir_run47 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _menhir_stack = Obj.magic _menhir_stack in
    let _1 = () in
    let _v : (Ast.binop) =               ( Subtracao ) in
    _menhir_goto_binop _menhir_env _menhir_stack _menhir_s _v

and _menhir_run48 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _menhir_stack = Obj.magic _menhir_stack in
    let _1 = () in
    let _v : (Ast.binop) =          ( Soma ) in
    _menhir_goto_binop _menhir_env _menhir_stack _menhir_s _v

and _menhir_run49 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _menhir_stack = Obj.magic _menhir_stack in
    let _1 = () in
    let _v : (Ast.binop) =                ( PontoPonto) in
    _menhir_goto_binop _menhir_env _menhir_stack _menhir_s _v

and _menhir_run50 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _menhir_stack = Obj.magic _menhir_stack in
    let _1 = () in
    let _v : (Ast.binop) =        ( Or) in
    _menhir_goto_binop _menhir_env _menhir_stack _menhir_s _v

and _menhir_run51 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _menhir_stack = Obj.magic _menhir_stack in
    let _1 = () in
    let _v : (Ast.binop) =                   ( Multiplicacao ) in
    _menhir_goto_binop _menhir_env _menhir_stack _menhir_s _v

and _menhir_run52 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _menhir_stack = Obj.magic _menhir_stack in
    let _1 = () in
    let _v : (Ast.binop) =            ( Modulo ) in
    _menhir_goto_binop _menhir_env _menhir_stack _menhir_s _v

and _menhir_run53 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _menhir_stack = Obj.magic _menhir_stack in
    let _1 = () in
    let _v : (Ast.binop) =                ( MenorIgual ) in
    _menhir_goto_binop _menhir_env _menhir_stack _menhir_s _v

and _menhir_run54 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _menhir_stack = Obj.magic _menhir_stack in
    let _1 = () in
    let _v : (Ast.binop) =           ( Menor) in
    _menhir_goto_binop _menhir_env _menhir_stack _menhir_s _v

and _menhir_run55 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _menhir_stack = Obj.magic _menhir_stack in
    let _1 = () in
    let _v : (Ast.binop) =                ( MaiorIgual) in
    _menhir_goto_binop _menhir_env _menhir_stack _menhir_s _v

and _menhir_run56 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _menhir_stack = Obj.magic _menhir_stack in
    let _1 = () in
    let _v : (Ast.binop) =           ( Maior) in
    _menhir_goto_binop _menhir_env _menhir_stack _menhir_s _v

and _menhir_run57 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _menhir_stack = Obj.magic _menhir_stack in
    let _1 = () in
    let _v : (Ast.binop) =               ( Igualdade) in
    _menhir_goto_binop _menhir_env _menhir_stack _menhir_s _v

and _menhir_run59 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _menhir_stack = Obj.magic _menhir_stack in
    let _1 = () in
    let _v : (Ast.binop) =                   ( Exponenciacao ) in
    _menhir_goto_binop _menhir_env _menhir_stack _menhir_s _v

and _menhir_run60 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _menhir_stack = Obj.magic _menhir_stack in
    let _1 = () in
    let _v : (Ast.binop) =             ( Divisao ) in
    _menhir_goto_binop _menhir_env _menhir_stack _menhir_s _v

and _menhir_run61 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _menhir_stack = Obj.magic _menhir_stack in
    let _1 = () in
    let _v : (Ast.binop) =               ( Diferente) in
    _menhir_goto_binop _menhir_env _menhir_stack _menhir_s _v

and _menhir_run62 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _menhir_stack = Obj.magic _menhir_stack in
    let _1 = () in
    let _v : (Ast.binop) =         ( And) in
    _menhir_goto_binop _menhir_env _menhir_stack _menhir_s _v

and _menhir_fail : unit -> 'a =
  fun () ->
    Printf.fprintf Pervasives.stderr "Internal failure -- please contact the parser generator's developers.\n%!";
    assert false

and _menhir_goto_option_retstat_ : _menhir_env -> 'ttv_tail -> (Ast.retstat option) -> 'ttv_return =
  fun _menhir_env _menhir_stack _v ->
    let _menhir_stack = Obj.magic _menhir_stack in
    let _menhir_stack = Obj.magic _menhir_stack in
    let (r : (Ast.retstat option)) = _v in
    let (_menhir_stack, _menhir_s, (s : (Ast.stat list))) = _menhir_stack in
    let _v : (Ast.block) =                        ( Block(s,r)) in
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    match _menhir_s with
    | MenhirState137 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | END ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_env = _menhir_discard _menhir_env in
            let _menhir_stack = Obj.magic _menhir_stack in
            let ((_menhir_stack, _menhir_s), _, (b : (Ast.block))) = _menhir_stack in
            let _3 = () in
            let _1 = () in
            let _v : (Ast.stat) =                    ( Do(b) ) in
            _menhir_goto_stat _menhir_env _menhir_stack _menhir_s _v
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | MenhirState133 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | END ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_env = _menhir_discard _menhir_env in
            let _menhir_stack = Obj.magic _menhir_stack in
            let ((((((((_menhir_stack, _menhir_s), _, (i : (string))), _), _, (e : (Ast.exp))), _), _, (ec : (Ast.exp))), _, (c : (Ast.comma_exp_rule option))), _, (b : (Ast.block))) = _menhir_stack in
            let _10 = () in
            let _8 = () in
            let _5 = () in
            let _3 = () in
            let _1 = () in
            let _v : (Ast.stat) =                                                                               ( For1(i, e, ec, c, b)) in
            _menhir_goto_stat _menhir_env _menhir_stack _menhir_s _v
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | MenhirState168 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | END ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_env = _menhir_discard _menhir_env in
            let _menhir_stack = Obj.magic _menhir_stack in
            let ((((_menhir_stack, _menhir_s), _, (n : (Ast.namelist))), _, (e : (Ast.explist))), _, (b : (Ast.block))) = _menhir_stack in
            let _7 = () in
            let _5 = () in
            let _3 = () in
            let _1 = () in
            let _v : (Ast.stat) =                                                ( For2(n, e, b) ) in
            _menhir_goto_stat _menhir_env _menhir_stack _menhir_s _v
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | MenhirState108 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | ELSEIF ->
            _menhir_run172 _menhir_env (Obj.magic _menhir_stack) MenhirState171
        | ELSE | END ->
            _menhir_reduce51 _menhir_env (Obj.magic _menhir_stack) MenhirState171
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState171)
    | MenhirState174 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_stack = Obj.magic _menhir_stack in
        let ((((_menhir_stack, _menhir_s), _, (e : (Ast.exp))), _), _, (b : (Ast.block))) = _menhir_stack in
        let _3 = () in
        let _1 = () in
        let _v : (Ast.elseif_rule) =                               ( Elseif(e,b) ) in
        let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | ELSEIF ->
            _menhir_run172 _menhir_env (Obj.magic _menhir_stack) MenhirState182
        | ELSE | END ->
            _menhir_reduce51 _menhir_env (Obj.magic _menhir_stack) MenhirState182
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState182)
    | MenhirState177 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _, (b : (Ast.block))) = _menhir_stack in
        let _1 = () in
        let _v : (Ast.else_block_rule) =                  ( Else(b) ) in
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_stack = Obj.magic _menhir_stack in
        let (x : (Ast.else_block_rule)) = _v in
        let _v : (Ast.else_block_rule option) =     ( Some x ) in
        _menhir_goto_option_else_block_rule_ _menhir_env _menhir_stack _v
    | MenhirState23 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | UNTIL ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            (match _tok with
            | ABRECHAVES ->
                _menhir_run30 _menhir_env (Obj.magic _menhir_stack) MenhirState185
            | ABREPARENTESE ->
                _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState185
            | FALSE ->
                _menhir_run28 _menhir_env (Obj.magic _menhir_stack) MenhirState185
            | FLOAT _v ->
                _menhir_run27 _menhir_env (Obj.magic _menhir_stack) MenhirState185 _v
            | FUNCTION ->
                _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState185
            | ID _v ->
                _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState185 _v
            | INT _v ->
                _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState185 _v
            | NIL ->
                _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState185
            | NOT ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState185
            | PONTOPONTOPONTO ->
                _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState185
            | QUADRADO ->
                _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState185
            | STRING _v ->
                _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState185 _v
            | SUBTRACAO ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState185
            | TRUE ->
                _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState185
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState185)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | MenhirState22 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | END ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_env = _menhir_discard _menhir_env in
            let _menhir_stack = Obj.magic _menhir_stack in
            let (((_menhir_stack, _menhir_s), _, (p : (Ast.parlist option))), _, (b : (Ast.block))) = _menhir_stack in
            let _5 = () in
            let _3 = () in
            let _1 = () in
            let _v : (Ast.funcbody) =                                                         ( Funcbody(p,b) ) in
            (match _menhir_s with
            | MenhirState122 ->
                let _menhir_stack = Obj.magic _menhir_stack in
                let _menhir_stack = Obj.magic _menhir_stack in
                let (fb : (Ast.funcbody)) = _v in
                let ((_menhir_stack, _menhir_s), (fn : (Ast.funcname))) = _menhir_stack in
                let _1 = () in
                let _v : (Ast.stat) =                                      ( Function(fn, fb) ) in
                _menhir_goto_stat _menhir_env _menhir_stack _menhir_s _v
            | MenhirState11 ->
                let _menhir_stack = Obj.magic _menhir_stack in
                let _menhir_stack = Obj.magic _menhir_stack in
                let (f : (Ast.funcbody)) = _v in
                let (_menhir_stack, _menhir_s) = _menhir_stack in
                let _1 = () in
                let _v : (Ast.functiondef) =                         ( FuncDef(f) ) in
                let _menhir_stack = Obj.magic _menhir_stack in
                let _menhir_stack = Obj.magic _menhir_stack in
                let (_1 : (Ast.functiondef)) = _v in
                let _v : (Ast.exp) =                 ( FunctionDef ) in
                _menhir_goto_exp _menhir_env _menhir_stack _menhir_s _v
            | _ ->
                _menhir_fail ())
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | MenhirState196 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | END ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_env = _menhir_discard _menhir_env in
            let _menhir_stack = Obj.magic _menhir_stack in
            let ((((_menhir_stack, _menhir_s), _, (e : (Ast.exp))), _), _, (b : (Ast.block))) = _menhir_stack in
            let _5 = () in
            let _3 = () in
            let _1 = () in
            let _v : (Ast.stat) =                                ( While(e,b)) in
            _menhir_goto_stat _menhir_env _menhir_stack _menhir_s _v
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | MenhirState0 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | EOF ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, (b : (Ast.block))) = _menhir_stack in
            let _2 = () in
            let _v : (Ast.program) =                 ( Program(b) ) in
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_1 : (Ast.program)) = _v in
            Obj.magic _1
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | _ ->
        _menhir_fail ()

and _menhir_goto_args : _menhir_env -> 'ttv_tail -> _menhir_state -> (Ast.args) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    match _menhir_s with
    | MenhirState40 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_stack = Obj.magic _menhir_stack in
        let (a : (Ast.args)) = _v in
        let (((_menhir_stack, _menhir_s, (p : (Ast.prefixexp))), _), (i : (string))) = _menhir_stack in
        let _2 = () in
        let _v : (Ast.functioncall) =                                        ( PrefixoDoisPontosIdArgs(p, i, a) ) in
        _menhir_goto_functioncall _menhir_env _menhir_stack _menhir_s _v
    | MenhirState145 | MenhirState36 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_stack = Obj.magic _menhir_stack in
        let (a : (Ast.args)) = _v in
        let (_menhir_stack, _menhir_s, (p : (Ast.prefixexp))) = _menhir_stack in
        let _v : (Ast.functioncall) =                        ( PrefixexpArgs(p,a) ) in
        _menhir_goto_functioncall _menhir_env _menhir_stack _menhir_s _v
    | MenhirState24 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_stack = Obj.magic _menhir_stack in
        let (a : (Ast.args)) = _v in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        let _1 = () in
        let _v : (Ast.stat) =                  ( Print(a) ) in
        _menhir_goto_stat _menhir_env _menhir_stack _menhir_s _v
    | _ ->
        _menhir_fail ()

and _menhir_reduce76 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _v : (Ast.explist option) =     ( None ) in
    _menhir_goto_option_explist_ _menhir_env _menhir_stack _menhir_s _v

and _menhir_goto_var : _menhir_env -> 'ttv_tail -> _menhir_state -> (Ast.var) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    match _menhir_s with
    | MenhirState1 | MenhirState185 | MenhirState172 | MenhirState166 | MenhirState154 | MenhirState140 | MenhirState130 | MenhirState128 | MenhirState126 | MenhirState106 | MenhirState102 | MenhirState93 | MenhirState26 | MenhirState29 | MenhirState84 | MenhirState30 | MenhirState71 | MenhirState68 | MenhirState63 | MenhirState43 | MenhirState34 | MenhirState32 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        _menhir_reduce91 _menhir_env (Obj.magic _menhir_stack)
    | MenhirState0 | MenhirState196 | MenhirState22 | MenhirState23 | MenhirState177 | MenhirState174 | MenhirState108 | MenhirState168 | MenhirState133 | MenhirState149 | MenhirState137 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | VIRGULA ->
            _menhir_run143 _menhir_env (Obj.magic _menhir_stack) MenhirState142
        | ABRECHAVES | ABRECOLCHETE | ABREPARENTESE | DOISPONTOS | PONTO | STRING _ ->
            _menhir_reduce91 _menhir_env (Obj.magic _menhir_stack)
        | ATRIBUICAO ->
            _menhir_reduce63 _menhir_env (Obj.magic _menhir_stack) MenhirState142
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState142)
    | MenhirState143 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | ATRIBUICAO | VIRGULA ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let ((_menhir_stack, _menhir_s), _, (v : (Ast.var))) = _menhir_stack in
            let _1 = () in
            let _v : (Ast.virgula_var_rule) =                   ( VirgulaVarRule(v) ) in
            let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
            let _menhir_stack = Obj.magic _menhir_stack in
            assert (not _menhir_env._menhir_error);
            let _tok = _menhir_env._menhir_token in
            (match _tok with
            | VIRGULA ->
                _menhir_run143 _menhir_env (Obj.magic _menhir_stack) MenhirState146
            | ATRIBUICAO ->
                _menhir_reduce63 _menhir_env (Obj.magic _menhir_stack) MenhirState146
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState146)
        | ABRECHAVES | ABRECOLCHETE | ABREPARENTESE | DOISPONTOS | PONTO | STRING _ ->
            _menhir_reduce91 _menhir_env (Obj.magic _menhir_stack)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | _ ->
        _menhir_fail ()

and _menhir_goto_list_ponto_id_rule_ : _menhir_env -> 'ttv_tail -> _menhir_state -> (Ast.ponto_id_rule list) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    match _menhir_s with
    | MenhirState115 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_stack = Obj.magic _menhir_stack in
        let ((_menhir_stack, _menhir_s, (x : (Ast.ponto_id_rule))), _, (xs : (Ast.ponto_id_rule list))) = _menhir_stack in
        let _v : (Ast.ponto_id_rule list) =     ( x :: xs ) in
        _menhir_goto_list_ponto_id_rule_ _menhir_env _menhir_stack _menhir_s _v
    | MenhirState112 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | DOISPONTOS ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            (match _tok with
            | ID _v ->
                let _menhir_stack = Obj.magic _menhir_stack in
                let _menhir_env = _menhir_discard _menhir_env in
                let _menhir_stack = Obj.magic _menhir_stack in
                let (i : (string)) = _v in
                let _1 = () in
                let _v : (Ast.doispontos_id_rule) =                     ( Doispontos(i) ) in
                let _menhir_stack = Obj.magic _menhir_stack in
                let _menhir_stack = Obj.magic _menhir_stack in
                let (x : (Ast.doispontos_id_rule)) = _v in
                let _v : (Ast.doispontos_id_rule option) =     ( Some x ) in
                _menhir_goto_option_doispontos_id_rule_ _menhir_env _menhir_stack _v
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                let _menhir_stack = Obj.magic _menhir_stack in
                raise _eRR)
        | ABREPARENTESE ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _v : (Ast.doispontos_id_rule option) =     ( None ) in
            _menhir_goto_option_doispontos_id_rule_ _menhir_env _menhir_stack _v
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | _ ->
        _menhir_fail ()

and _menhir_goto_list_virgula_id_rule_ : _menhir_env -> 'ttv_tail -> _menhir_state -> (Ast.virgula_id_rule list) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    match _menhir_s with
    | MenhirState17 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_stack = Obj.magic _menhir_stack in
        let (xs : (Ast.virgula_id_rule list)) = _v in
        let (_menhir_stack, _menhir_s, (x : (Ast.virgula_id_rule))) = _menhir_stack in
        let _v : (Ast.virgula_id_rule list) =     ( x :: xs ) in
        _menhir_goto_list_virgula_id_rule_ _menhir_env _menhir_stack _menhir_s _v
    | MenhirState125 | MenhirState14 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_stack = Obj.magic _menhir_stack in
        let (v : (Ast.virgula_id_rule list)) = _v in
        let (_menhir_stack, _menhir_s, (i : (string))) = _menhir_stack in
        let _v : (Ast.namelist) =                             ( Namelist(i,v) ) in
        let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
        (match _menhir_s with
        | MenhirState100 ->
            let _menhir_stack = Obj.magic _menhir_stack in
            assert (not _menhir_env._menhir_error);
            let _tok = _menhir_env._menhir_token in
            (match _tok with
            | ATRIBUICAO ->
                let _menhir_stack = Obj.magic _menhir_stack in
                let _menhir_env = _menhir_discard _menhir_env in
                let _tok = _menhir_env._menhir_token in
                (match _tok with
                | ABRECHAVES ->
                    _menhir_run30 _menhir_env (Obj.magic _menhir_stack) MenhirState102
                | ABREPARENTESE ->
                    _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState102
                | FALSE ->
                    _menhir_run28 _menhir_env (Obj.magic _menhir_stack) MenhirState102
                | FLOAT _v ->
                    _menhir_run27 _menhir_env (Obj.magic _menhir_stack) MenhirState102 _v
                | FUNCTION ->
                    _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState102
                | ID _v ->
                    _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState102 _v
                | INT _v ->
                    _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState102 _v
                | NIL ->
                    _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState102
                | NOT ->
                    _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState102
                | PONTOPONTOPONTO ->
                    _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState102
                | QUADRADO ->
                    _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState102
                | STRING _v ->
                    _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState102 _v
                | SUBTRACAO ->
                    _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState102
                | TRUE ->
                    _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState102
                | _ ->
                    assert (not _menhir_env._menhir_error);
                    _menhir_env._menhir_error <- true;
                    _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState102)
            | ABREPARENTESE | BREAK | DO | DOISDOISPONTOS | ELSE | ELSEIF | END | EOF | FOR | FUNCTION | GOTO | ID _ | IF | LOCAL | PONTOEVIRGULA | PRINT | REPEAT | RETURN | UNTIL | WHILE ->
                let _menhir_stack = Obj.magic _menhir_stack in
                let _v : (Ast.atribuicao_explist_rule option) =     ( None ) in
                _menhir_goto_option_atribuicao_explist_rule_ _menhir_env _menhir_stack _v
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                let _menhir_stack = Obj.magic _menhir_stack in
                let (_menhir_stack, _menhir_s, _) = _menhir_stack in
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
        | MenhirState124 ->
            let _menhir_stack = Obj.magic _menhir_stack in
            assert (not _menhir_env._menhir_error);
            let _tok = _menhir_env._menhir_token in
            (match _tok with
            | IN ->
                let _menhir_stack = Obj.magic _menhir_stack in
                let _menhir_env = _menhir_discard _menhir_env in
                let _tok = _menhir_env._menhir_token in
                (match _tok with
                | ABRECHAVES ->
                    _menhir_run30 _menhir_env (Obj.magic _menhir_stack) MenhirState166
                | ABREPARENTESE ->
                    _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState166
                | FALSE ->
                    _menhir_run28 _menhir_env (Obj.magic _menhir_stack) MenhirState166
                | FLOAT _v ->
                    _menhir_run27 _menhir_env (Obj.magic _menhir_stack) MenhirState166 _v
                | FUNCTION ->
                    _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState166
                | ID _v ->
                    _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState166 _v
                | INT _v ->
                    _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState166 _v
                | NIL ->
                    _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState166
                | NOT ->
                    _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState166
                | PONTOPONTOPONTO ->
                    _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState166
                | QUADRADO ->
                    _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState166
                | STRING _v ->
                    _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState166 _v
                | SUBTRACAO ->
                    _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState166
                | TRUE ->
                    _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState166
                | _ ->
                    assert (not _menhir_env._menhir_error);
                    _menhir_env._menhir_error <- true;
                    _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState166)
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                let _menhir_stack = Obj.magic _menhir_stack in
                let (_menhir_stack, _menhir_s, _) = _menhir_stack in
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
        | MenhirState12 ->
            let _menhir_stack = Obj.magic _menhir_stack in
            assert (not _menhir_env._menhir_error);
            let _tok = _menhir_env._menhir_token in
            (match _tok with
            | VIRGULA ->
                let _menhir_stack = Obj.magic _menhir_stack in
                let _menhir_env = _menhir_discard _menhir_env in
                let _tok = _menhir_env._menhir_token in
                (match _tok with
                | PONTOPONTOPONTO ->
                    let _menhir_stack = Obj.magic _menhir_stack in
                    let _menhir_env = _menhir_discard _menhir_env in
                    let _menhir_stack = Obj.magic _menhir_stack in
                    let _2 = () in
                    let _1 = () in
                    let _v : (Ast.virgula_tres_pontos_rule) =                             (  VirgulaPPP ) in
                    let _menhir_stack = Obj.magic _menhir_stack in
                    let _menhir_stack = Obj.magic _menhir_stack in
                    let (x : (Ast.virgula_tres_pontos_rule)) = _v in
                    let _v : (Ast.virgula_tres_pontos_rule option) =     ( Some x ) in
                    _menhir_goto_option_virgula_tres_pontos_rule_ _menhir_env _menhir_stack _v
                | _ ->
                    assert (not _menhir_env._menhir_error);
                    _menhir_env._menhir_error <- true;
                    let _menhir_stack = Obj.magic _menhir_stack in
                    raise _eRR)
            | FECHAPARENTESE ->
                let _menhir_stack = Obj.magic _menhir_stack in
                let _v : (Ast.virgula_tres_pontos_rule option) =     ( None ) in
                _menhir_goto_option_virgula_tres_pontos_rule_ _menhir_env _menhir_stack _v
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                let _menhir_stack = Obj.magic _menhir_stack in
                let (_menhir_stack, _menhir_s, _) = _menhir_stack in
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
        | _ ->
            _menhir_fail ())
    | _ ->
        _menhir_fail ()

and _menhir_goto_unop : _menhir_env -> 'ttv_tail -> _menhir_state -> (Ast.unop) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    let _menhir_stack = Obj.magic _menhir_stack in
    assert (not _menhir_env._menhir_error);
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ABRECHAVES ->
        _menhir_run30 _menhir_env (Obj.magic _menhir_stack) MenhirState34
    | ABREPARENTESE ->
        _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState34
    | FALSE ->
        _menhir_run28 _menhir_env (Obj.magic _menhir_stack) MenhirState34
    | FLOAT _v ->
        _menhir_run27 _menhir_env (Obj.magic _menhir_stack) MenhirState34 _v
    | FUNCTION ->
        _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState34
    | ID _v ->
        _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState34 _v
    | INT _v ->
        _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState34 _v
    | NIL ->
        _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState34
    | NOT ->
        _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState34
    | PONTOPONTOPONTO ->
        _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState34
    | QUADRADO ->
        _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState34
    | STRING _v ->
        _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState34 _v
    | SUBTRACAO ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState34
    | TRUE ->
        _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState34
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState34

and _menhir_run12 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ID _v ->
        _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState12 _v
    | PONTOPONTOPONTO ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_s = MenhirState12 in
        let _menhir_env = _menhir_discard _menhir_env in
        let _menhir_stack = Obj.magic _menhir_stack in
        let _1 = () in
        let _v : (Ast.parlist) =                     ( PontoPontoPonto) in
        _menhir_goto_parlist _menhir_env _menhir_stack _menhir_s _v
    | FECHAPARENTESE ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_s = MenhirState12 in
        let _v : (Ast.parlist option) =     ( None ) in
        _menhir_goto_option_parlist_ _menhir_env _menhir_stack _menhir_s _v
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState12

and _menhir_goto_exp : _menhir_env -> 'ttv_tail -> _menhir_state -> (Ast.exp) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    match _menhir_s with
    | MenhirState43 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | AND ->
            _menhir_run62 _menhir_env (Obj.magic _menhir_stack) MenhirState46
        | DIFERENTE ->
            _menhir_run61 _menhir_env (Obj.magic _menhir_stack) MenhirState46
        | DIVISAO ->
            _menhir_run60 _menhir_env (Obj.magic _menhir_stack) MenhirState46
        | EXPONENCIACAO ->
            _menhir_run59 _menhir_env (Obj.magic _menhir_stack) MenhirState46
        | FECHACOLCHETE ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_s = MenhirState46 in
            let _menhir_env = _menhir_discard _menhir_env in
            let _menhir_stack = Obj.magic _menhir_stack in
            let (((_menhir_stack, _menhir_s, (p : (Ast.prefixexp))), _), _, (e : (Ast.exp))) = _menhir_stack in
            let _4 = () in
            let _2 = () in
            let _v : (Ast.var) =                                                  ( Varcol(p,e) ) in
            _menhir_goto_var _menhir_env _menhir_stack _menhir_s _v
        | IGUALDADE ->
            _menhir_run57 _menhir_env (Obj.magic _menhir_stack) MenhirState46
        | MAIOR ->
            _menhir_run56 _menhir_env (Obj.magic _menhir_stack) MenhirState46
        | MAIORIGUAL ->
            _menhir_run55 _menhir_env (Obj.magic _menhir_stack) MenhirState46
        | MENOR ->
            _menhir_run54 _menhir_env (Obj.magic _menhir_stack) MenhirState46
        | MENORIGUAL ->
            _menhir_run53 _menhir_env (Obj.magic _menhir_stack) MenhirState46
        | MODULO ->
            _menhir_run52 _menhir_env (Obj.magic _menhir_stack) MenhirState46
        | MULTIPLICACAO ->
            _menhir_run51 _menhir_env (Obj.magic _menhir_stack) MenhirState46
        | OR ->
            _menhir_run50 _menhir_env (Obj.magic _menhir_stack) MenhirState46
        | PONTOPONTO ->
            _menhir_run49 _menhir_env (Obj.magic _menhir_stack) MenhirState46
        | SOMA ->
            _menhir_run48 _menhir_env (Obj.magic _menhir_stack) MenhirState46
        | SUBTRACAO ->
            _menhir_run47 _menhir_env (Obj.magic _menhir_stack) MenhirState46
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState46)
    | MenhirState63 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | AND ->
            _menhir_run62 _menhir_env (Obj.magic _menhir_stack) MenhirState64
        | DIFERENTE ->
            _menhir_run61 _menhir_env (Obj.magic _menhir_stack) MenhirState64
        | DIVISAO ->
            _menhir_run60 _menhir_env (Obj.magic _menhir_stack) MenhirState64
        | EXPONENCIACAO ->
            _menhir_run59 _menhir_env (Obj.magic _menhir_stack) MenhirState64
        | IGUALDADE ->
            _menhir_run57 _menhir_env (Obj.magic _menhir_stack) MenhirState64
        | MAIOR ->
            _menhir_run56 _menhir_env (Obj.magic _menhir_stack) MenhirState64
        | MAIORIGUAL ->
            _menhir_run55 _menhir_env (Obj.magic _menhir_stack) MenhirState64
        | MENOR ->
            _menhir_run54 _menhir_env (Obj.magic _menhir_stack) MenhirState64
        | MENORIGUAL ->
            _menhir_run53 _menhir_env (Obj.magic _menhir_stack) MenhirState64
        | MODULO ->
            _menhir_run52 _menhir_env (Obj.magic _menhir_stack) MenhirState64
        | MULTIPLICACAO ->
            _menhir_run51 _menhir_env (Obj.magic _menhir_stack) MenhirState64
        | OR ->
            _menhir_run50 _menhir_env (Obj.magic _menhir_stack) MenhirState64
        | PONTOPONTO ->
            _menhir_run49 _menhir_env (Obj.magic _menhir_stack) MenhirState64
        | SOMA ->
            _menhir_run48 _menhir_env (Obj.magic _menhir_stack) MenhirState64
        | SUBTRACAO ->
            _menhir_run47 _menhir_env (Obj.magic _menhir_stack) MenhirState64
        | ABREPARENTESE | BREAK | DO | DOISDOISPONTOS | ELSE | ELSEIF | END | EOF | FECHACHAVES | FECHACOLCHETE | FECHAPARENTESE | FOR | FUNCTION | GOTO | ID _ | IF | LOCAL | PONTOEVIRGULA | PRINT | REPEAT | RETURN | THEN | UNTIL | VIRGULA | WHILE ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let (((_menhir_stack, _menhir_s, (e : (Ast.exp))), _, (b : (Ast.binop))), _, (e2 : (Ast.exp))) = _menhir_stack in
            let _v : (Ast.exp) =                          ( ExpressaoBinaria(e, b, e2) ) in
            _menhir_goto_exp _menhir_env _menhir_stack _menhir_s _v
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState64)
    | MenhirState34 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | AND ->
            _menhir_run62 _menhir_env (Obj.magic _menhir_stack) MenhirState66
        | DIFERENTE ->
            _menhir_run61 _menhir_env (Obj.magic _menhir_stack) MenhirState66
        | DIVISAO ->
            _menhir_run60 _menhir_env (Obj.magic _menhir_stack) MenhirState66
        | EXPONENCIACAO ->
            _menhir_run59 _menhir_env (Obj.magic _menhir_stack) MenhirState66
        | IGUALDADE ->
            _menhir_run57 _menhir_env (Obj.magic _menhir_stack) MenhirState66
        | MAIOR ->
            _menhir_run56 _menhir_env (Obj.magic _menhir_stack) MenhirState66
        | MAIORIGUAL ->
            _menhir_run55 _menhir_env (Obj.magic _menhir_stack) MenhirState66
        | MENOR ->
            _menhir_run54 _menhir_env (Obj.magic _menhir_stack) MenhirState66
        | MENORIGUAL ->
            _menhir_run53 _menhir_env (Obj.magic _menhir_stack) MenhirState66
        | MODULO ->
            _menhir_run52 _menhir_env (Obj.magic _menhir_stack) MenhirState66
        | MULTIPLICACAO ->
            _menhir_run51 _menhir_env (Obj.magic _menhir_stack) MenhirState66
        | OR ->
            _menhir_run50 _menhir_env (Obj.magic _menhir_stack) MenhirState66
        | PONTOPONTO ->
            _menhir_run49 _menhir_env (Obj.magic _menhir_stack) MenhirState66
        | SOMA ->
            _menhir_run48 _menhir_env (Obj.magic _menhir_stack) MenhirState66
        | SUBTRACAO ->
            _menhir_run47 _menhir_env (Obj.magic _menhir_stack) MenhirState66
        | ABREPARENTESE | BREAK | DO | DOISDOISPONTOS | ELSE | ELSEIF | END | EOF | FECHACHAVES | FECHACOLCHETE | FECHAPARENTESE | FOR | FUNCTION | GOTO | ID _ | IF | LOCAL | PONTOEVIRGULA | PRINT | REPEAT | RETURN | THEN | UNTIL | VIRGULA | WHILE ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let ((_menhir_stack, _menhir_s, (u : (Ast.unop))), _, (e : (Ast.exp))) = _menhir_stack in
            let _v : (Ast.exp) =                  ( ExpressaoUnaria(u,e)) in
            _menhir_goto_exp _menhir_env _menhir_stack _menhir_s _v
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState66)
    | MenhirState32 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | AND ->
            _menhir_run62 _menhir_env (Obj.magic _menhir_stack) MenhirState67
        | DIFERENTE ->
            _menhir_run61 _menhir_env (Obj.magic _menhir_stack) MenhirState67
        | DIVISAO ->
            _menhir_run60 _menhir_env (Obj.magic _menhir_stack) MenhirState67
        | EXPONENCIACAO ->
            _menhir_run59 _menhir_env (Obj.magic _menhir_stack) MenhirState67
        | IGUALDADE ->
            _menhir_run57 _menhir_env (Obj.magic _menhir_stack) MenhirState67
        | MAIOR ->
            _menhir_run56 _menhir_env (Obj.magic _menhir_stack) MenhirState67
        | MAIORIGUAL ->
            _menhir_run55 _menhir_env (Obj.magic _menhir_stack) MenhirState67
        | MENOR ->
            _menhir_run54 _menhir_env (Obj.magic _menhir_stack) MenhirState67
        | MENORIGUAL ->
            _menhir_run53 _menhir_env (Obj.magic _menhir_stack) MenhirState67
        | MODULO ->
            _menhir_run52 _menhir_env (Obj.magic _menhir_stack) MenhirState67
        | MULTIPLICACAO ->
            _menhir_run51 _menhir_env (Obj.magic _menhir_stack) MenhirState67
        | OR ->
            _menhir_run50 _menhir_env (Obj.magic _menhir_stack) MenhirState67
        | PONTOPONTO ->
            _menhir_run49 _menhir_env (Obj.magic _menhir_stack) MenhirState67
        | SOMA ->
            _menhir_run48 _menhir_env (Obj.magic _menhir_stack) MenhirState67
        | SUBTRACAO ->
            _menhir_run47 _menhir_env (Obj.magic _menhir_stack) MenhirState67
        | FECHACHAVES | PONTOEVIRGULA | VIRGULA ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let ((_menhir_stack, _menhir_s, (i : (string))), _, (e : (Ast.exp))) = _menhir_stack in
            let _2 = () in
            let _v : (Ast.field) =                           ( Campo2(i,e) ) in
            _menhir_goto_field _menhir_env _menhir_stack _menhir_s _v
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState67)
    | MenhirState68 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | AND ->
            _menhir_run62 _menhir_env (Obj.magic _menhir_stack) MenhirState69
        | DIFERENTE ->
            _menhir_run61 _menhir_env (Obj.magic _menhir_stack) MenhirState69
        | DIVISAO ->
            _menhir_run60 _menhir_env (Obj.magic _menhir_stack) MenhirState69
        | EXPONENCIACAO ->
            _menhir_run59 _menhir_env (Obj.magic _menhir_stack) MenhirState69
        | FECHACOLCHETE ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_s = MenhirState69 in
            let _menhir_stack = (_menhir_stack, _menhir_s) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            (match _tok with
            | ATRIBUICAO ->
                let _menhir_stack = Obj.magic _menhir_stack in
                let _menhir_env = _menhir_discard _menhir_env in
                let _tok = _menhir_env._menhir_token in
                (match _tok with
                | ABRECHAVES ->
                    _menhir_run30 _menhir_env (Obj.magic _menhir_stack) MenhirState71
                | ABREPARENTESE ->
                    _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState71
                | FALSE ->
                    _menhir_run28 _menhir_env (Obj.magic _menhir_stack) MenhirState71
                | FLOAT _v ->
                    _menhir_run27 _menhir_env (Obj.magic _menhir_stack) MenhirState71 _v
                | FUNCTION ->
                    _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState71
                | ID _v ->
                    _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState71 _v
                | INT _v ->
                    _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState71 _v
                | NIL ->
                    _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState71
                | NOT ->
                    _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState71
                | PONTOPONTOPONTO ->
                    _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState71
                | QUADRADO ->
                    _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState71
                | STRING _v ->
                    _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState71 _v
                | SUBTRACAO ->
                    _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState71
                | TRUE ->
                    _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState71
                | _ ->
                    assert (not _menhir_env._menhir_error);
                    _menhir_env._menhir_error <- true;
                    _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState71)
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                let _menhir_stack = Obj.magic _menhir_stack in
                let (_menhir_stack, _menhir_s) = _menhir_stack in
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
        | IGUALDADE ->
            _menhir_run57 _menhir_env (Obj.magic _menhir_stack) MenhirState69
        | MAIOR ->
            _menhir_run56 _menhir_env (Obj.magic _menhir_stack) MenhirState69
        | MAIORIGUAL ->
            _menhir_run55 _menhir_env (Obj.magic _menhir_stack) MenhirState69
        | MENOR ->
            _menhir_run54 _menhir_env (Obj.magic _menhir_stack) MenhirState69
        | MENORIGUAL ->
            _menhir_run53 _menhir_env (Obj.magic _menhir_stack) MenhirState69
        | MODULO ->
            _menhir_run52 _menhir_env (Obj.magic _menhir_stack) MenhirState69
        | MULTIPLICACAO ->
            _menhir_run51 _menhir_env (Obj.magic _menhir_stack) MenhirState69
        | OR ->
            _menhir_run50 _menhir_env (Obj.magic _menhir_stack) MenhirState69
        | PONTOPONTO ->
            _menhir_run49 _menhir_env (Obj.magic _menhir_stack) MenhirState69
        | SOMA ->
            _menhir_run48 _menhir_env (Obj.magic _menhir_stack) MenhirState69
        | SUBTRACAO ->
            _menhir_run47 _menhir_env (Obj.magic _menhir_stack) MenhirState69
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState69)
    | MenhirState71 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | AND ->
            _menhir_run62 _menhir_env (Obj.magic _menhir_stack) MenhirState72
        | DIFERENTE ->
            _menhir_run61 _menhir_env (Obj.magic _menhir_stack) MenhirState72
        | DIVISAO ->
            _menhir_run60 _menhir_env (Obj.magic _menhir_stack) MenhirState72
        | EXPONENCIACAO ->
            _menhir_run59 _menhir_env (Obj.magic _menhir_stack) MenhirState72
        | IGUALDADE ->
            _menhir_run57 _menhir_env (Obj.magic _menhir_stack) MenhirState72
        | MAIOR ->
            _menhir_run56 _menhir_env (Obj.magic _menhir_stack) MenhirState72
        | MAIORIGUAL ->
            _menhir_run55 _menhir_env (Obj.magic _menhir_stack) MenhirState72
        | MENOR ->
            _menhir_run54 _menhir_env (Obj.magic _menhir_stack) MenhirState72
        | MENORIGUAL ->
            _menhir_run53 _menhir_env (Obj.magic _menhir_stack) MenhirState72
        | MODULO ->
            _menhir_run52 _menhir_env (Obj.magic _menhir_stack) MenhirState72
        | MULTIPLICACAO ->
            _menhir_run51 _menhir_env (Obj.magic _menhir_stack) MenhirState72
        | OR ->
            _menhir_run50 _menhir_env (Obj.magic _menhir_stack) MenhirState72
        | PONTOPONTO ->
            _menhir_run49 _menhir_env (Obj.magic _menhir_stack) MenhirState72
        | SOMA ->
            _menhir_run48 _menhir_env (Obj.magic _menhir_stack) MenhirState72
        | SUBTRACAO ->
            _menhir_run47 _menhir_env (Obj.magic _menhir_stack) MenhirState72
        | FECHACHAVES | PONTOEVIRGULA | VIRGULA ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let ((((_menhir_stack, _menhir_s), _, (e1 : (Ast.exp))), _), _, (e2 : (Ast.exp))) = _menhir_stack in
            let _4 = () in
            let _3 = () in
            let _1 = () in
            let _v : (Ast.field) =                                                         ( Campo1(e1,e2)) in
            _menhir_goto_field _menhir_env _menhir_stack _menhir_s _v
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState72)
    | MenhirState30 | MenhirState84 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | AND ->
            _menhir_run62 _menhir_env (Obj.magic _menhir_stack) MenhirState86
        | DIFERENTE ->
            _menhir_run61 _menhir_env (Obj.magic _menhir_stack) MenhirState86
        | DIVISAO ->
            _menhir_run60 _menhir_env (Obj.magic _menhir_stack) MenhirState86
        | EXPONENCIACAO ->
            _menhir_run59 _menhir_env (Obj.magic _menhir_stack) MenhirState86
        | IGUALDADE ->
            _menhir_run57 _menhir_env (Obj.magic _menhir_stack) MenhirState86
        | MAIOR ->
            _menhir_run56 _menhir_env (Obj.magic _menhir_stack) MenhirState86
        | MAIORIGUAL ->
            _menhir_run55 _menhir_env (Obj.magic _menhir_stack) MenhirState86
        | MENOR ->
            _menhir_run54 _menhir_env (Obj.magic _menhir_stack) MenhirState86
        | MENORIGUAL ->
            _menhir_run53 _menhir_env (Obj.magic _menhir_stack) MenhirState86
        | MODULO ->
            _menhir_run52 _menhir_env (Obj.magic _menhir_stack) MenhirState86
        | MULTIPLICACAO ->
            _menhir_run51 _menhir_env (Obj.magic _menhir_stack) MenhirState86
        | OR ->
            _menhir_run50 _menhir_env (Obj.magic _menhir_stack) MenhirState86
        | PONTOPONTO ->
            _menhir_run49 _menhir_env (Obj.magic _menhir_stack) MenhirState86
        | SOMA ->
            _menhir_run48 _menhir_env (Obj.magic _menhir_stack) MenhirState86
        | SUBTRACAO ->
            _menhir_run47 _menhir_env (Obj.magic _menhir_stack) MenhirState86
        | FECHACHAVES | PONTOEVIRGULA | VIRGULA ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, (e : (Ast.exp))) = _menhir_stack in
            let _v : (Ast.field) =           ( Campo3(e) ) in
            _menhir_goto_field _menhir_env _menhir_stack _menhir_s _v
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState86)
    | MenhirState29 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | AND ->
            _menhir_run62 _menhir_env (Obj.magic _menhir_stack) MenhirState87
        | DIFERENTE ->
            _menhir_run61 _menhir_env (Obj.magic _menhir_stack) MenhirState87
        | DIVISAO ->
            _menhir_run60 _menhir_env (Obj.magic _menhir_stack) MenhirState87
        | EXPONENCIACAO ->
            _menhir_run59 _menhir_env (Obj.magic _menhir_stack) MenhirState87
        | FECHAPARENTESE ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_s = MenhirState87 in
            let _menhir_env = _menhir_discard _menhir_env in
            let _menhir_stack = Obj.magic _menhir_stack in
            let ((_menhir_stack, _menhir_s), _, (e : (Ast.exp))) = _menhir_stack in
            let _3 = () in
            let _1 = () in
            let _v : (Ast.prefixexp) =                                        ( ExpressaoParentese(e) ) in
            _menhir_goto_prefixexp _menhir_env _menhir_stack _menhir_s _v
        | IGUALDADE ->
            _menhir_run57 _menhir_env (Obj.magic _menhir_stack) MenhirState87
        | MAIOR ->
            _menhir_run56 _menhir_env (Obj.magic _menhir_stack) MenhirState87
        | MAIORIGUAL ->
            _menhir_run55 _menhir_env (Obj.magic _menhir_stack) MenhirState87
        | MENOR ->
            _menhir_run54 _menhir_env (Obj.magic _menhir_stack) MenhirState87
        | MENORIGUAL ->
            _menhir_run53 _menhir_env (Obj.magic _menhir_stack) MenhirState87
        | MODULO ->
            _menhir_run52 _menhir_env (Obj.magic _menhir_stack) MenhirState87
        | MULTIPLICACAO ->
            _menhir_run51 _menhir_env (Obj.magic _menhir_stack) MenhirState87
        | OR ->
            _menhir_run50 _menhir_env (Obj.magic _menhir_stack) MenhirState87
        | PONTOPONTO ->
            _menhir_run49 _menhir_env (Obj.magic _menhir_stack) MenhirState87
        | SOMA ->
            _menhir_run48 _menhir_env (Obj.magic _menhir_stack) MenhirState87
        | SUBTRACAO ->
            _menhir_run47 _menhir_env (Obj.magic _menhir_stack) MenhirState87
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState87)
    | MenhirState166 | MenhirState154 | MenhirState140 | MenhirState102 | MenhirState26 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | AND ->
            _menhir_run62 _menhir_env (Obj.magic _menhir_stack) MenhirState92
        | DIFERENTE ->
            _menhir_run61 _menhir_env (Obj.magic _menhir_stack) MenhirState92
        | DIVISAO ->
            _menhir_run60 _menhir_env (Obj.magic _menhir_stack) MenhirState92
        | EXPONENCIACAO ->
            _menhir_run59 _menhir_env (Obj.magic _menhir_stack) MenhirState92
        | IGUALDADE ->
            _menhir_run57 _menhir_env (Obj.magic _menhir_stack) MenhirState92
        | MAIOR ->
            _menhir_run56 _menhir_env (Obj.magic _menhir_stack) MenhirState92
        | MAIORIGUAL ->
            _menhir_run55 _menhir_env (Obj.magic _menhir_stack) MenhirState92
        | MENOR ->
            _menhir_run54 _menhir_env (Obj.magic _menhir_stack) MenhirState92
        | MENORIGUAL ->
            _menhir_run53 _menhir_env (Obj.magic _menhir_stack) MenhirState92
        | MODULO ->
            _menhir_run52 _menhir_env (Obj.magic _menhir_stack) MenhirState92
        | MULTIPLICACAO ->
            _menhir_run51 _menhir_env (Obj.magic _menhir_stack) MenhirState92
        | OR ->
            _menhir_run50 _menhir_env (Obj.magic _menhir_stack) MenhirState92
        | PONTOPONTO ->
            _menhir_run49 _menhir_env (Obj.magic _menhir_stack) MenhirState92
        | SOMA ->
            _menhir_run48 _menhir_env (Obj.magic _menhir_stack) MenhirState92
        | SUBTRACAO ->
            _menhir_run47 _menhir_env (Obj.magic _menhir_stack) MenhirState92
        | VIRGULA ->
            _menhir_run93 _menhir_env (Obj.magic _menhir_stack) MenhirState92
        | ABREPARENTESE | BREAK | DO | DOISDOISPONTOS | ELSE | ELSEIF | END | EOF | FECHAPARENTESE | FOR | FUNCTION | GOTO | ID _ | IF | LOCAL | PONTOEVIRGULA | PRINT | REPEAT | RETURN | UNTIL | WHILE ->
            _menhir_reduce59 _menhir_env (Obj.magic _menhir_stack) MenhirState92
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState92)
    | MenhirState93 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | AND ->
            _menhir_run62 _menhir_env (Obj.magic _menhir_stack) MenhirState94
        | DIFERENTE ->
            _menhir_run61 _menhir_env (Obj.magic _menhir_stack) MenhirState94
        | DIVISAO ->
            _menhir_run60 _menhir_env (Obj.magic _menhir_stack) MenhirState94
        | EXPONENCIACAO ->
            _menhir_run59 _menhir_env (Obj.magic _menhir_stack) MenhirState94
        | IGUALDADE ->
            _menhir_run57 _menhir_env (Obj.magic _menhir_stack) MenhirState94
        | MAIOR ->
            _menhir_run56 _menhir_env (Obj.magic _menhir_stack) MenhirState94
        | MAIORIGUAL ->
            _menhir_run55 _menhir_env (Obj.magic _menhir_stack) MenhirState94
        | MENOR ->
            _menhir_run54 _menhir_env (Obj.magic _menhir_stack) MenhirState94
        | MENORIGUAL ->
            _menhir_run53 _menhir_env (Obj.magic _menhir_stack) MenhirState94
        | MODULO ->
            _menhir_run52 _menhir_env (Obj.magic _menhir_stack) MenhirState94
        | MULTIPLICACAO ->
            _menhir_run51 _menhir_env (Obj.magic _menhir_stack) MenhirState94
        | OR ->
            _menhir_run50 _menhir_env (Obj.magic _menhir_stack) MenhirState94
        | PONTOPONTO ->
            _menhir_run49 _menhir_env (Obj.magic _menhir_stack) MenhirState94
        | SOMA ->
            _menhir_run48 _menhir_env (Obj.magic _menhir_stack) MenhirState94
        | SUBTRACAO ->
            _menhir_run47 _menhir_env (Obj.magic _menhir_stack) MenhirState94
        | ABREPARENTESE | BREAK | DO | DOISDOISPONTOS | ELSE | ELSEIF | END | EOF | FECHAPARENTESE | FOR | FUNCTION | GOTO | ID _ | IF | LOCAL | PONTOEVIRGULA | PRINT | REPEAT | RETURN | UNTIL | VIRGULA | WHILE ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let ((_menhir_stack, _menhir_s), _, (e : (Ast.exp))) = _menhir_stack in
            let _1 = () in
            let _v : (Ast.virgula_exp_rule) =                   ( VirgulaExp(e) ) in
            let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
            let _menhir_stack = Obj.magic _menhir_stack in
            assert (not _menhir_env._menhir_error);
            let _tok = _menhir_env._menhir_token in
            (match _tok with
            | VIRGULA ->
                _menhir_run93 _menhir_env (Obj.magic _menhir_stack) MenhirState95
            | ABREPARENTESE | BREAK | DO | DOISDOISPONTOS | ELSE | ELSEIF | END | EOF | FECHAPARENTESE | FOR | FUNCTION | GOTO | ID _ | IF | LOCAL | PONTOEVIRGULA | PRINT | REPEAT | RETURN | UNTIL | WHILE ->
                _menhir_reduce59 _menhir_env (Obj.magic _menhir_stack) MenhirState95
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState95)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState94)
    | MenhirState106 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | AND ->
            _menhir_run62 _menhir_env (Obj.magic _menhir_stack) MenhirState107
        | DIFERENTE ->
            _menhir_run61 _menhir_env (Obj.magic _menhir_stack) MenhirState107
        | DIVISAO ->
            _menhir_run60 _menhir_env (Obj.magic _menhir_stack) MenhirState107
        | EXPONENCIACAO ->
            _menhir_run59 _menhir_env (Obj.magic _menhir_stack) MenhirState107
        | IGUALDADE ->
            _menhir_run57 _menhir_env (Obj.magic _menhir_stack) MenhirState107
        | MAIOR ->
            _menhir_run56 _menhir_env (Obj.magic _menhir_stack) MenhirState107
        | MAIORIGUAL ->
            _menhir_run55 _menhir_env (Obj.magic _menhir_stack) MenhirState107
        | MENOR ->
            _menhir_run54 _menhir_env (Obj.magic _menhir_stack) MenhirState107
        | MENORIGUAL ->
            _menhir_run53 _menhir_env (Obj.magic _menhir_stack) MenhirState107
        | MODULO ->
            _menhir_run52 _menhir_env (Obj.magic _menhir_stack) MenhirState107
        | MULTIPLICACAO ->
            _menhir_run51 _menhir_env (Obj.magic _menhir_stack) MenhirState107
        | OR ->
            _menhir_run50 _menhir_env (Obj.magic _menhir_stack) MenhirState107
        | PONTOPONTO ->
            _menhir_run49 _menhir_env (Obj.magic _menhir_stack) MenhirState107
        | SOMA ->
            _menhir_run48 _menhir_env (Obj.magic _menhir_stack) MenhirState107
        | SUBTRACAO ->
            _menhir_run47 _menhir_env (Obj.magic _menhir_stack) MenhirState107
        | THEN ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_s = MenhirState107 in
            let _menhir_stack = (_menhir_stack, _menhir_s) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            (match _tok with
            | ABREPARENTESE ->
                _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState108
            | BREAK ->
                _menhir_run138 _menhir_env (Obj.magic _menhir_stack) MenhirState108
            | DO ->
                _menhir_run137 _menhir_env (Obj.magic _menhir_stack) MenhirState108
            | DOISDOISPONTOS ->
                _menhir_run134 _menhir_env (Obj.magic _menhir_stack) MenhirState108
            | FOR ->
                _menhir_run124 _menhir_env (Obj.magic _menhir_stack) MenhirState108
            | FUNCTION ->
                _menhir_run111 _menhir_env (Obj.magic _menhir_stack) MenhirState108
            | GOTO ->
                _menhir_run109 _menhir_env (Obj.magic _menhir_stack) MenhirState108
            | ID _v ->
                _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState108 _v
            | IF ->
                _menhir_run106 _menhir_env (Obj.magic _menhir_stack) MenhirState108
            | LOCAL ->
                _menhir_run100 _menhir_env (Obj.magic _menhir_stack) MenhirState108
            | PONTOEVIRGULA ->
                _menhir_run99 _menhir_env (Obj.magic _menhir_stack) MenhirState108
            | PRINT ->
                _menhir_run24 _menhir_env (Obj.magic _menhir_stack) MenhirState108
            | REPEAT ->
                _menhir_run23 _menhir_env (Obj.magic _menhir_stack) MenhirState108
            | WHILE ->
                _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState108
            | ELSE | ELSEIF | END | RETURN ->
                _menhir_reduce57 _menhir_env (Obj.magic _menhir_stack) MenhirState108
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState108)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState107)
    | MenhirState126 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | AND ->
            _menhir_run62 _menhir_env (Obj.magic _menhir_stack) MenhirState127
        | DIFERENTE ->
            _menhir_run61 _menhir_env (Obj.magic _menhir_stack) MenhirState127
        | DIVISAO ->
            _menhir_run60 _menhir_env (Obj.magic _menhir_stack) MenhirState127
        | EXPONENCIACAO ->
            _menhir_run59 _menhir_env (Obj.magic _menhir_stack) MenhirState127
        | IGUALDADE ->
            _menhir_run57 _menhir_env (Obj.magic _menhir_stack) MenhirState127
        | MAIOR ->
            _menhir_run56 _menhir_env (Obj.magic _menhir_stack) MenhirState127
        | MAIORIGUAL ->
            _menhir_run55 _menhir_env (Obj.magic _menhir_stack) MenhirState127
        | MENOR ->
            _menhir_run54 _menhir_env (Obj.magic _menhir_stack) MenhirState127
        | MENORIGUAL ->
            _menhir_run53 _menhir_env (Obj.magic _menhir_stack) MenhirState127
        | MODULO ->
            _menhir_run52 _menhir_env (Obj.magic _menhir_stack) MenhirState127
        | MULTIPLICACAO ->
            _menhir_run51 _menhir_env (Obj.magic _menhir_stack) MenhirState127
        | OR ->
            _menhir_run50 _menhir_env (Obj.magic _menhir_stack) MenhirState127
        | PONTOPONTO ->
            _menhir_run49 _menhir_env (Obj.magic _menhir_stack) MenhirState127
        | SOMA ->
            _menhir_run48 _menhir_env (Obj.magic _menhir_stack) MenhirState127
        | SUBTRACAO ->
            _menhir_run47 _menhir_env (Obj.magic _menhir_stack) MenhirState127
        | VIRGULA ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_s = MenhirState127 in
            let _menhir_stack = (_menhir_stack, _menhir_s) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            (match _tok with
            | ABRECHAVES ->
                _menhir_run30 _menhir_env (Obj.magic _menhir_stack) MenhirState128
            | ABREPARENTESE ->
                _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState128
            | FALSE ->
                _menhir_run28 _menhir_env (Obj.magic _menhir_stack) MenhirState128
            | FLOAT _v ->
                _menhir_run27 _menhir_env (Obj.magic _menhir_stack) MenhirState128 _v
            | FUNCTION ->
                _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState128
            | ID _v ->
                _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState128 _v
            | INT _v ->
                _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState128 _v
            | NIL ->
                _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState128
            | NOT ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState128
            | PONTOPONTOPONTO ->
                _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState128
            | QUADRADO ->
                _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState128
            | STRING _v ->
                _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState128 _v
            | SUBTRACAO ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState128
            | TRUE ->
                _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState128
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState128)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState127)
    | MenhirState128 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | AND ->
            _menhir_run62 _menhir_env (Obj.magic _menhir_stack) MenhirState129
        | DIFERENTE ->
            _menhir_run61 _menhir_env (Obj.magic _menhir_stack) MenhirState129
        | DIVISAO ->
            _menhir_run60 _menhir_env (Obj.magic _menhir_stack) MenhirState129
        | EXPONENCIACAO ->
            _menhir_run59 _menhir_env (Obj.magic _menhir_stack) MenhirState129
        | IGUALDADE ->
            _menhir_run57 _menhir_env (Obj.magic _menhir_stack) MenhirState129
        | MAIOR ->
            _menhir_run56 _menhir_env (Obj.magic _menhir_stack) MenhirState129
        | MAIORIGUAL ->
            _menhir_run55 _menhir_env (Obj.magic _menhir_stack) MenhirState129
        | MENOR ->
            _menhir_run54 _menhir_env (Obj.magic _menhir_stack) MenhirState129
        | MENORIGUAL ->
            _menhir_run53 _menhir_env (Obj.magic _menhir_stack) MenhirState129
        | MODULO ->
            _menhir_run52 _menhir_env (Obj.magic _menhir_stack) MenhirState129
        | MULTIPLICACAO ->
            _menhir_run51 _menhir_env (Obj.magic _menhir_stack) MenhirState129
        | OR ->
            _menhir_run50 _menhir_env (Obj.magic _menhir_stack) MenhirState129
        | PONTOPONTO ->
            _menhir_run49 _menhir_env (Obj.magic _menhir_stack) MenhirState129
        | SOMA ->
            _menhir_run48 _menhir_env (Obj.magic _menhir_stack) MenhirState129
        | SUBTRACAO ->
            _menhir_run47 _menhir_env (Obj.magic _menhir_stack) MenhirState129
        | VIRGULA ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_s = MenhirState129 in
            let _menhir_stack = (_menhir_stack, _menhir_s) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            (match _tok with
            | ABRECHAVES ->
                _menhir_run30 _menhir_env (Obj.magic _menhir_stack) MenhirState130
            | ABREPARENTESE ->
                _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState130
            | FALSE ->
                _menhir_run28 _menhir_env (Obj.magic _menhir_stack) MenhirState130
            | FLOAT _v ->
                _menhir_run27 _menhir_env (Obj.magic _menhir_stack) MenhirState130 _v
            | FUNCTION ->
                _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState130
            | ID _v ->
                _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState130 _v
            | INT _v ->
                _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState130 _v
            | NIL ->
                _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState130
            | NOT ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState130
            | PONTOPONTOPONTO ->
                _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState130
            | QUADRADO ->
                _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState130
            | STRING _v ->
                _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState130 _v
            | SUBTRACAO ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState130
            | TRUE ->
                _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState130
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState130)
        | DO ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_s = MenhirState129 in
            let _v : (Ast.comma_exp_rule option) =     ( None ) in
            _menhir_goto_option_comma_exp_rule_ _menhir_env _menhir_stack _menhir_s _v
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState129)
    | MenhirState130 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | AND ->
            _menhir_run62 _menhir_env (Obj.magic _menhir_stack) MenhirState131
        | DIFERENTE ->
            _menhir_run61 _menhir_env (Obj.magic _menhir_stack) MenhirState131
        | DIVISAO ->
            _menhir_run60 _menhir_env (Obj.magic _menhir_stack) MenhirState131
        | EXPONENCIACAO ->
            _menhir_run59 _menhir_env (Obj.magic _menhir_stack) MenhirState131
        | IGUALDADE ->
            _menhir_run57 _menhir_env (Obj.magic _menhir_stack) MenhirState131
        | MAIOR ->
            _menhir_run56 _menhir_env (Obj.magic _menhir_stack) MenhirState131
        | MAIORIGUAL ->
            _menhir_run55 _menhir_env (Obj.magic _menhir_stack) MenhirState131
        | MENOR ->
            _menhir_run54 _menhir_env (Obj.magic _menhir_stack) MenhirState131
        | MENORIGUAL ->
            _menhir_run53 _menhir_env (Obj.magic _menhir_stack) MenhirState131
        | MODULO ->
            _menhir_run52 _menhir_env (Obj.magic _menhir_stack) MenhirState131
        | MULTIPLICACAO ->
            _menhir_run51 _menhir_env (Obj.magic _menhir_stack) MenhirState131
        | OR ->
            _menhir_run50 _menhir_env (Obj.magic _menhir_stack) MenhirState131
        | PONTOPONTO ->
            _menhir_run49 _menhir_env (Obj.magic _menhir_stack) MenhirState131
        | SOMA ->
            _menhir_run48 _menhir_env (Obj.magic _menhir_stack) MenhirState131
        | SUBTRACAO ->
            _menhir_run47 _menhir_env (Obj.magic _menhir_stack) MenhirState131
        | DO ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let ((_menhir_stack, _menhir_s), _, (e : (Ast.exp))) = _menhir_stack in
            let _1 = () in
            let _v : (Ast.comma_exp_rule) =                   ( Virgula(e) ) in
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_stack = Obj.magic _menhir_stack in
            let (x : (Ast.comma_exp_rule)) = _v in
            let _v : (Ast.comma_exp_rule option) =     ( Some x ) in
            _menhir_goto_option_comma_exp_rule_ _menhir_env _menhir_stack _menhir_s _v
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState131)
    | MenhirState172 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | AND ->
            _menhir_run62 _menhir_env (Obj.magic _menhir_stack) MenhirState173
        | DIFERENTE ->
            _menhir_run61 _menhir_env (Obj.magic _menhir_stack) MenhirState173
        | DIVISAO ->
            _menhir_run60 _menhir_env (Obj.magic _menhir_stack) MenhirState173
        | EXPONENCIACAO ->
            _menhir_run59 _menhir_env (Obj.magic _menhir_stack) MenhirState173
        | IGUALDADE ->
            _menhir_run57 _menhir_env (Obj.magic _menhir_stack) MenhirState173
        | MAIOR ->
            _menhir_run56 _menhir_env (Obj.magic _menhir_stack) MenhirState173
        | MAIORIGUAL ->
            _menhir_run55 _menhir_env (Obj.magic _menhir_stack) MenhirState173
        | MENOR ->
            _menhir_run54 _menhir_env (Obj.magic _menhir_stack) MenhirState173
        | MENORIGUAL ->
            _menhir_run53 _menhir_env (Obj.magic _menhir_stack) MenhirState173
        | MODULO ->
            _menhir_run52 _menhir_env (Obj.magic _menhir_stack) MenhirState173
        | MULTIPLICACAO ->
            _menhir_run51 _menhir_env (Obj.magic _menhir_stack) MenhirState173
        | OR ->
            _menhir_run50 _menhir_env (Obj.magic _menhir_stack) MenhirState173
        | PONTOPONTO ->
            _menhir_run49 _menhir_env (Obj.magic _menhir_stack) MenhirState173
        | SOMA ->
            _menhir_run48 _menhir_env (Obj.magic _menhir_stack) MenhirState173
        | SUBTRACAO ->
            _menhir_run47 _menhir_env (Obj.magic _menhir_stack) MenhirState173
        | THEN ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_s = MenhirState173 in
            let _menhir_stack = (_menhir_stack, _menhir_s) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            (match _tok with
            | ABREPARENTESE ->
                _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState174
            | BREAK ->
                _menhir_run138 _menhir_env (Obj.magic _menhir_stack) MenhirState174
            | DO ->
                _menhir_run137 _menhir_env (Obj.magic _menhir_stack) MenhirState174
            | DOISDOISPONTOS ->
                _menhir_run134 _menhir_env (Obj.magic _menhir_stack) MenhirState174
            | FOR ->
                _menhir_run124 _menhir_env (Obj.magic _menhir_stack) MenhirState174
            | FUNCTION ->
                _menhir_run111 _menhir_env (Obj.magic _menhir_stack) MenhirState174
            | GOTO ->
                _menhir_run109 _menhir_env (Obj.magic _menhir_stack) MenhirState174
            | ID _v ->
                _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState174 _v
            | IF ->
                _menhir_run106 _menhir_env (Obj.magic _menhir_stack) MenhirState174
            | LOCAL ->
                _menhir_run100 _menhir_env (Obj.magic _menhir_stack) MenhirState174
            | PONTOEVIRGULA ->
                _menhir_run99 _menhir_env (Obj.magic _menhir_stack) MenhirState174
            | PRINT ->
                _menhir_run24 _menhir_env (Obj.magic _menhir_stack) MenhirState174
            | REPEAT ->
                _menhir_run23 _menhir_env (Obj.magic _menhir_stack) MenhirState174
            | WHILE ->
                _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState174
            | ELSE | ELSEIF | END | RETURN ->
                _menhir_reduce57 _menhir_env (Obj.magic _menhir_stack) MenhirState174
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState174)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState173)
    | MenhirState185 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | AND ->
            _menhir_run62 _menhir_env (Obj.magic _menhir_stack) MenhirState186
        | DIFERENTE ->
            _menhir_run61 _menhir_env (Obj.magic _menhir_stack) MenhirState186
        | DIVISAO ->
            _menhir_run60 _menhir_env (Obj.magic _menhir_stack) MenhirState186
        | EXPONENCIACAO ->
            _menhir_run59 _menhir_env (Obj.magic _menhir_stack) MenhirState186
        | IGUALDADE ->
            _menhir_run57 _menhir_env (Obj.magic _menhir_stack) MenhirState186
        | MAIOR ->
            _menhir_run56 _menhir_env (Obj.magic _menhir_stack) MenhirState186
        | MAIORIGUAL ->
            _menhir_run55 _menhir_env (Obj.magic _menhir_stack) MenhirState186
        | MENOR ->
            _menhir_run54 _menhir_env (Obj.magic _menhir_stack) MenhirState186
        | MENORIGUAL ->
            _menhir_run53 _menhir_env (Obj.magic _menhir_stack) MenhirState186
        | MODULO ->
            _menhir_run52 _menhir_env (Obj.magic _menhir_stack) MenhirState186
        | MULTIPLICACAO ->
            _menhir_run51 _menhir_env (Obj.magic _menhir_stack) MenhirState186
        | OR ->
            _menhir_run50 _menhir_env (Obj.magic _menhir_stack) MenhirState186
        | PONTOPONTO ->
            _menhir_run49 _menhir_env (Obj.magic _menhir_stack) MenhirState186
        | SOMA ->
            _menhir_run48 _menhir_env (Obj.magic _menhir_stack) MenhirState186
        | SUBTRACAO ->
            _menhir_run47 _menhir_env (Obj.magic _menhir_stack) MenhirState186
        | ABREPARENTESE | BREAK | DO | DOISDOISPONTOS | ELSE | ELSEIF | END | EOF | FOR | FUNCTION | GOTO | ID _ | IF | LOCAL | PONTOEVIRGULA | PRINT | REPEAT | RETURN | UNTIL | WHILE ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let (((_menhir_stack, _menhir_s), _, (b : (Ast.block))), _, (e : (Ast.exp))) = _menhir_stack in
            let _3 = () in
            let _1 = () in
            let _v : (Ast.stat) =                                ( Repeat(b,e)) in
            _menhir_goto_stat _menhir_env _menhir_stack _menhir_s _v
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState186)
    | MenhirState1 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | AND ->
            _menhir_run62 _menhir_env (Obj.magic _menhir_stack) MenhirState195
        | DIFERENTE ->
            _menhir_run61 _menhir_env (Obj.magic _menhir_stack) MenhirState195
        | DIVISAO ->
            _menhir_run60 _menhir_env (Obj.magic _menhir_stack) MenhirState195
        | DO ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_s = MenhirState195 in
            let _menhir_stack = (_menhir_stack, _menhir_s) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            (match _tok with
            | ABREPARENTESE ->
                _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState196
            | BREAK ->
                _menhir_run138 _menhir_env (Obj.magic _menhir_stack) MenhirState196
            | DO ->
                _menhir_run137 _menhir_env (Obj.magic _menhir_stack) MenhirState196
            | DOISDOISPONTOS ->
                _menhir_run134 _menhir_env (Obj.magic _menhir_stack) MenhirState196
            | FOR ->
                _menhir_run124 _menhir_env (Obj.magic _menhir_stack) MenhirState196
            | FUNCTION ->
                _menhir_run111 _menhir_env (Obj.magic _menhir_stack) MenhirState196
            | GOTO ->
                _menhir_run109 _menhir_env (Obj.magic _menhir_stack) MenhirState196
            | ID _v ->
                _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState196 _v
            | IF ->
                _menhir_run106 _menhir_env (Obj.magic _menhir_stack) MenhirState196
            | LOCAL ->
                _menhir_run100 _menhir_env (Obj.magic _menhir_stack) MenhirState196
            | PONTOEVIRGULA ->
                _menhir_run99 _menhir_env (Obj.magic _menhir_stack) MenhirState196
            | PRINT ->
                _menhir_run24 _menhir_env (Obj.magic _menhir_stack) MenhirState196
            | REPEAT ->
                _menhir_run23 _menhir_env (Obj.magic _menhir_stack) MenhirState196
            | WHILE ->
                _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState196
            | END | RETURN ->
                _menhir_reduce57 _menhir_env (Obj.magic _menhir_stack) MenhirState196
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState196)
        | EXPONENCIACAO ->
            _menhir_run59 _menhir_env (Obj.magic _menhir_stack) MenhirState195
        | IGUALDADE ->
            _menhir_run57 _menhir_env (Obj.magic _menhir_stack) MenhirState195
        | MAIOR ->
            _menhir_run56 _menhir_env (Obj.magic _menhir_stack) MenhirState195
        | MAIORIGUAL ->
            _menhir_run55 _menhir_env (Obj.magic _menhir_stack) MenhirState195
        | MENOR ->
            _menhir_run54 _menhir_env (Obj.magic _menhir_stack) MenhirState195
        | MENORIGUAL ->
            _menhir_run53 _menhir_env (Obj.magic _menhir_stack) MenhirState195
        | MODULO ->
            _menhir_run52 _menhir_env (Obj.magic _menhir_stack) MenhirState195
        | MULTIPLICACAO ->
            _menhir_run51 _menhir_env (Obj.magic _menhir_stack) MenhirState195
        | OR ->
            _menhir_run50 _menhir_env (Obj.magic _menhir_stack) MenhirState195
        | PONTOPONTO ->
            _menhir_run49 _menhir_env (Obj.magic _menhir_stack) MenhirState195
        | SOMA ->
            _menhir_run48 _menhir_env (Obj.magic _menhir_stack) MenhirState195
        | SUBTRACAO ->
            _menhir_run47 _menhir_env (Obj.magic _menhir_stack) MenhirState195
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState195)
    | _ ->
        _menhir_fail ()

and _menhir_goto_option_fieldlist_ : _menhir_env -> 'ttv_tail -> _menhir_state -> (Ast.fieldlist option) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    let _menhir_stack = Obj.magic _menhir_stack in
    assert (not _menhir_env._menhir_error);
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | FECHACHAVES ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_env = _menhir_discard _menhir_env in
        let _menhir_stack = Obj.magic _menhir_stack in
        let ((_menhir_stack, _menhir_s), _, (f : (Ast.fieldlist option))) = _menhir_stack in
        let _3 = () in
        let _1 = () in
        let _v : (Ast.tableconstructor) =                                         ( FieldList(f) ) in
        (match _menhir_s with
        | MenhirState1 | MenhirState185 | MenhirState172 | MenhirState166 | MenhirState154 | MenhirState140 | MenhirState130 | MenhirState128 | MenhirState126 | MenhirState106 | MenhirState102 | MenhirState93 | MenhirState26 | MenhirState29 | MenhirState84 | MenhirState30 | MenhirState71 | MenhirState68 | MenhirState32 | MenhirState63 | MenhirState43 | MenhirState34 ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_stack = Obj.magic _menhir_stack in
            let (t : (Ast.tableconstructor)) = _v in
            let _v : (Ast.exp) =                        ( TableConstructor(t) ) in
            _menhir_goto_exp _menhir_env _menhir_stack _menhir_s _v
        | MenhirState145 | MenhirState24 | MenhirState36 | MenhirState40 ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_stack = Obj.magic _menhir_stack in
            let (t : (Ast.tableconstructor)) = _v in
            let _v : (Ast.args) =                        ( TableConstructor(t) ) in
            _menhir_goto_args _menhir_env _menhir_stack _menhir_s _v
        | _ ->
            _menhir_fail ())
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s

and _menhir_run31 : _menhir_env -> 'ttv_tail -> _menhir_state -> (string) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ATRIBUICAO ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | ABRECHAVES ->
            _menhir_run30 _menhir_env (Obj.magic _menhir_stack) MenhirState32
        | ABREPARENTESE ->
            _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState32
        | FALSE ->
            _menhir_run28 _menhir_env (Obj.magic _menhir_stack) MenhirState32
        | FLOAT _v ->
            _menhir_run27 _menhir_env (Obj.magic _menhir_stack) MenhirState32 _v
        | FUNCTION ->
            _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState32
        | ID _v ->
            _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState32 _v
        | INT _v ->
            _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState32 _v
        | NIL ->
            _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState32
        | NOT ->
            _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState32
        | PONTOPONTOPONTO ->
            _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState32
        | QUADRADO ->
            _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState32
        | STRING _v ->
            _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState32 _v
        | SUBTRACAO ->
            _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState32
        | TRUE ->
            _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState32
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState32)
    | ABRECHAVES | ABRECOLCHETE | ABREPARENTESE | AND | DIFERENTE | DIVISAO | DOISPONTOS | EXPONENCIACAO | FECHACHAVES | IGUALDADE | MAIOR | MAIORIGUAL | MENOR | MENORIGUAL | MODULO | MULTIPLICACAO | OR | PONTO | PONTOEVIRGULA | PONTOPONTO | SOMA | STRING _ | SUBTRACAO | VIRGULA ->
        _menhir_reduce115 _menhir_env (Obj.magic _menhir_stack)
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s

and _menhir_run68 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ABRECHAVES ->
        _menhir_run30 _menhir_env (Obj.magic _menhir_stack) MenhirState68
    | ABREPARENTESE ->
        _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState68
    | FALSE ->
        _menhir_run28 _menhir_env (Obj.magic _menhir_stack) MenhirState68
    | FLOAT _v ->
        _menhir_run27 _menhir_env (Obj.magic _menhir_stack) MenhirState68 _v
    | FUNCTION ->
        _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState68
    | ID _v ->
        _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState68 _v
    | INT _v ->
        _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState68 _v
    | NIL ->
        _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState68
    | NOT ->
        _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState68
    | PONTOPONTOPONTO ->
        _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState68
    | QUADRADO ->
        _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState68
    | STRING _v ->
        _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState68 _v
    | SUBTRACAO ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState68
    | TRUE ->
        _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState68
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState68

and _menhir_goto_list_stat_ : _menhir_env -> 'ttv_tail -> _menhir_state -> (Ast.stat list) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    match _menhir_s with
    | MenhirState149 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_stack = Obj.magic _menhir_stack in
        let ((_menhir_stack, _menhir_s, (x : (Ast.stat))), _, (xs : (Ast.stat list))) = _menhir_stack in
        let _v : (Ast.stat list) =     ( x :: xs ) in
        _menhir_goto_list_stat_ _menhir_env _menhir_stack _menhir_s _v
    | MenhirState0 | MenhirState196 | MenhirState22 | MenhirState23 | MenhirState177 | MenhirState174 | MenhirState108 | MenhirState168 | MenhirState133 | MenhirState137 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | RETURN ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            (match _tok with
            | ABRECHAVES ->
                _menhir_run30 _menhir_env (Obj.magic _menhir_stack) MenhirState154
            | ABREPARENTESE ->
                _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState154
            | FALSE ->
                _menhir_run28 _menhir_env (Obj.magic _menhir_stack) MenhirState154
            | FLOAT _v ->
                _menhir_run27 _menhir_env (Obj.magic _menhir_stack) MenhirState154 _v
            | FUNCTION ->
                _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState154
            | ID _v ->
                _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState154 _v
            | INT _v ->
                _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState154 _v
            | NIL ->
                _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState154
            | NOT ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState154
            | PONTOPONTOPONTO ->
                _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState154
            | QUADRADO ->
                _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState154
            | STRING _v ->
                _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState154 _v
            | SUBTRACAO ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState154
            | TRUE ->
                _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState154
            | ELSE | ELSEIF | END | EOF | PONTOEVIRGULA | UNTIL ->
                _menhir_reduce76 _menhir_env (Obj.magic _menhir_stack) MenhirState154
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState154)
        | ELSE | ELSEIF | END | EOF | UNTIL ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _v : (Ast.retstat option) =     ( None ) in
            _menhir_goto_option_retstat_ _menhir_env _menhir_stack _v
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | _ ->
        _menhir_fail ()

and _menhir_run25 : _menhir_env -> 'ttv_tail -> _menhir_state -> (string) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _menhir_stack = Obj.magic _menhir_stack in
    let (s : (string)) = _v in
    let _v : (Ast.args) =              ( String(s) ) in
    _menhir_goto_args _menhir_env _menhir_stack _menhir_s _v

and _menhir_run26 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ABRECHAVES ->
        _menhir_run30 _menhir_env (Obj.magic _menhir_stack) MenhirState26
    | ABREPARENTESE ->
        _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState26
    | FALSE ->
        _menhir_run28 _menhir_env (Obj.magic _menhir_stack) MenhirState26
    | FLOAT _v ->
        _menhir_run27 _menhir_env (Obj.magic _menhir_stack) MenhirState26 _v
    | FUNCTION ->
        _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState26
    | ID _v ->
        _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState26 _v
    | INT _v ->
        _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState26 _v
    | NIL ->
        _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState26
    | NOT ->
        _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState26
    | PONTOPONTOPONTO ->
        _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState26
    | QUADRADO ->
        _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState26
    | STRING _v ->
        _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState26 _v
    | SUBTRACAO ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState26
    | TRUE ->
        _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState26
    | FECHAPARENTESE ->
        _menhir_reduce76 _menhir_env (Obj.magic _menhir_stack) MenhirState26
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState26

and _menhir_run14 : _menhir_env -> 'ttv_tail -> _menhir_state -> (string) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | VIRGULA ->
        _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState14
    | ABREPARENTESE | ATRIBUICAO | BREAK | DO | DOISDOISPONTOS | ELSE | ELSEIF | END | EOF | FECHAPARENTESE | FOR | FUNCTION | GOTO | ID _ | IF | LOCAL | PONTOEVIRGULA | PRINT | REPEAT | RETURN | UNTIL | WHILE ->
        _menhir_reduce61 _menhir_env (Obj.magic _menhir_stack) MenhirState14
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState14

and _menhir_reduce115 : _menhir_env -> 'ttv_tail * _menhir_state * (string) -> 'ttv_return =
  fun _menhir_env _menhir_stack ->
    let (_menhir_stack, _menhir_s, (i : (string))) = _menhir_stack in
    let _v : (Ast.var) =          ( Id(i) ) in
    _menhir_goto_var _menhir_env _menhir_stack _menhir_s _v

and _menhir_reduce55 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _v : (Ast.ponto_id_rule list) =     ( [] ) in
    _menhir_goto_list_ponto_id_rule_ _menhir_env _menhir_stack _menhir_s _v

and _menhir_run113 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ID _v ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_env = _menhir_discard _menhir_env in
        let _menhir_stack = Obj.magic _menhir_stack in
        let (i : (string)) = _v in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        let _1 = () in
        let _v : (Ast.ponto_id_rule) =                ( Ponto(i) ) in
        let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | PONTO ->
            _menhir_run113 _menhir_env (Obj.magic _menhir_stack) MenhirState115
        | ABREPARENTESE | DOISPONTOS ->
            _menhir_reduce55 _menhir_env (Obj.magic _menhir_stack) MenhirState115
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState115)
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s

and _menhir_reduce61 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _v : (Ast.virgula_id_rule list) =     ( [] ) in
    _menhir_goto_list_virgula_id_rule_ _menhir_env _menhir_stack _menhir_s _v

and _menhir_run15 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ID _v ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_env = _menhir_discard _menhir_env in
        let _menhir_stack = Obj.magic _menhir_stack in
        let (i : (string)) = _v in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        let _1 = () in
        let _v : (Ast.virgula_id_rule) =                  ( Virgulaid(i) ) in
        let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
        let _menhir_stack = Obj.magic _menhir_stack in
        assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | VIRGULA ->
            _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState17
        | ABREPARENTESE | ATRIBUICAO | BREAK | DO | DOISDOISPONTOS | ELSE | ELSEIF | END | EOF | FECHAPARENTESE | FOR | FUNCTION | GOTO | ID _ | IF | IN | LOCAL | PONTOEVIRGULA | PRINT | REPEAT | RETURN | UNTIL | WHILE ->
            _menhir_reduce61 _menhir_env (Obj.magic _menhir_stack) MenhirState17
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState17)
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s

and _menhir_goto_stat : _menhir_env -> 'ttv_tail -> _menhir_state -> (Ast.stat) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    let _menhir_stack = Obj.magic _menhir_stack in
    assert (not _menhir_env._menhir_error);
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ABREPARENTESE ->
        _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState149
    | BREAK ->
        _menhir_run138 _menhir_env (Obj.magic _menhir_stack) MenhirState149
    | DO ->
        _menhir_run137 _menhir_env (Obj.magic _menhir_stack) MenhirState149
    | DOISDOISPONTOS ->
        _menhir_run134 _menhir_env (Obj.magic _menhir_stack) MenhirState149
    | FOR ->
        _menhir_run124 _menhir_env (Obj.magic _menhir_stack) MenhirState149
    | FUNCTION ->
        _menhir_run111 _menhir_env (Obj.magic _menhir_stack) MenhirState149
    | GOTO ->
        _menhir_run109 _menhir_env (Obj.magic _menhir_stack) MenhirState149
    | ID _v ->
        _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState149 _v
    | IF ->
        _menhir_run106 _menhir_env (Obj.magic _menhir_stack) MenhirState149
    | LOCAL ->
        _menhir_run100 _menhir_env (Obj.magic _menhir_stack) MenhirState149
    | PONTOEVIRGULA ->
        _menhir_run99 _menhir_env (Obj.magic _menhir_stack) MenhirState149
    | PRINT ->
        _menhir_run24 _menhir_env (Obj.magic _menhir_stack) MenhirState149
    | REPEAT ->
        _menhir_run23 _menhir_env (Obj.magic _menhir_stack) MenhirState149
    | WHILE ->
        _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState149
    | ELSE | ELSEIF | END | EOF | RETURN | UNTIL ->
        _menhir_reduce57 _menhir_env (Obj.magic _menhir_stack) MenhirState149
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState149

and _menhir_run2 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _menhir_stack = Obj.magic _menhir_stack in
    let _1 = () in
    let _v : (Ast.exp) =          ( Verdadeiro ) in
    _menhir_goto_exp _menhir_env _menhir_stack _menhir_s _v

and _menhir_run3 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _menhir_stack = Obj.magic _menhir_stack in
    let _1 = () in
    let _v : (Ast.unop) =               ( Subtracao) in
    _menhir_goto_unop _menhir_env _menhir_stack _menhir_s _v

and _menhir_run4 : _menhir_env -> 'ttv_tail -> _menhir_state -> (string) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _menhir_stack = Obj.magic _menhir_stack in
    let (i : (string)) = _v in
    let _v : (Ast.exp) =              ( String(i)) in
    _menhir_goto_exp _menhir_env _menhir_stack _menhir_s _v

and _menhir_run5 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _menhir_stack = Obj.magic _menhir_stack in
    let _1 = () in
    let _v : (Ast.unop) =              ( Quadrado) in
    _menhir_goto_unop _menhir_env _menhir_stack _menhir_s _v

and _menhir_run6 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _menhir_stack = Obj.magic _menhir_stack in
    let _1 = () in
    let _v : (Ast.exp) =                     ( PontoPonto ) in
    _menhir_goto_exp _menhir_env _menhir_stack _menhir_s _v

and _menhir_run7 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _menhir_stack = Obj.magic _menhir_stack in
    let _1 = () in
    let _v : (Ast.unop) =         ( Not) in
    _menhir_goto_unop _menhir_env _menhir_stack _menhir_s _v

and _menhir_run8 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _menhir_stack = Obj.magic _menhir_stack in
    let _1 = () in
    let _v : (Ast.exp) =         ( Nil ) in
    _menhir_goto_exp _menhir_env _menhir_stack _menhir_s _v

and _menhir_run9 : _menhir_env -> 'ttv_tail -> _menhir_state -> (int) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _menhir_stack = Obj.magic _menhir_stack in
    let (i : (int)) = _v in
    let _v : (Ast.exp) =           ( Int(i) ) in
    _menhir_goto_exp _menhir_env _menhir_stack _menhir_s _v

and _menhir_run11 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ABREPARENTESE ->
        _menhir_run12 _menhir_env (Obj.magic _menhir_stack) MenhirState11
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState11

and _menhir_run27 : _menhir_env -> 'ttv_tail -> _menhir_state -> (float) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _menhir_stack = Obj.magic _menhir_stack in
    let (i : (float)) = _v in
    let _v : (Ast.exp) =             ( Float(i) ) in
    _menhir_goto_exp _menhir_env _menhir_stack _menhir_s _v

and _menhir_run28 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _menhir_stack = Obj.magic _menhir_stack in
    let _1 = () in
    let _v : (Ast.exp) =           ( Falso) in
    _menhir_goto_exp _menhir_env _menhir_stack _menhir_s _v

and _menhir_run30 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ABRECHAVES ->
        _menhir_run30 _menhir_env (Obj.magic _menhir_stack) MenhirState30
    | ABRECOLCHETE ->
        _menhir_run68 _menhir_env (Obj.magic _menhir_stack) MenhirState30
    | ABREPARENTESE ->
        _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState30
    | FALSE ->
        _menhir_run28 _menhir_env (Obj.magic _menhir_stack) MenhirState30
    | FLOAT _v ->
        _menhir_run27 _menhir_env (Obj.magic _menhir_stack) MenhirState30 _v
    | FUNCTION ->
        _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState30
    | ID _v ->
        _menhir_run31 _menhir_env (Obj.magic _menhir_stack) MenhirState30 _v
    | INT _v ->
        _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState30 _v
    | NIL ->
        _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState30
    | NOT ->
        _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState30
    | PONTOPONTOPONTO ->
        _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState30
    | QUADRADO ->
        _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState30
    | STRING _v ->
        _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState30 _v
    | SUBTRACAO ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState30
    | TRUE ->
        _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState30
    | FECHACHAVES ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_s = MenhirState30 in
        let _v : (Ast.fieldlist option) =     ( None ) in
        _menhir_goto_option_fieldlist_ _menhir_env _menhir_stack _menhir_s _v
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState30

and _menhir_errorcase : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    match _menhir_s with
    | MenhirState196 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState195 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState186 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState185 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState182 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState177 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        raise _eRR
    | MenhirState174 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState173 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState172 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState171 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState168 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState166 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState154 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        raise _eRR
    | MenhirState149 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState146 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState145 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState143 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState142 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState140 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState137 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState133 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState131 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState130 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState129 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState128 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState127 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState126 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState125 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState124 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState122 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let ((_menhir_stack, _menhir_s), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState115 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState112 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        raise _eRR
    | MenhirState108 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState107 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState106 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState102 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        raise _eRR
    | MenhirState100 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState95 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState94 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState93 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState92 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState87 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState86 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState84 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState82 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState79 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState76 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState72 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState71 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState69 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState68 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState67 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState66 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState64 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState63 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState46 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState43 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState40 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let ((_menhir_stack, _menhir_s), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState36 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState34 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState32 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState30 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState29 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState26 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState24 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState23 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState22 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState17 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState14 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState12 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState11 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState1 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s
    | MenhirState0 ->
        let _menhir_stack = Obj.magic _menhir_stack in
        raise _eRR

and _menhir_reduce57 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _v : (Ast.stat list) =     ( [] ) in
    _menhir_goto_list_stat_ _menhir_env _menhir_stack _menhir_s _v

and _menhir_run1 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ABRECHAVES ->
        _menhir_run30 _menhir_env (Obj.magic _menhir_stack) MenhirState1
    | ABREPARENTESE ->
        _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState1
    | FALSE ->
        _menhir_run28 _menhir_env (Obj.magic _menhir_stack) MenhirState1
    | FLOAT _v ->
        _menhir_run27 _menhir_env (Obj.magic _menhir_stack) MenhirState1 _v
    | FUNCTION ->
        _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState1
    | ID _v ->
        _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState1 _v
    | INT _v ->
        _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState1 _v
    | NIL ->
        _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState1
    | NOT ->
        _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState1
    | PONTOPONTOPONTO ->
        _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState1
    | QUADRADO ->
        _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState1
    | STRING _v ->
        _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState1 _v
    | SUBTRACAO ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState1
    | TRUE ->
        _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState1
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState1

and _menhir_run23 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ABREPARENTESE ->
        _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState23
    | BREAK ->
        _menhir_run138 _menhir_env (Obj.magic _menhir_stack) MenhirState23
    | DO ->
        _menhir_run137 _menhir_env (Obj.magic _menhir_stack) MenhirState23
    | DOISDOISPONTOS ->
        _menhir_run134 _menhir_env (Obj.magic _menhir_stack) MenhirState23
    | FOR ->
        _menhir_run124 _menhir_env (Obj.magic _menhir_stack) MenhirState23
    | FUNCTION ->
        _menhir_run111 _menhir_env (Obj.magic _menhir_stack) MenhirState23
    | GOTO ->
        _menhir_run109 _menhir_env (Obj.magic _menhir_stack) MenhirState23
    | ID _v ->
        _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState23 _v
    | IF ->
        _menhir_run106 _menhir_env (Obj.magic _menhir_stack) MenhirState23
    | LOCAL ->
        _menhir_run100 _menhir_env (Obj.magic _menhir_stack) MenhirState23
    | PONTOEVIRGULA ->
        _menhir_run99 _menhir_env (Obj.magic _menhir_stack) MenhirState23
    | PRINT ->
        _menhir_run24 _menhir_env (Obj.magic _menhir_stack) MenhirState23
    | REPEAT ->
        _menhir_run23 _menhir_env (Obj.magic _menhir_stack) MenhirState23
    | WHILE ->
        _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState23
    | RETURN | UNTIL ->
        _menhir_reduce57 _menhir_env (Obj.magic _menhir_stack) MenhirState23
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState23

and _menhir_run24 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ABRECHAVES ->
        _menhir_run30 _menhir_env (Obj.magic _menhir_stack) MenhirState24
    | ABREPARENTESE ->
        _menhir_run26 _menhir_env (Obj.magic _menhir_stack) MenhirState24
    | STRING _v ->
        _menhir_run25 _menhir_env (Obj.magic _menhir_stack) MenhirState24 _v
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState24

and _menhir_run99 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _menhir_stack = Obj.magic _menhir_stack in
    let _1 = () in
    let _v : (Ast.stat) =                   ( Pontoevirgula ) in
    _menhir_goto_stat _menhir_env _menhir_stack _menhir_s _v

and _menhir_run100 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ID _v ->
        _menhir_run14 _menhir_env (Obj.magic _menhir_stack) MenhirState100 _v
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState100

and _menhir_run106 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ABRECHAVES ->
        _menhir_run30 _menhir_env (Obj.magic _menhir_stack) MenhirState106
    | ABREPARENTESE ->
        _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState106
    | FALSE ->
        _menhir_run28 _menhir_env (Obj.magic _menhir_stack) MenhirState106
    | FLOAT _v ->
        _menhir_run27 _menhir_env (Obj.magic _menhir_stack) MenhirState106 _v
    | FUNCTION ->
        _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState106
    | ID _v ->
        _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState106 _v
    | INT _v ->
        _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState106 _v
    | NIL ->
        _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState106
    | NOT ->
        _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState106
    | PONTOPONTOPONTO ->
        _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState106
    | QUADRADO ->
        _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState106
    | STRING _v ->
        _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState106 _v
    | SUBTRACAO ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState106
    | TRUE ->
        _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState106
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState106

and _menhir_run10 : _menhir_env -> 'ttv_tail -> _menhir_state -> (string) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    let _menhir_env = _menhir_discard _menhir_env in
    _menhir_reduce115 _menhir_env (Obj.magic _menhir_stack)

and _menhir_run109 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ID _v ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_env = _menhir_discard _menhir_env in
        let _menhir_stack = Obj.magic _menhir_stack in
        let (i : (string)) = _v in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        let _1 = () in
        let _v : (Ast.stat) =               ( Goto(i) ) in
        _menhir_goto_stat _menhir_env _menhir_stack _menhir_s _v
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s

and _menhir_run111 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ID _v ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_stack = (_menhir_stack, _v) in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | PONTO ->
            _menhir_run113 _menhir_env (Obj.magic _menhir_stack) MenhirState112
        | ABREPARENTESE | DOISPONTOS ->
            _menhir_reduce55 _menhir_env (Obj.magic _menhir_stack) MenhirState112
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState112)
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s

and _menhir_run124 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ID _v ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_s = MenhirState124 in
        let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | ATRIBUICAO ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_s = MenhirState125 in
            let _menhir_stack = (_menhir_stack, _menhir_s) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            (match _tok with
            | ABRECHAVES ->
                _menhir_run30 _menhir_env (Obj.magic _menhir_stack) MenhirState126
            | ABREPARENTESE ->
                _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState126
            | FALSE ->
                _menhir_run28 _menhir_env (Obj.magic _menhir_stack) MenhirState126
            | FLOAT _v ->
                _menhir_run27 _menhir_env (Obj.magic _menhir_stack) MenhirState126 _v
            | FUNCTION ->
                _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState126
            | ID _v ->
                _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState126 _v
            | INT _v ->
                _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState126 _v
            | NIL ->
                _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState126
            | NOT ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState126
            | PONTOPONTOPONTO ->
                _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState126
            | QUADRADO ->
                _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState126
            | STRING _v ->
                _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState126 _v
            | SUBTRACAO ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState126
            | TRUE ->
                _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState126
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState126)
        | VIRGULA ->
            _menhir_run15 _menhir_env (Obj.magic _menhir_stack) MenhirState125
        | IN ->
            _menhir_reduce61 _menhir_env (Obj.magic _menhir_stack) MenhirState125
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState125)
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState124

and _menhir_run134 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ID _v ->
        let _menhir_stack = Obj.magic _menhir_stack in
        let _menhir_stack = (_menhir_stack, _v) in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        (match _tok with
        | DOISDOISPONTOS ->
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_env = _menhir_discard _menhir_env in
            let _menhir_stack = Obj.magic _menhir_stack in
            let ((_menhir_stack, _menhir_s), (i : (string))) = _menhir_stack in
            let _3 = () in
            let _1 = () in
            let _v : (Ast.label) =                                        ( Label(i)) in
            let _menhir_stack = Obj.magic _menhir_stack in
            let _menhir_stack = Obj.magic _menhir_stack in
            let (l : (Ast.label)) = _v in
            let _v : (Ast.stat) =             ( Label(l) ) in
            _menhir_goto_stat _menhir_env _menhir_stack _menhir_s _v
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let _menhir_stack = Obj.magic _menhir_stack in
            let ((_menhir_stack, _menhir_s), _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s)
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        let _menhir_stack = Obj.magic _menhir_stack in
        let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s

and _menhir_run137 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ABREPARENTESE ->
        _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState137
    | BREAK ->
        _menhir_run138 _menhir_env (Obj.magic _menhir_stack) MenhirState137
    | DO ->
        _menhir_run137 _menhir_env (Obj.magic _menhir_stack) MenhirState137
    | DOISDOISPONTOS ->
        _menhir_run134 _menhir_env (Obj.magic _menhir_stack) MenhirState137
    | FOR ->
        _menhir_run124 _menhir_env (Obj.magic _menhir_stack) MenhirState137
    | FUNCTION ->
        _menhir_run111 _menhir_env (Obj.magic _menhir_stack) MenhirState137
    | GOTO ->
        _menhir_run109 _menhir_env (Obj.magic _menhir_stack) MenhirState137
    | ID _v ->
        _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState137 _v
    | IF ->
        _menhir_run106 _menhir_env (Obj.magic _menhir_stack) MenhirState137
    | LOCAL ->
        _menhir_run100 _menhir_env (Obj.magic _menhir_stack) MenhirState137
    | PONTOEVIRGULA ->
        _menhir_run99 _menhir_env (Obj.magic _menhir_stack) MenhirState137
    | PRINT ->
        _menhir_run24 _menhir_env (Obj.magic _menhir_stack) MenhirState137
    | REPEAT ->
        _menhir_run23 _menhir_env (Obj.magic _menhir_stack) MenhirState137
    | WHILE ->
        _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState137
    | END | RETURN ->
        _menhir_reduce57 _menhir_env (Obj.magic _menhir_stack) MenhirState137
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState137

and _menhir_run138 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_env = _menhir_discard _menhir_env in
    let _menhir_stack = Obj.magic _menhir_stack in
    let _1 = () in
    let _v : (Ast.stat) =           ( Break ) in
    _menhir_goto_stat _menhir_env _menhir_stack _menhir_s _v

and _menhir_run29 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ABRECHAVES ->
        _menhir_run30 _menhir_env (Obj.magic _menhir_stack) MenhirState29
    | ABREPARENTESE ->
        _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState29
    | FALSE ->
        _menhir_run28 _menhir_env (Obj.magic _menhir_stack) MenhirState29
    | FLOAT _v ->
        _menhir_run27 _menhir_env (Obj.magic _menhir_stack) MenhirState29 _v
    | FUNCTION ->
        _menhir_run11 _menhir_env (Obj.magic _menhir_stack) MenhirState29
    | ID _v ->
        _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState29 _v
    | INT _v ->
        _menhir_run9 _menhir_env (Obj.magic _menhir_stack) MenhirState29 _v
    | NIL ->
        _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState29
    | NOT ->
        _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState29
    | PONTOPONTOPONTO ->
        _menhir_run6 _menhir_env (Obj.magic _menhir_stack) MenhirState29
    | QUADRADO ->
        _menhir_run5 _menhir_env (Obj.magic _menhir_stack) MenhirState29
    | STRING _v ->
        _menhir_run4 _menhir_env (Obj.magic _menhir_stack) MenhirState29 _v
    | SUBTRACAO ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) MenhirState29
    | TRUE ->
        _menhir_run2 _menhir_env (Obj.magic _menhir_stack) MenhirState29
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState29

and _menhir_discard : _menhir_env -> _menhir_env =
  fun _menhir_env ->
    let lexer = _menhir_env._menhir_lexer in
    let lexbuf = _menhir_env._menhir_lexbuf in
    let _tok = lexer lexbuf in
    {
      _menhir_lexer = lexer;
      _menhir_lexbuf = lexbuf;
      _menhir_token = _tok;
      _menhir_error = false;
    }

and program : (Lexing.lexbuf -> token) -> Lexing.lexbuf -> (Ast.program) =
  fun lexer lexbuf ->
    let _menhir_env = let _tok = Obj.magic () in
    {
      _menhir_lexer = lexer;
      _menhir_lexbuf = lexbuf;
      _menhir_token = _tok;
      _menhir_error = false;
    } in
    Obj.magic (let _menhir_stack = ((), _menhir_env._menhir_lexbuf.Lexing.lex_curr_p) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ABREPARENTESE ->
        _menhir_run29 _menhir_env (Obj.magic _menhir_stack) MenhirState0
    | BREAK ->
        _menhir_run138 _menhir_env (Obj.magic _menhir_stack) MenhirState0
    | DO ->
        _menhir_run137 _menhir_env (Obj.magic _menhir_stack) MenhirState0
    | DOISDOISPONTOS ->
        _menhir_run134 _menhir_env (Obj.magic _menhir_stack) MenhirState0
    | FOR ->
        _menhir_run124 _menhir_env (Obj.magic _menhir_stack) MenhirState0
    | FUNCTION ->
        _menhir_run111 _menhir_env (Obj.magic _menhir_stack) MenhirState0
    | GOTO ->
        _menhir_run109 _menhir_env (Obj.magic _menhir_stack) MenhirState0
    | ID _v ->
        _menhir_run10 _menhir_env (Obj.magic _menhir_stack) MenhirState0 _v
    | IF ->
        _menhir_run106 _menhir_env (Obj.magic _menhir_stack) MenhirState0
    | LOCAL ->
        _menhir_run100 _menhir_env (Obj.magic _menhir_stack) MenhirState0
    | PONTOEVIRGULA ->
        _menhir_run99 _menhir_env (Obj.magic _menhir_stack) MenhirState0
    | PRINT ->
        _menhir_run24 _menhir_env (Obj.magic _menhir_stack) MenhirState0
    | REPEAT ->
        _menhir_run23 _menhir_env (Obj.magic _menhir_stack) MenhirState0
    | WHILE ->
        _menhir_run1 _menhir_env (Obj.magic _menhir_stack) MenhirState0
    | EOF | RETURN ->
        _menhir_reduce57 _menhir_env (Obj.magic _menhir_stack) MenhirState0
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState0)
  

